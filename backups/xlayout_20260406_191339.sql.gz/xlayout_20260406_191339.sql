--
-- PostgreSQL database dump
--

\restrict rKVYobWk74ozb3Tvam8pFcQK3gwHeFOgCN21xfg50LNeX3ZeAUY9ndFYBs9NUro

-- Dumped from database version 15.17
-- Dumped by pg_dump version 15.17

-- Started on 2026-04-06 17:13:39 UTC

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 879 (class 1247 OID 16386)
-- Name: AuditActorType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."AuditActorType" AS ENUM (
    'PLATFORM_USER',
    'COMPANY_USER',
    'DISTRIBUTOR_USER',
    'END_USER',
    'SYSTEM'
);


--
-- TOC entry 882 (class 1247 OID 16398)
-- Name: CompanyUserRole; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."CompanyUserRole" AS ENUM (
    'TENANT_ADMIN',
    'BUSINESS_OWNER',
    'CATALOG_MANAGER',
    'SALES_USER'
);


--
-- TOC entry 1026 (class 1247 OID 17162)
-- Name: DiscountScope; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."DiscountScope" AS ENUM (
    'GLOBAL',
    'BY_LINE',
    'BY_PRODUCT'
);


--
-- TOC entry 1020 (class 1247 OID 17150)
-- Name: DistributorPlan; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."DistributorPlan" AS ENUM (
    'STANDARD',
    'PRO'
);


--
-- TOC entry 885 (class 1247 OID 16408)
-- Name: DistributorUserRole; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."DistributorUserRole" AS ENUM (
    'DISTRIBUTOR_ADMIN',
    'DESIGNER',
    'SALES'
);


--
-- TOC entry 888 (class 1247 OID 16416)
-- Name: ImportJobStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."ImportJobStatus" AS ENUM (
    'PENDING',
    'PROCESSING',
    'COMPLETED',
    'FAILED'
);


--
-- TOC entry 891 (class 1247 OID 16426)
-- Name: MarkupScope; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."MarkupScope" AS ENUM (
    'GLOBAL',
    'BY_TENANT',
    'BY_LINE',
    'BY_PRODUCT'
);


--
-- TOC entry 894 (class 1247 OID 16436)
-- Name: PlatformRole; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."PlatformRole" AS ENUM (
    'PLATFORM_OWNER',
    'PLATFORM_ADMIN'
);


--
-- TOC entry 897 (class 1247 OID 16442)
-- Name: ProductStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."ProductStatus" AS ENUM (
    'DRAFT',
    'PUBLISHED',
    'ARCHIVED'
);


--
-- TOC entry 1023 (class 1247 OID 17156)
-- Name: QuoteMode; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."QuoteMode" AS ENUM (
    'PER_BRAND',
    'CONSOLIDATED'
);


--
-- TOC entry 900 (class 1247 OID 16450)
-- Name: TenantStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."TenantStatus" AS ENUM (
    'ACTIVE',
    'INACTIVE',
    'SUSPENDED',
    'PENDING'
);


--
-- TOC entry 903 (class 1247 OID 16460)
-- Name: UserStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."UserStatus" AS ENUM (
    'ACTIVE',
    'INACTIVE',
    'SUSPENDED'
);


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 214 (class 1259 OID 16467)
-- Name: activation_codes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.activation_codes (
    id text NOT NULL,
    tenant_id text NOT NULL,
    code text NOT NULL,
    catalog_enabled boolean DEFAULT true NOT NULL,
    prices_enabled boolean DEFAULT false NOT NULL,
    conditions_enabled boolean DEFAULT false NOT NULL,
    max_uses integer,
    used_count integer DEFAULT 0 NOT NULL,
    expires_at timestamp(3) without time zone,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 215 (class 1259 OID 16478)
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_logs (
    id text NOT NULL,
    actor_type public."AuditActorType" NOT NULL,
    actor_id text NOT NULL,
    tenant_id text,
    action text NOT NULL,
    entity_type text NOT NULL,
    entity_id text,
    payload jsonb,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 216 (class 1259 OID 16484)
-- Name: brands; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.brands (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    "logoUrl" text,
    tenant_id text NOT NULL
);


--
-- TOC entry 217 (class 1259 OID 16489)
-- Name: catalog_accesses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.catalog_accesses (
    id text NOT NULL,
    tenant_id text NOT NULL,
    end_user_id text NOT NULL,
    catalog_enabled boolean DEFAULT true NOT NULL,
    prices_enabled boolean DEFAULT false NOT NULL,
    conditions_enabled boolean DEFAULT false NOT NULL,
    activated_by_user_id text,
    activation_code_id text,
    active boolean DEFAULT true NOT NULL,
    activated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    expires_at timestamp(3) without time zone
);


--
-- TOC entry 218 (class 1259 OID 16499)
-- Name: companies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.companies (
    id text NOT NULL,
    name text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 219 (class 1259 OID 16505)
-- Name: company_brand_access; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.company_brand_access (
    company_id text NOT NULL,
    brand_id text NOT NULL,
    "grantedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 220 (class 1259 OID 16511)
-- Name: company_price_lists; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.company_price_lists (
    tenant_id text NOT NULL,
    price_list_id text NOT NULL
);


--
-- TOC entry 221 (class 1259 OID 16516)
-- Name: company_users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.company_users (
    id text NOT NULL,
    tenant_id text NOT NULL,
    email text NOT NULL,
    password_hash text NOT NULL,
    first_name text NOT NULL,
    last_name text NOT NULL,
    role public."CompanyUserRole" DEFAULT 'CATALOG_MANAGER'::public."CompanyUserRole" NOT NULL,
    status public."UserStatus" DEFAULT 'ACTIVE'::public."UserStatus" NOT NULL,
    preferences jsonb,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 222 (class 1259 OID 16524)
-- Name: discount_rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.discount_rules (
    id text NOT NULL,
    tenant_id text NOT NULL,
    name text NOT NULL,
    "strategyType" text NOT NULL,
    "configPayload" jsonb NOT NULL,
    priority integer DEFAULT 0 NOT NULL,
    active boolean DEFAULT true NOT NULL
);


--
-- TOC entry 255 (class 1259 OID 17205)
-- Name: distributor_branding_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.distributor_branding_configs (
    id text NOT NULL,
    distributor_id text NOT NULL,
    logo_url text,
    company_name text,
    primary_color text DEFAULT '#4F46E5'::text NOT NULL,
    accent_color text DEFAULT '#10B981'::text NOT NULL,
    address text,
    phone text,
    email text,
    rfc text,
    website text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 223 (class 1259 OID 16531)
-- Name: distributor_catalog_accesses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.distributor_catalog_accesses (
    id text NOT NULL,
    distributor_id text NOT NULL,
    tenant_id text NOT NULL,
    price_list_type text DEFAULT 'A'::text NOT NULL,
    active boolean DEFAULT true NOT NULL,
    granted_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 224 (class 1259 OID 16539)
-- Name: distributor_companies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.distributor_companies (
    id text NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    contact_email text,
    phone text,
    country text,
    status public."UserStatus" DEFAULT 'ACTIVE'::public."UserStatus" NOT NULL,
    metadata jsonb,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    plan public."DistributorPlan" DEFAULT 'STANDARD'::public."DistributorPlan" NOT NULL
);


--
-- TOC entry 225 (class 1259 OID 16547)
-- Name: distributor_price_markups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.distributor_price_markups (
    id text NOT NULL,
    distributor_id text NOT NULL,
    scope public."MarkupScope" DEFAULT 'GLOBAL'::public."MarkupScope" NOT NULL,
    tenant_id text,
    product_line_id text,
    product_id text,
    markup_percent numeric(8,4) NOT NULL,
    active boolean DEFAULT true NOT NULL,
    priority integer DEFAULT 0 NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 254 (class 1259 OID 17194)
-- Name: distributor_pro_pricing_rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.distributor_pro_pricing_rules (
    id text NOT NULL,
    distributor_id text NOT NULL,
    scope public."MarkupScope" DEFAULT 'GLOBAL'::public."MarkupScope" NOT NULL,
    tenant_id text,
    product_line_id text,
    product_id text,
    markup_percent numeric(8,4) NOT NULL,
    active boolean DEFAULT true NOT NULL,
    priority integer DEFAULT 0 NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 226 (class 1259 OID 16556)
-- Name: distributor_users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.distributor_users (
    id text NOT NULL,
    distributor_id text NOT NULL,
    email text NOT NULL,
    password_hash text NOT NULL,
    first_name text NOT NULL,
    last_name text NOT NULL,
    role public."DistributorUserRole" DEFAULT 'DESIGNER'::public."DistributorUserRole" NOT NULL,
    status public."UserStatus" DEFAULT 'ACTIVE'::public."UserStatus" NOT NULL,
    preferences jsonb,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 227 (class 1259 OID 16564)
-- Name: end_users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.end_users (
    id text NOT NULL,
    email text NOT NULL,
    password_hash text NOT NULL,
    first_name text NOT NULL,
    last_name text NOT NULL,
    phone text,
    company_name text,
    profession text,
    country text,
    status public."UserStatus" DEFAULT 'ACTIVE'::public."UserStatus" NOT NULL,
    preferences jsonb,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 228 (class 1259 OID 16571)
-- Name: import_jobs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.import_jobs (
    id text NOT NULL,
    tenant_id text NOT NULL,
    type text NOT NULL,
    filename text NOT NULL,
    status public."ImportJobStatus" DEFAULT 'PENDING'::public."ImportJobStatus" NOT NULL,
    summary jsonb,
    created_by_id text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 229 (class 1259 OID 16578)
-- Name: manufacturer_distributor_accesses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.manufacturer_distributor_accesses (
    id text NOT NULL,
    tenant_id text NOT NULL,
    distributor_id text NOT NULL,
    active boolean DEFAULT true NOT NULL,
    granted_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    expires_at timestamp(3) without time zone,
    notes text,
    default_price_list text DEFAULT 'A'::text NOT NULL
);


--
-- TOC entry 252 (class 1259 OID 17174)
-- Name: manufacturer_distributor_allowed_price_lists; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.manufacturer_distributor_allowed_price_lists (
    id text NOT NULL,
    tenant_id text NOT NULL,
    distributor_id text NOT NULL,
    price_list_type text NOT NULL,
    is_default boolean DEFAULT false NOT NULL,
    active boolean DEFAULT true NOT NULL,
    granted_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 253 (class 1259 OID 17184)
-- Name: manufacturer_distributor_discounts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.manufacturer_distributor_discounts (
    id text NOT NULL,
    tenant_id text NOT NULL,
    distributor_id text NOT NULL,
    discount_percent numeric(8,4) NOT NULL,
    scope public."DiscountScope" DEFAULT 'GLOBAL'::public."DiscountScope" NOT NULL,
    product_line_id text,
    product_id text,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 230 (class 1259 OID 16585)
-- Name: openings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.openings (
    id text NOT NULL,
    project_version_id text NOT NULL,
    wall_id text NOT NULL,
    type text NOT NULL,
    position_x double precision NOT NULL,
    width double precision NOT NULL,
    height double precision NOT NULL
);


--
-- TOC entry 231 (class 1259 OID 16590)
-- Name: placements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.placements (
    id text NOT NULL,
    project_version_id text NOT NULL,
    room_id text,
    product_id text NOT NULL,
    pos_x double precision NOT NULL,
    pos_y double precision NOT NULL,
    pos_z double precision NOT NULL,
    rot_x double precision NOT NULL,
    rot_y double precision NOT NULL,
    rot_z double precision NOT NULL
);


--
-- TOC entry 232 (class 1259 OID 16595)
-- Name: platform_users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.platform_users (
    id text NOT NULL,
    email text NOT NULL,
    password_hash text NOT NULL,
    first_name text NOT NULL,
    last_name text NOT NULL,
    role public."PlatformRole" DEFAULT 'PLATFORM_ADMIN'::public."PlatformRole" NOT NULL,
    status public."UserStatus" DEFAULT 'ACTIVE'::public."UserStatus" NOT NULL,
    preferences jsonb,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 233 (class 1259 OID 16603)
-- Name: price_list_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.price_list_items (
    price_list_id text NOT NULL,
    product_id_legacy text NOT NULL,
    price numeric(10,2) NOT NULL
);


--
-- TOC entry 234 (class 1259 OID 16608)
-- Name: price_lists; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.price_lists (
    id text NOT NULL,
    name text NOT NULL,
    currency text DEFAULT 'USD'::text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 235 (class 1259 OID 16615)
-- Name: product_assets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_assets (
    id text NOT NULL,
    tenant_id text NOT NULL,
    product_id text,
    "assetType" text NOT NULL,
    file_url text,
    thumbnail_url text,
    footprint_2d_url text,
    model_3d_url text,
    original_file_url text,
    original_format text,
    conversion_status text DEFAULT 'pending'::text NOT NULL,
    conversion_error text,
    metadata jsonb,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 236 (class 1259 OID 16622)
-- Name: product_categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_categories (
    id text NOT NULL,
    tenant_id text NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    parent_id text,
    active boolean DEFAULT true NOT NULL
);


--
-- TOC entry 237 (class 1259 OID 16628)
-- Name: product_conditions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_conditions (
    id text NOT NULL,
    tenant_id text NOT NULL,
    product_id text,
    line_id text,
    condition_type text NOT NULL,
    description text NOT NULL,
    metadata jsonb,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 238 (class 1259 OID 16635)
-- Name: product_lines; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_lines (
    id text NOT NULL,
    tenant_id text NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    category text,
    description text,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 239 (class 1259 OID 16642)
-- Name: product_prices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_prices (
    id text NOT NULL,
    tenant_id text NOT NULL,
    product_id text NOT NULL,
    price_type text DEFAULT 'A'::text NOT NULL,
    currency text DEFAULT 'MXN'::text NOT NULL,
    base_price numeric(12,2) NOT NULL,
    active boolean DEFAULT true NOT NULL,
    valid_from timestamp(3) without time zone,
    valid_to timestamp(3) without time zone,
    metadata jsonb,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    variant_id text
);


--
-- TOC entry 240 (class 1259 OID 16651)
-- Name: product_variants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_variants (
    id text NOT NULL,
    product_id text NOT NULL,
    tenant_id text NOT NULL,
    name text NOT NULL,
    variant_type text NOT NULL,
    sku text,
    metadata jsonb,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    depth double precision,
    height double precision,
    sort_order integer DEFAULT 0 NOT NULL,
    width double precision
);


--
-- TOC entry 241 (class 1259 OID 16659)
-- Name: products; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.products (
    id text NOT NULL,
    tenant_id text NOT NULL,
    line_id text NOT NULL,
    category_id text,
    sku text NOT NULL,
    name text NOT NULL,
    description text,
    width double precision NOT NULL,
    depth double precision NOT NULL,
    height double precision NOT NULL,
    active boolean DEFAULT true NOT NULL,
    status public."ProductStatus" DEFAULT 'DRAFT'::public."ProductStatus" NOT NULL,
    metadata jsonb
);


--
-- TOC entry 242 (class 1259 OID 16666)
-- Name: project_versions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_versions (
    id text NOT NULL,
    project_id text NOT NULL,
    "versionNum" integer NOT NULL,
    scene_state_json jsonb NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    save_mode text DEFAULT 'autosave'::text NOT NULL,
    scene_hash text,
    summary jsonb
);


--
-- TOC entry 243 (class 1259 OID 16673)
-- Name: projects; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.projects (
    id text NOT NULL,
    tenant_id text NOT NULL,
    name text NOT NULL,
    description text,
    price_type text DEFAULT 'A'::text NOT NULL,
    creator_id text NOT NULL,
    client_company text,
    client_name text,
    commercial_status text DEFAULT 'Prospecto'::text NOT NULL,
    contact_email text,
    contact_name text,
    contact_phone text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    due_date timestamp(3) without time zone,
    estimated_value numeric(12,2),
    final_value numeric(12,2),
    operational_status text DEFAULT 'Sin iniciar'::text NOT NULL,
    priority text DEFAULT 'Media'::text NOT NULL,
    probability integer,
    project_code text,
    source text,
    tags jsonb,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 256 (class 1259 OID 17215)
-- Name: quote_lines; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.quote_lines (
    id text NOT NULL,
    quote_id text NOT NULL,
    product_id text,
    variant_id text,
    tenant_id text NOT NULL,
    tenant_name text DEFAULT ''::text NOT NULL,
    product_name text NOT NULL,
    product_sku text,
    quantity integer DEFAULT 1 NOT NULL,
    price_list_type text NOT NULL,
    base_list_price numeric(12,2) NOT NULL,
    discount_percent numeric(8,4) DEFAULT 0 NOT NULL,
    authorized_price numeric(12,2) NOT NULL,
    pro_markup numeric(8,4) DEFAULT 0 NOT NULL,
    final_price numeric(12,2) NOT NULL,
    line_total numeric(12,2) NOT NULL,
    currency text DEFAULT 'MXN'::text NOT NULL,
    metadata jsonb
);


--
-- TOC entry 244 (class 1259 OID 16683)
-- Name: quote_templates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.quote_templates (
    id text NOT NULL,
    owner_type text NOT NULL,
    tenant_id text,
    distributor_id text,
    name text DEFAULT 'Cotización estándar'::text NOT NULL,
    logo_url text,
    company_name text,
    address text,
    phone text,
    email text,
    rfc text,
    website text,
    primary_color text DEFAULT '#4F46E5'::text NOT NULL,
    accent_color text DEFAULT '#10B981'::text NOT NULL,
    font_family text DEFAULT 'helvetica'::text NOT NULL,
    header_text text,
    footer_text text,
    validity_days integer DEFAULT 30 NOT NULL,
    show_iva boolean DEFAULT true NOT NULL,
    iva_rate double precision DEFAULT 0.16 NOT NULL,
    currency text DEFAULT 'MXN'::text NOT NULL,
    is_default boolean DEFAULT false NOT NULL,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 245 (class 1259 OID 16699)
-- Name: quotes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.quotes (
    id text NOT NULL,
    tenant_id text NOT NULL,
    project_version_id text NOT NULL,
    total_amount numeric(12,2) NOT NULL,
    total_pieces integer DEFAULT 0 NOT NULL,
    price_type text DEFAULT 'A'::text NOT NULL,
    status text DEFAULT 'DRAFT'::text NOT NULL,
    "quoteData" jsonb NOT NULL,
    creator_id text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    distributor_id text,
    iva_amount numeric(12,2) DEFAULT 0 NOT NULL,
    quote_mode public."QuoteMode" DEFAULT 'PER_BRAND'::public."QuoteMode" NOT NULL,
    subtotal_amount numeric(12,2) DEFAULT 0 NOT NULL
);


--
-- TOC entry 246 (class 1259 OID 16708)
-- Name: roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.roles (
    id text NOT NULL,
    name text NOT NULL,
    description text
);


--
-- TOC entry 247 (class 1259 OID 16713)
-- Name: rooms; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rooms (
    id text NOT NULL,
    project_version_id text NOT NULL,
    name text,
    area_square_meters double precision,
    "dataJson" jsonb
);


--
-- TOC entry 248 (class 1259 OID 16718)
-- Name: tenants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tenants (
    id text NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    status public."TenantStatus" DEFAULT 'PENDING'::public."TenantStatus" NOT NULL,
    logo_url text,
    contact_email text,
    created_by_id text,
    metadata jsonb,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 249 (class 1259 OID 16725)
-- Name: user_roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_roles (
    user_id text NOT NULL,
    role_id text NOT NULL
);


--
-- TOC entry 250 (class 1259 OID 16730)
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id text NOT NULL,
    email text NOT NULL,
    password text NOT NULL,
    "firstName" text NOT NULL,
    "lastName" text NOT NULL,
    tenant_id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 251 (class 1259 OID 16736)
-- Name: walls; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.walls (
    id text NOT NULL,
    project_version_id text NOT NULL,
    room_id text,
    start_x double precision NOT NULL,
    start_y double precision NOT NULL,
    end_x double precision NOT NULL,
    end_y double precision NOT NULL,
    thickness double precision NOT NULL,
    height double precision NOT NULL
);


--
-- TOC entry 3888 (class 0 OID 16467)
-- Dependencies: 214
-- Data for Name: activation_codes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.activation_codes (id, tenant_id, code, catalog_enabled, prices_enabled, conditions_enabled, max_uses, used_count, expires_at, active, created_at) FROM stdin;
84d150d9-9aae-4f63-b33f-7c6f58b40da4	843c9ed9-5fce-4111-9839-34949786bed8	PMLAPIEDAD-DEMO	t	t	f	100	0	\N	t	2026-03-25 04:23:38.14
\.


--
-- TOC entry 3889 (class 0 OID 16478)
-- Dependencies: 215
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_logs (id, actor_type, actor_id, tenant_id, action, entity_type, entity_id, payload, created_at) FROM stdin;
\.


--
-- TOC entry 3890 (class 0 OID 16484)
-- Dependencies: 216
-- Data for Name: brands; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.brands (id, name, description, "logoUrl", tenant_id) FROM stdin;
\.


--
-- TOC entry 3891 (class 0 OID 16489)
-- Dependencies: 217
-- Data for Name: catalog_accesses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.catalog_accesses (id, tenant_id, end_user_id, catalog_enabled, prices_enabled, conditions_enabled, activated_by_user_id, activation_code_id, active, activated_at, expires_at) FROM stdin;
\.


--
-- TOC entry 3892 (class 0 OID 16499)
-- Dependencies: 218
-- Data for Name: companies; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.companies (id, name, "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 3893 (class 0 OID 16505)
-- Dependencies: 219
-- Data for Name: company_brand_access; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.company_brand_access (company_id, brand_id, "grantedAt") FROM stdin;
\.


--
-- TOC entry 3894 (class 0 OID 16511)
-- Dependencies: 220
-- Data for Name: company_price_lists; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.company_price_lists (tenant_id, price_list_id) FROM stdin;
\.


--
-- TOC entry 3895 (class 0 OID 16516)
-- Dependencies: 221
-- Data for Name: company_users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.company_users (id, tenant_id, email, password_hash, first_name, last_name, role, status, preferences, created_at, updated_at) FROM stdin;
91fe865b-eb59-4b28-a861-e6330fee9826	843c9ed9-5fce-4111-9839-34949786bed8	admin@pmlapiedad.com	$2a$10$4W0uIH5.q72wdf7FIh6YFem97ov6g/fxakM6i6YLMotPI5YNOfrru	Admin	PM La Piedad	TENANT_ADMIN	ACTIVE	\N	2026-03-25 04:23:37.898	2026-03-27 01:53:47.079
87bef96f-0286-4995-a05f-ec1ca6715765	b0a521ce-a8f0-4a63-997d-911c06aa7495	admin@demobrand.io	$2a$10$CuEDSii7VNqN9ir6MApWHuucUnGuGlllGPMY8ab7AG1osbE.3IfpO	Admin	Demo Brand	TENANT_ADMIN	ACTIVE	\N	2026-03-25 04:23:38.075	2026-03-27 01:53:47.262
d19e8e60-fca2-4498-a210-8c3d48808f31	ad434e3f-b929-4ff4-a80d-11feac16b136	jx.granados@pmlapiedad.com	$2a$10$r4VTQtFolgSbd621QH1azuiBSlGkP.2J6c6v/icmAft3jpqI5w6pS	Xocotzin	Granados	TENANT_ADMIN	ACTIVE	\N	2026-03-27 01:54:35.809	2026-03-27 01:54:35.809
\.


--
-- TOC entry 3896 (class 0 OID 16524)
-- Dependencies: 222
-- Data for Name: discount_rules; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.discount_rules (id, tenant_id, name, "strategyType", "configPayload", priority, active) FROM stdin;
\.


--
-- TOC entry 3929 (class 0 OID 17205)
-- Dependencies: 255
-- Data for Name: distributor_branding_configs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.distributor_branding_configs (id, distributor_id, logo_url, company_name, primary_color, accent_color, address, phone, email, rfc, website, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 3897 (class 0 OID 16531)
-- Dependencies: 223
-- Data for Name: distributor_catalog_accesses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.distributor_catalog_accesses (id, distributor_id, tenant_id, price_list_type, active, granted_at) FROM stdin;
a12bfe01-5252-4a10-a9c5-59879e7b14e0	409ac438-b74f-465e-8aff-92fde52d70c3	ad434e3f-b929-4ff4-a80d-11feac16b136	A	t	2026-03-27 01:55:37.103
\.


--
-- TOC entry 3898 (class 0 OID 16539)
-- Dependencies: 224
-- Data for Name: distributor_companies; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.distributor_companies (id, name, slug, contact_email, phone, country, status, metadata, created_at, updated_at, plan) FROM stdin;
409ac438-b74f-465e-8aff-92fde52d70c3	PEME	peme	jx.granados@peme.mx	+523525259090	MX	ACTIVE	\N	2026-03-27 01:55:29.921	2026-03-27 01:55:29.921	STANDARD
\.


--
-- TOC entry 3899 (class 0 OID 16547)
-- Dependencies: 225
-- Data for Name: distributor_price_markups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.distributor_price_markups (id, distributor_id, scope, tenant_id, product_line_id, product_id, markup_percent, active, priority, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 3928 (class 0 OID 17194)
-- Dependencies: 254
-- Data for Name: distributor_pro_pricing_rules; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.distributor_pro_pricing_rules (id, distributor_id, scope, tenant_id, product_line_id, product_id, markup_percent, active, priority, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 3900 (class 0 OID 16556)
-- Dependencies: 226
-- Data for Name: distributor_users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.distributor_users (id, distributor_id, email, password_hash, first_name, last_name, role, status, preferences, created_at, updated_at) FROM stdin;
0464a0e6-8763-46fb-927b-119fbfc0d30c	409ac438-b74f-465e-8aff-92fde52d70c3	test-designer-1@peme.mx	$2a$10$N8R7uYMO1ONQK6QgsueA/eHq9k/TSgzq3MKm2NVkwrlB0w.tC6a4y	Test	Designer	DESIGNER	ACTIVE	\N	2026-03-27 02:07:33.846	2026-03-27 02:07:33.846
0650b7ab-ee0d-4a02-88db-ae714f839639	409ac438-b74f-465e-8aff-92fde52d70c3	diseña@pmlapiedad.com	$2a$10$XlISV4pzBz.ZueyJWjJmH.G25WvGMvUmt5jf350B61AgSW2zvnvsG	Xocotzin	Granados	DESIGNER	ACTIVE	\N	2026-03-27 02:48:28.599	2026-03-27 02:48:28.599
\.


--
-- TOC entry 3901 (class 0 OID 16564)
-- Dependencies: 227
-- Data for Name: end_users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.end_users (id, email, password_hash, first_name, last_name, phone, company_name, profession, country, status, preferences, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 3902 (class 0 OID 16571)
-- Dependencies: 228
-- Data for Name: import_jobs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.import_jobs (id, tenant_id, type, filename, status, summary, created_by_id, created_at, updated_at) FROM stdin;
1	843c9ed9-5fce-4111-9839-34949786bed8	CATALOG	test_import_v2.csv	COMPLETED	{"type": "catalog", "total": 222, "dryRun": true, "errors": [], "failed": 0, "created": 62, "success": true, "updated": 0, "warnings": ["Fila 2: width = 120m parece muy grande. ¿Verifique unidades?", "Fila 3: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 3: width = 140m parece muy grande. ¿Verifique unidades?", "Fila 4: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 4: width = 150m parece muy grande. ¿Verifique unidades?", "Fila 5: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 5: width = 160m parece muy grande. ¿Verifique unidades?", "Fila 6: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 6: width = 180m parece muy grande. ¿Verifique unidades?", "Fila 7: width = 120m parece muy grande. ¿Verifique unidades?", "Fila 8: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 8: width = 140m parece muy grande. ¿Verifique unidades?", "Fila 9: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 9: width = 150m parece muy grande. ¿Verifique unidades?", "Fila 10: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 10: width = 160m parece muy grande. ¿Verifique unidades?", "Fila 11: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 11: width = 180m parece muy grande. ¿Verifique unidades?", "Fila 12: width = 120m parece muy grande. ¿Verifique unidades?", "Fila 13: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 13: width = 140m parece muy grande. ¿Verifique unidades?", "Fila 14: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 14: width = 150m parece muy grande. ¿Verifique unidades?", "Fila 15: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 15: width = 160m parece muy grande. ¿Verifique unidades?", "Fila 16: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 16: width = 180m parece muy grande. ¿Verifique unidades?", "Fila 17: width = 120m parece muy grande. ¿Verifique unidades?", "Fila 18: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 18: width = 140m parece muy grande. ¿Verifique unidades?", "Fila 19: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 19: width = 160m parece muy grande. ¿Verifique unidades?", "Fila 20: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 20: width = 150m parece muy grande. ¿Verifique unidades?", "Fila 21: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 21: width = 180m parece muy grande. ¿Verifique unidades?", "Fila 22: width = 120m parece muy grande. ¿Verifique unidades?", "Fila 23: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 23: width = 140m parece muy grande. ¿Verifique unidades?", "Fila 24: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 24: width = 150m parece muy grande. ¿Verifique unidades?", "Fila 25: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 25: width = 160m parece muy grande. ¿Verifique unidades?", "Fila 26: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 26: width = 180m parece muy grande. ¿Verifique unidades?", "Fila 27: width = 120m parece muy grande. ¿Verifique unidades?", "Fila 28: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 28: width = 140m parece muy grande. ¿Verifique unidades?", "Fila 29: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 29: width = 150m parece muy grande. ¿Verifique unidades?", "Fila 30: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 30: width = 160m parece muy grande. ¿Verifique unidades?", "Fila 31: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 31: width = 180m parece muy grande. ¿Verifique unidades?", "Fila 32: width = 120m parece muy grande. ¿Verifique unidades?", "Fila 33: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 33: width = 140m parece muy grande. ¿Verifique unidades?", "Fila 34: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 34: width = 150m parece muy grande. ¿Verifique unidades?", "Fila 35: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 35: width = 160m parece muy grande. ¿Verifique unidades?", "Fila 36: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 36: width = 180m parece muy grande. ¿Verifique unidades?", "Fila 37: width = 120m parece muy grande. ¿Verifique unidades?", "Fila 38: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 38: width = 140m parece muy grande. ¿Verifique unidades?", "Fila 39: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 39: width = 150m parece muy grande. ¿Verifique unidades?", "Fila 40: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 40: width = 160m parece muy grande. ¿Verifique unidades?", "Fila 41: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 41: width = 180m parece muy grande. ¿Verifique unidades?", "Fila 46: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 46: width = 120m parece muy grande. ¿Verifique unidades?", "Fila 47: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 47: width = 120m parece muy grande. ¿Verifique unidades?", "Fila 48: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 48: width = 120m parece muy grande. ¿Verifique unidades?", "Fila 49: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 49: width = 120m parece muy grande. ¿Verifique unidades?", "Fila 54: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 54: width = 120m parece muy grande. ¿Verifique unidades?", "Fila 55: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 55: width = 120m parece muy grande. ¿Verifique unidades?", "Fila 56: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 56: width = 120m parece muy grande. ¿Verifique unidades?", "Fila 57: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 57: width = 120m parece muy grande. ¿Verifique unidades?", "Fila 58: width = 120m parece muy grande. ¿Verifique unidades?", "Fila 59: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 59: width = 140m parece muy grande. ¿Verifique unidades?", "Fila 60: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 60: width = 150m parece muy grande. ¿Verifique unidades?", "Fila 61: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 61: width = 160m parece muy grande. ¿Verifique unidades?", "Fila 62: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 62: width = 180m parece muy grande. ¿Verifique unidades?", "Fila 63: width = 120m parece muy grande. ¿Verifique unidades?", "Fila 64: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 64: width = 140m parece muy grande. ¿Verifique unidades?", "Fila 65: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 65: width = 150m parece muy grande. ¿Verifique unidades?", "Fila 66: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 66: width = 160m parece muy grande. ¿Verifique unidades?", "Fila 67: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 67: width = 180m parece muy grande. ¿Verifique unidades?", "Fila 68: width = 120m parece muy grande. ¿Verifique unidades?", "Fila 69: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 69: width = 140m parece muy grande. ¿Verifique unidades?", "Fila 70: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 70: width = 150m parece muy grande. ¿Verifique unidades?", "Fila 71: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 71: width = 160m parece muy grande. ¿Verifique unidades?", "Fila 72: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 72: width = 180m parece muy grande. ¿Verifique unidades?", "Fila 73: width = 120m parece muy grande. ¿Verifique unidades?", "Fila 74: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 74: width = 140m parece muy grande. ¿Verifique unidades?", "Fila 75: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 75: width = 160m parece muy grande. ¿Verifique unidades?", "Fila 76: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 76: width = 150m parece muy grande. ¿Verifique unidades?", "Fila 77: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 77: width = 180m parece muy grande. ¿Verifique unidades?", "Fila 78: width = 120m parece muy grande. ¿Verifique unidades?", "Fila 79: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 79: width = 140m parece muy grande. ¿Verifique unidades?", "Fila 80: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 80: width = 150m parece muy grande. ¿Verifique unidades?", "Fila 81: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 81: width = 160m parece muy grande. ¿Verifique unidades?", "Fila 82: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 82: width = 180m parece muy grande. ¿Verifique unidades?", "Fila 83: width = 120m parece muy grande. ¿Verifique unidades?", "Fila 84: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 84: width = 140m parece muy grande. ¿Verifique unidades?", "Fila 85: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 85: width = 150m parece muy grande. ¿Verifique unidades?", "Fila 86: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 86: width = 160m parece muy grande. ¿Verifique unidades?", "Fila 87: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 87: width = 180m parece muy grande. ¿Verifique unidades?", "Fila 88: width = 120m parece muy grande. ¿Verifique unidades?", "Fila 89: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 89: width = 140m parece muy grande. ¿Verifique unidades?", "Fila 90: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 90: width = 150m parece muy grande. ¿Verifique unidades?", "Fila 91: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 91: width = 160m parece muy grande. ¿Verifique unidades?", "Fila 92: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 92: width = 180m parece muy grande. ¿Verifique unidades?", "Fila 93: width = 120m parece muy grande. ¿Verifique unidades?", "Fila 94: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 94: width = 140m parece muy grande. ¿Verifique unidades?", "Fila 95: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 95: width = 150m parece muy grande. ¿Verifique unidades?", "Fila 96: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 96: width = 160m parece muy grande. ¿Verifique unidades?", "Fila 97: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 97: width = 180m parece muy grande. ¿Verifique unidades?", "Fila 102: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 102: width = 105m parece muy grande. ¿Verifique unidades?", "Fila 103: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 103: width = 105m parece muy grande. ¿Verifique unidades?", "Fila 104: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 104: width = 105m parece muy grande. ¿Verifique unidades?", "Fila 105: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 105: width = 105m parece muy grande. ¿Verifique unidades?", "Fila 110: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 110: width = 105m parece muy grande. ¿Verifique unidades?", "Fila 111: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 111: width = 105m parece muy grande. ¿Verifique unidades?", "Fila 112: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 112: width = 105m parece muy grande. ¿Verifique unidades?", "Fila 113: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 113: width = 105m parece muy grande. ¿Verifique unidades?", "Fila 114: width = 120m parece muy grande. ¿Verifique unidades?", "Fila 114: depth = 120m parece muy grande. ¿Verifique unidades?", "Fila 115: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 115: width = 140m parece muy grande. ¿Verifique unidades?", "Fila 115: depth = 120m parece muy grande. ¿Verifique unidades?", "Fila 116: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 116: width = 150m parece muy grande. ¿Verifique unidades?", "Fila 116: depth = 120m parece muy grande. ¿Verifique unidades?", "Fila 117: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 117: width = 160m parece muy grande. ¿Verifique unidades?", "Fila 117: depth = 120m parece muy grande. ¿Verifique unidades?", "Fila 118: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 118: width = 180m parece muy grande. ¿Verifique unidades?", "Fila 118: depth = 120m parece muy grande. ¿Verifique unidades?", "Fila 119: width = 120m parece muy grande. ¿Verifique unidades?", "Fila 119: depth = 120m parece muy grande. ¿Verifique unidades?", "Fila 120: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 120: width = 140m parece muy grande. ¿Verifique unidades?", "Fila 120: depth = 120m parece muy grande. ¿Verifique unidades?", "Fila 121: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 121: width = 150m parece muy grande. ¿Verifique unidades?", "Fila 121: depth = 120m parece muy grande. ¿Verifique unidades?", "Fila 122: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 122: width = 160m parece muy grande. ¿Verifique unidades?", "Fila 122: depth = 120m parece muy grande. ¿Verifique unidades?", "Fila 123: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 123: width = 180m parece muy grande. ¿Verifique unidades?", "Fila 123: depth = 120m parece muy grande. ¿Verifique unidades?", "Fila 124: width = 120m parece muy grande. ¿Verifique unidades?", "Fila 124: depth = 120m parece muy grande. ¿Verifique unidades?", "Fila 125: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 125: width = 140m parece muy grande. ¿Verifique unidades?", "Fila 125: depth = 120m parece muy grande. ¿Verifique unidades?", "Fila 126: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 126: width = 150m parece muy grande. ¿Verifique unidades?", "Fila 126: depth = 120m parece muy grande. ¿Verifique unidades?", "Fila 127: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 127: width = 160m parece muy grande. ¿Verifique unidades?", "Fila 127: depth = 120m parece muy grande. ¿Verifique unidades?", "Fila 128: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 128: width = 180m parece muy grande. ¿Verifique unidades?", "Fila 128: depth = 120m parece muy grande. ¿Verifique unidades?", "Fila 129: width = 120m parece muy grande. ¿Verifique unidades?", "Fila 129: depth = 120m parece muy grande. ¿Verifique unidades?", "Fila 130: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 130: width = 140m parece muy grande. ¿Verifique unidades?", "Fila 130: depth = 120m parece muy grande. ¿Verifique unidades?", "Fila 131: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 131: width = 150m parece muy grande. ¿Verifique unidades?", "Fila 131: depth = 120m parece muy grande. ¿Verifique unidades?", "Fila 132: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 132: width = 160m parece muy grande. ¿Verifique unidades?", "Fila 132: depth = 120m parece muy grande. ¿Verifique unidades?", "Fila 133: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 133: width = 180m parece muy grande. ¿Verifique unidades?", "Fila 133: depth = 120m parece muy grande. ¿Verifique unidades?", "Fila 134: width = 120m parece muy grande. ¿Verifique unidades?", "Fila 134: depth = 120m parece muy grande. ¿Verifique unidades?", "Fila 135: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 135: width = 140m parece muy grande. ¿Verifique unidades?", "Fila 135: depth = 120m parece muy grande. ¿Verifique unidades?", "Fila 136: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 136: width = 150m parece muy grande. ¿Verifique unidades?", "Fila 136: depth = 120m parece muy grande. ¿Verifique unidades?", "Fila 137: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 137: width = 160m parece muy grande. ¿Verifique unidades?", "Fila 137: depth = 120m parece muy grande. ¿Verifique unidades?", "Fila 138: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 138: width = 180m parece muy grande. ¿Verifique unidades?", "Fila 138: depth = 120m parece muy grande. ¿Verifique unidades?", "Fila 139: width = 120m parece muy grande. ¿Verifique unidades?", "Fila 139: depth = 120m parece muy grande. ¿Verifique unidades?", "Fila 140: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 140: width = 140m parece muy grande. ¿Verifique unidades?", "Fila 140: depth = 120m parece muy grande. ¿Verifique unidades?", "Fila 141: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 141: width = 150m parece muy grande. ¿Verifique unidades?", "Fila 141: depth = 120m parece muy grande. ¿Verifique unidades?", "Fila 142: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 142: width = 160m parece muy grande. ¿Verifique unidades?", "Fila 142: depth = 120m parece muy grande. ¿Verifique unidades?", "Fila 143: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 143: width = 180m parece muy grande. ¿Verifique unidades?", "Fila 143: depth = 120m parece muy grande. ¿Verifique unidades?", "Fila 144: width = 120m parece muy grande. ¿Verifique unidades?", "Fila 144: depth = 120m parece muy grande. ¿Verifique unidades?", "Fila 145: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 145: width = 140m parece muy grande. ¿Verifique unidades?", "Fila 145: depth = 120m parece muy grande. ¿Verifique unidades?", "Fila 146: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 146: width = 150m parece muy grande. ¿Verifique unidades?", "Fila 146: depth = 120m parece muy grande. ¿Verifique unidades?", "Fila 147: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 147: width = 160m parece muy grande. ¿Verifique unidades?", "Fila 147: depth = 120m parece muy grande. ¿Verifique unidades?", "Fila 148: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 148: width = 180m parece muy grande. ¿Verifique unidades?", "Fila 148: depth = 120m parece muy grande. ¿Verifique unidades?", "Fila 149: width = 120m parece muy grande. ¿Verifique unidades?", "Fila 149: depth = 120m parece muy grande. ¿Verifique unidades?", "Fila 150: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 150: width = 140m parece muy grande. ¿Verifique unidades?", "Fila 150: depth = 120m parece muy grande. ¿Verifique unidades?", "Fila 151: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 151: width = 150m parece muy grande. ¿Verifique unidades?", "Fila 151: depth = 120m parece muy grande. ¿Verifique unidades?", "Fila 152: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 152: width = 160m parece muy grande. ¿Verifique unidades?", "Fila 152: depth = 120m parece muy grande. ¿Verifique unidades?", "Fila 153: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 153: width = 180m parece muy grande. ¿Verifique unidades?", "Fila 153: depth = 120m parece muy grande. ¿Verifique unidades?", "Fila 154: depth = 120m parece muy grande. ¿Verifique unidades?", "Fila 155: depth = 120m parece muy grande. ¿Verifique unidades?", "Fila 156: depth = 120m parece muy grande. ¿Verifique unidades?", "Fila 157: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 157: width = 120m parece muy grande. ¿Verifique unidades?", "Fila 157: depth = 120m parece muy grande. ¿Verifique unidades?", "Fila 158: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 158: width = 120m parece muy grande. ¿Verifique unidades?", "Fila 158: depth = 120m parece muy grande. ¿Verifique unidades?", "Fila 159: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 159: width = 120m parece muy grande. ¿Verifique unidades?", "Fila 159: depth = 120m parece muy grande. ¿Verifique unidades?", "Fila 160: depth = 150m parece muy grande. ¿Verifique unidades?", "Fila 161: depth = 150m parece muy grande. ¿Verifique unidades?", "Fila 162: depth = 150m parece muy grande. ¿Verifique unidades?", "Fila 163: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 163: width = 120m parece muy grande. ¿Verifique unidades?", "Fila 163: depth = 150m parece muy grande. ¿Verifique unidades?", "Fila 164: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 164: width = 120m parece muy grande. ¿Verifique unidades?", "Fila 164: depth = 150m parece muy grande. ¿Verifique unidades?", "Fila 165: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 165: width = 120m parece muy grande. ¿Verifique unidades?", "Fila 165: depth = 150m parece muy grande. ¿Verifique unidades?", "Fila 166: width = 120m parece muy grande. ¿Verifique unidades?", "Fila 166: depth = 150m parece muy grande. ¿Verifique unidades?", "Fila 167: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 167: width = 140m parece muy grande. ¿Verifique unidades?", "Fila 167: depth = 150m parece muy grande. ¿Verifique unidades?", "Fila 168: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 168: width = 150m parece muy grande. ¿Verifique unidades?", "Fila 168: depth = 150m parece muy grande. ¿Verifique unidades?", "Fila 169: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 169: width = 160m parece muy grande. ¿Verifique unidades?", "Fila 169: depth = 150m parece muy grande. ¿Verifique unidades?", "Fila 170: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 170: width = 180m parece muy grande. ¿Verifique unidades?", "Fila 170: depth = 150m parece muy grande. ¿Verifique unidades?", "Fila 171: width = 120m parece muy grande. ¿Verifique unidades?", "Fila 171: depth = 150m parece muy grande. ¿Verifique unidades?", "Fila 172: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 172: width = 140m parece muy grande. ¿Verifique unidades?", "Fila 172: depth = 150m parece muy grande. ¿Verifique unidades?", "Fila 173: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 173: width = 150m parece muy grande. ¿Verifique unidades?", "Fila 173: depth = 150m parece muy grande. ¿Verifique unidades?", "Fila 174: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 174: width = 160m parece muy grande. ¿Verifique unidades?", "Fila 174: depth = 150m parece muy grande. ¿Verifique unidades?", "Fila 175: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 175: width = 180m parece muy grande. ¿Verifique unidades?", "Fila 175: depth = 150m parece muy grande. ¿Verifique unidades?", "Fila 176: width = 120m parece muy grande. ¿Verifique unidades?", "Fila 176: depth = 150m parece muy grande. ¿Verifique unidades?", "Fila 177: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 177: width = 140m parece muy grande. ¿Verifique unidades?", "Fila 177: depth = 150m parece muy grande. ¿Verifique unidades?", "Fila 178: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 178: width = 150m parece muy grande. ¿Verifique unidades?", "Fila 178: depth = 150m parece muy grande. ¿Verifique unidades?", "Fila 179: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 179: width = 160m parece muy grande. ¿Verifique unidades?", "Fila 179: depth = 150m parece muy grande. ¿Verifique unidades?", "Fila 180: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 180: width = 180m parece muy grande. ¿Verifique unidades?", "Fila 180: depth = 150m parece muy grande. ¿Verifique unidades?", "Fila 181: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 181: width = 120m parece muy grande. ¿Verifique unidades?", "Fila 181: depth = 120m parece muy grande. ¿Verifique unidades?", "Fila 182: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 182: width = 140m parece muy grande. ¿Verifique unidades?", "Fila 182: depth = 120m parece muy grande. ¿Verifique unidades?", "Fila 183: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 183: width = 150m parece muy grande. ¿Verifique unidades?", "Fila 183: depth = 120m parece muy grande. ¿Verifique unidades?", "Fila 184: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 184: width = 160m parece muy grande. ¿Verifique unidades?", "Fila 184: depth = 120m parece muy grande. ¿Verifique unidades?", "Fila 185: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 185: width = 180m parece muy grande. ¿Verifique unidades?", "Fila 185: depth = 120m parece muy grande. ¿Verifique unidades?", "Fila 186: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 186: width = 140m parece muy grande. ¿Verifique unidades?", "Fila 186: depth = 120m parece muy grande. ¿Verifique unidades?", "Fila 187: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 187: width = 120m parece muy grande. ¿Verifique unidades?", "Fila 187: depth = 120m parece muy grande. ¿Verifique unidades?", "Fila 188: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 188: width = 150m parece muy grande. ¿Verifique unidades?", "Fila 188: depth = 120m parece muy grande. ¿Verifique unidades?", "Fila 189: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 189: width = 160m parece muy grande. ¿Verifique unidades?", "Fila 189: depth = 120m parece muy grande. ¿Verifique unidades?", "Fila 190: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 190: width = 180m parece muy grande. ¿Verifique unidades?", "Fila 190: depth = 120m parece muy grande. ¿Verifique unidades?", "Fila 191: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 191: width = 120m parece muy grande. ¿Verifique unidades?", "Fila 191: depth = 120m parece muy grande. ¿Verifique unidades?", "Fila 192: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 192: width = 140m parece muy grande. ¿Verifique unidades?", "Fila 192: depth = 120m parece muy grande. ¿Verifique unidades?", "Fila 193: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 193: width = 150m parece muy grande. ¿Verifique unidades?", "Fila 193: depth = 120m parece muy grande. ¿Verifique unidades?", "Fila 194: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 194: width = 160m parece muy grande. ¿Verifique unidades?", "Fila 194: depth = 120m parece muy grande. ¿Verifique unidades?", "Fila 195: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 195: width = 180m parece muy grande. ¿Verifique unidades?", "Fila 195: depth = 120m parece muy grande. ¿Verifique unidades?", "Fila 196: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 196: width = 120m parece muy grande. ¿Verifique unidades?", "Fila 196: depth = 120m parece muy grande. ¿Verifique unidades?", "Fila 197: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 197: width = 140m parece muy grande. ¿Verifique unidades?", "Fila 197: depth = 120m parece muy grande. ¿Verifique unidades?", "Fila 198: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 198: width = 150m parece muy grande. ¿Verifique unidades?", "Fila 198: depth = 120m parece muy grande. ¿Verifique unidades?", "Fila 199: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 199: width = 160m parece muy grande. ¿Verifique unidades?", "Fila 199: depth = 120m parece muy grande. ¿Verifique unidades?", "Fila 200: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 200: width = 180m parece muy grande. ¿Verifique unidades?", "Fila 200: depth = 120m parece muy grande. ¿Verifique unidades?", "Fila 201: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 201: width = 120m parece muy grande. ¿Verifique unidades?", "Fila 201: depth = 120m parece muy grande. ¿Verifique unidades?", "Fila 202: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 202: width = 140m parece muy grande. ¿Verifique unidades?", "Fila 202: depth = 120m parece muy grande. ¿Verifique unidades?", "Fila 203: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 203: width = 150m parece muy grande. ¿Verifique unidades?", "Fila 203: depth = 120m parece muy grande. ¿Verifique unidades?", "Fila 204: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 204: width = 160m parece muy grande. ¿Verifique unidades?", "Fila 204: depth = 120m parece muy grande. ¿Verifique unidades?", "Fila 205: width = 180m parece muy grande. ¿Verifique unidades?", "Fila 205: depth = 120m parece muy grande. ¿Verifique unidades?", "Fila 206: depth = 120m parece muy grande. ¿Verifique unidades?", "Fila 207: depth = 120m parece muy grande. ¿Verifique unidades?", "Fila 208: depth = 120m parece muy grande. ¿Verifique unidades?", "Fila 209: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 209: width = 105m parece muy grande. ¿Verifique unidades?", "Fila 209: depth = 120m parece muy grande. ¿Verifique unidades?", "Fila 210: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 210: width = 105m parece muy grande. ¿Verifique unidades?", "Fila 210: depth = 120m parece muy grande. ¿Verifique unidades?", "Fila 211: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 211: width = 105m parece muy grande. ¿Verifique unidades?", "Fila 211: depth = 120m parece muy grande. ¿Verifique unidades?", "Fila 212: depth = 150m parece muy grande. ¿Verifique unidades?", "Fila 213: depth = 150m parece muy grande. ¿Verifique unidades?", "Fila 214: depth = 150m parece muy grande. ¿Verifique unidades?", "Fila 215: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 215: width = 105m parece muy grande. ¿Verifique unidades?", "Fila 215: depth = 150m parece muy grande. ¿Verifique unidades?", "Fila 216: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 216: width = 105m parece muy grande. ¿Verifique unidades?", "Fila 216: depth = 150m parece muy grande. ¿Verifique unidades?", "Fila 217: variant_type 'medidas' no es estándar (valores recomendados: color, texture, material, finish, size, config)", "Fila 217: width = 105m parece muy grande. ¿Verifique unidades?", "Fila 217: depth = 150m parece muy grande. ¿Verifique unidades?"], "succeeded": 0, "linesCreated": ["TERRA"], "variantsCreated": 160, "categoriesCreated": ["MESAS", "LATERALES", "MESAS BENCH", "MESAS YOGUI"]}	91fe865b-eb59-4b28-a861-e6330fee9826	2026-03-30 03:33:02.259	2026-03-30 22:17:56.741
2	843c9ed9-5fce-4111-9839-34949786bed8	CATALOG	test_import_errors.csv	COMPLETED	{"type": "catalog", "total": 222, "dryRun": true, "errors": [], "failed": 0, "created": 62, "success": true, "updated": 0, "warnings": [], "succeeded": 0, "linesCreated": ["TERRA"], "variantsCreated": 160, "categoriesCreated": ["MESAS", "LATERALES", "MESAS BENCH", "MESAS YOGUI"]}	91fe865b-eb59-4b28-a861-e6330fee9826	2026-03-30 03:33:04.478	2026-03-30 22:21:19.831
3	843c9ed9-5fce-4111-9839-34949786bed8	CATALOG	test_import_v2.csv	COMPLETED	{"type": "catalog", "total": 222, "dryRun": false, "errors": [], "failed": 0, "created": 62, "success": true, "updated": 0, "warnings": [], "succeeded": 222, "linesCreated": ["TERRA"], "variantsCreated": 160, "categoriesCreated": ["MESAS", "LATERALES", "MESAS BENCH", "MESAS YOGUI"]}	91fe865b-eb59-4b28-a861-e6330fee9826	2026-03-30 03:33:12.641	2026-03-30 22:21:39.41
\.


--
-- TOC entry 3903 (class 0 OID 16578)
-- Dependencies: 229
-- Data for Name: manufacturer_distributor_accesses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.manufacturer_distributor_accesses (id, tenant_id, distributor_id, active, granted_at, expires_at, notes, default_price_list) FROM stdin;
6bc5a637-df3e-4b09-b6b1-f82e28be9364	ad434e3f-b929-4ff4-a80d-11feac16b136	409ac438-b74f-465e-8aff-92fde52d70c3	t	2026-03-27 01:55:37.068	\N		A
\.


--
-- TOC entry 3926 (class 0 OID 17174)
-- Dependencies: 252
-- Data for Name: manufacturer_distributor_allowed_price_lists; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.manufacturer_distributor_allowed_price_lists (id, tenant_id, distributor_id, price_list_type, is_default, active, granted_at) FROM stdin;
\.


--
-- TOC entry 3927 (class 0 OID 17184)
-- Dependencies: 253
-- Data for Name: manufacturer_distributor_discounts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.manufacturer_distributor_discounts (id, tenant_id, distributor_id, discount_percent, scope, product_line_id, product_id, active, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 3904 (class 0 OID 16585)
-- Dependencies: 230
-- Data for Name: openings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.openings (id, project_version_id, wall_id, type, position_x, width, height) FROM stdin;
\.


--
-- TOC entry 3905 (class 0 OID 16590)
-- Dependencies: 231
-- Data for Name: placements; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.placements (id, project_version_id, room_id, product_id, pos_x, pos_y, pos_z, rot_x, rot_y, rot_z) FROM stdin;
gi096icyq	7550be06-3a79-4ef3-b99a-6c0d94109928	\N	fb2a964a-2c4b-4521-9515-f4c734e8565c	0	0	0	0	0	0
kpeu51fed	7550be06-3a79-4ef3-b99a-6c0d94109928	\N	abb900bc-ac69-43f5-a10d-54c0fee97a29	0	0	0	0	0	0
y9mkz0hgt	7550be06-3a79-4ef3-b99a-6c0d94109928	\N	abb900bc-ac69-43f5-a10d-54c0fee97a29	0.5	0	0.5	0	0	0
j3bninyzr	df56185e-e19b-423f-92c9-39694c3b92af	\N	fb2a964a-2c4b-4521-9515-f4c734e8565c	3.25	0	0.375	0	0	0
3pqcwf7ug	df56185e-e19b-423f-92c9-39694c3b92af	\N	abb900bc-ac69-43f5-a10d-54c0fee97a29	3.25	0	1.625	0	0	0
omxz9aq6u	df56185e-e19b-423f-92c9-39694c3b92af	\N	abb900bc-ac69-43f5-a10d-54c0fee97a29	3.75	0	0.875	0	0	0
item1	4579730a-28a9-42df-ad19-28a27cc8bb99	\N	prod1	0	0	0	0	0	0
12l8axb4b	4d4b962f-9610-4c6f-b2ba-8a465e951e39	\N	1a8df8c7-601e-44fb-9037-82c7adf63b60	0	0	0	0	0	0
it10tugry	b0d97be3-b404-4454-844e-88e740f726f3	\N	fb2a964a-2c4b-4521-9515-f4c734e8565c	0	0	0	0	0	0
y1rg0kyct	f736d976-4d37-4190-811b-fb7b75b6e9a4	\N	1a8df8c7-601e-44fb-9037-82c7adf63b60	0	0	0	0	0	0
sm32nflqn	f736d976-4d37-4190-811b-fb7b75b6e9a4	\N	fb2a964a-2c4b-4521-9515-f4c734e8565c	0	0	0	0	0	0
jhfrfuf0r	94235198-f6f5-424c-8433-5da58646cd48	\N	705bc497-70b8-4c51-ab25-340efcb1b26a	0	0	0	0	0	0
g0st8n9oi	9c0f1ad7-0e50-4593-808f-d77163088626	\N	a0244668-d009-42cf-a2e3-16e02a19e6aa	0	0	0	0	0	0
\.


--
-- TOC entry 3906 (class 0 OID 16595)
-- Dependencies: 232
-- Data for Name: platform_users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.platform_users (id, email, password_hash, first_name, last_name, role, status, preferences, created_at, updated_at) FROM stdin;
00d6c278-f539-4a6c-9ca2-1ac75cb8a8ff	xocotzin@xlayout.io	$2a$10$N9jUJRnnhU3jM0JbFt8PguWXip71k6yvBtGCPNeIQV5.ojlkU5.h.	Xocotzin	Platform	PLATFORM_OWNER	ACTIVE	\N	2026-03-25 04:23:37.684	2026-03-27 01:53:46.88
\.


--
-- TOC entry 3907 (class 0 OID 16603)
-- Dependencies: 233
-- Data for Name: price_list_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.price_list_items (price_list_id, product_id_legacy, price) FROM stdin;
\.


--
-- TOC entry 3908 (class 0 OID 16608)
-- Dependencies: 234
-- Data for Name: price_lists; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.price_lists (id, name, currency, "createdAt") FROM stdin;
\.


--
-- TOC entry 3909 (class 0 OID 16615)
-- Dependencies: 235
-- Data for Name: product_assets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_assets (id, tenant_id, product_id, "assetType", file_url, thumbnail_url, footprint_2d_url, model_3d_url, original_file_url, original_format, conversion_status, conversion_error, metadata, created_at) FROM stdin;
6fd56ee1-efa5-44b3-8cc3-0fa16d2ec8f5	ad434e3f-b929-4ff4-a80d-11feac16b136	705bc497-70b8-4c51-ab25-340efcb1b26a	model_3d	\N	\N	\N	/storage/converted/6b3758e0-67c6-451f-818e-c938c02f0580.glb	/storage/uploads/f21961ae-fb62-46d3-a936-3ca480a1fadb.obj	obj	validated	\N	{"materials": 1, "triangles": 40728, "validation": "warning", "boundingBox": {"max": [0.5052420682215992, 0.7394428030406789, 0.304865394551872], "min": [-0.3154240733886066, 0.000994644281507252, -0.4799870735907856], "depth": 0.7849, "width": 0.8207, "height": 0.7384}, "convertedAt": "2026-03-28T06:05:13.971Z", "orientation": {"status": "ok", "centered": true, "warnings": [], "floorAligned": true}, "dracoEnabled": true, "normalization": {"normalized": true, "finalMaxDim": 0.8205659866333008, "detectedUnit": "cm", "scaleApplied": 0.01, "originalMaxDim": 82.05659866333008}, "originalFormat": "obj", "originalSizeMb": 6.1741, "optimizedSizeMb": 0.3275, "compressionRatio": 94.7, "originalSizeBytes": 6474010, "optimizedSizeBytes": 343400, "validationWarnings": ["40,728 triángulos — recomendado < 10K"]}	2026-03-28 05:02:41.567
9ba534d0-f294-4daa-a234-b41c936d62c3	ad434e3f-b929-4ff4-a80d-11feac16b136	8a291cf9-eb81-4404-a35c-0a3859efa369	model_3d	\N	\N	\N	/storage/converted/60f5ec6c-3580-4faf-b17c-1cce9821663d.glb	/storage/uploads/90ef11d4-63cc-4784-8d52-a7e2d3e9730a.stl	stl	validated	\N	{"materials": 1, "triangles": 76503, "validation": "warning", "boundingBox": {"max": [0.3801203373715304, 0.4674586916501066, 1.808882958843463], "min": [-0.0001102756998466871, -0.0001102756998466871, 0.002015616855494437], "depth": 1.8069, "width": 0.3802, "height": 0.4676}, "convertedAt": "2026-03-30T21:00:06.130Z", "orientation": {"status": "warning", "centered": false, "warnings": ["Modelo descentrado (centro: X=0.190, Z=0.905)"], "floorAligned": true}, "dracoEnabled": true, "normalization": {"meshMerged": false, "normalized": false, "finalMaxDim": 1.806646790588275, "detectedUnit": "m", "scaleApplied": 1, "meshCountAfter": 1, "nodeCountAfter": 2, "originalMaxDim": 1.806646790588275, "meshCountBefore": 1, "nodeCountBefore": 2, "drawCallReduction": "N/A (ya optimizado)"}, "originalFormat": "stl", "originalSizeMb": 3.6486, "optimizedSizeMb": 0.2828, "compressionRatio": 92.2, "originalSizeBytes": 3825834, "optimizedSizeBytes": 296576, "validationWarnings": ["76,503 triángulos — recomendado < 10K", "Modelo descentrado (centro: X=0.190, Z=0.905)"]}	2026-03-30 21:00:02.815
ae8cd24c-3008-4a1c-8092-e72fcf435acd	ad434e3f-b929-4ff4-a80d-11feac16b136	\N	model_3d	\N	\N	\N	/storage/converted/4ff138ed-f726-478d-b010-1e1e5f881c75.glb	/storage/uploads/a66a1a6f-9ac1-4dbb-b355-f806a2d1bfab.obj	obj	validated	\N	{"materials": 1, "triangles": 40728, "validation": "warning", "boundingBox": {"max": [0.5052420682215992, 0.7394428030406789, 0.304865394551872], "min": [-0.3154240733886066, 0.000994644281507252, -0.4799870735907856], "depth": 0.7849, "width": 0.8207, "height": 0.7384}, "convertedAt": "2026-03-28T15:02:55.979Z", "orientation": {"status": "ok", "centered": true, "warnings": [], "floorAligned": true}, "dracoEnabled": true, "normalization": {"normalized": true, "finalMaxDim": 0.8205659866333008, "detectedUnit": "cm", "scaleApplied": 0.01, "originalMaxDim": 82.05659866333008}, "originalFormat": "obj", "originalSizeMb": 6.1741, "optimizedSizeMb": 0.3275, "compressionRatio": 94.7, "originalSizeBytes": 6474010, "optimizedSizeBytes": 343400, "validationWarnings": ["40,728 triángulos — recomendado < 10K"]}	2026-03-28 15:02:53.546
ceb86240-7132-4477-b836-d5eb719a2a18	ad434e3f-b929-4ff4-a80d-11feac16b136	e70096db-3db2-4fc3-a7c4-cfd2028cb73a	model_3d	\N	\N	\N	/storage/converted/603eb681-2a10-4379-81ba-3c6f00fa606b.glb	/storage/uploads/8ec56d82-18f6-4f42-8930-431e92776767.obj	obj	validated	\N	{"materials": 1, "triangles": 83988, "validation": "warning", "boundingBox": {"max": [0.8626623977444836, 1.795529457938412, 0.01058738534373727], "min": [-0.004609407123664512, -0.005052798522490425, -0.8566844195244109], "depth": 0.8673, "width": 0.8673, "height": 1.8006}, "convertedAt": "2026-03-30T21:32:52.457Z", "orientation": {"status": "warning", "centered": false, "warnings": ["Modelo descentrado (centro: X=0.429, Z=-0.423)"], "floorAligned": true}, "dracoEnabled": true, "normalization": {"meshMerged": true, "normalized": true, "finalMaxDim": 1.800420043945313, "detectedUnit": "mm", "scaleApplied": 0.001, "meshCountAfter": 2, "nodeCountAfter": 2, "originalMaxDim": 1800.420043945312, "meshCountBefore": 6217, "nodeCountBefore": 6218, "drawCallReduction": "6217 → 2 (-100%)"}, "originalFormat": "obj", "originalSizeMb": 14.1911, "optimizedSizeMb": 0.3892, "compressionRatio": 97.3, "originalSizeBytes": 14880486, "optimizedSizeBytes": 408136, "validationWarnings": ["83,988 triángulos — recomendado < 10K", "Modelo descentrado (centro: X=0.429, Z=-0.423)"]}	2026-03-30 20:48:37.888
ffdf8dd8-3a9b-4755-8f71-6bd9f2bf2ff7	ad434e3f-b929-4ff4-a80d-11feac16b136	\N	model_3d	\N	\N	\N	\N	/storage/uploads/d904907d-7b40-4fbd-8ed2-f2c67d6266ae.skp	skp	error	Pipeline SKP → GLB falló: Command failed: blender --background --python /app/scripts/skp_convert.py -- /app/storage/uploads/d904907d-7b40-4fbd-8ed2-f2c67d6266ae.skp /app/storage/converted/c07f599f-5e32-432f-9dbc-d1b5b46dcc8e_raw.glb\n. Si el error persiste, exporta el modelo como OBJ o FBX desde SketchUp.	{"failedAt": "2026-03-30T21:07:37.463Z", "errorType": "skp_conversion", "originalFormat": "skp", "originalSizeMb": 0, "originalSizeBytes": 13}	2026-03-30 20:38:46.521
\.


--
-- TOC entry 3910 (class 0 OID 16622)
-- Dependencies: 236
-- Data for Name: product_categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_categories (id, tenant_id, name, slug, parent_id, active) FROM stdin;
b1c32b8f-7e94-427e-80aa-66a5fcdc2c27	843c9ed9-5fce-4111-9839-34949786bed8	Almacenamiento	almacenamiento	\N	t
15017834-be2a-4479-ac58-11fbe2275bce	843c9ed9-5fce-4111-9839-34949786bed8	Mobiliario	mobiliario	\N	t
b7c9f6df-ec51-4fd1-a7c3-5b12acae225a	ad434e3f-b929-4ff4-a80d-11feac16b136	MESAS	mesas	\N	t
60fe4a3f-fac0-4c98-8875-dfb56b9d3cd4	ad434e3f-b929-4ff4-a80d-11feac16b136	LATERALES	laterales	\N	t
c1efe4aa-f5e3-4a5a-86ad-4c41a98d6945	ad434e3f-b929-4ff4-a80d-11feac16b136	MESAS BENCH	mesas-bench	\N	t
99fef396-baf7-45da-a243-4a3e3c766137	ad434e3f-b929-4ff4-a80d-11feac16b136	MESAS YOGUI	mesas-yogui	\N	t
\.


--
-- TOC entry 3911 (class 0 OID 16628)
-- Dependencies: 237
-- Data for Name: product_conditions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_conditions (id, tenant_id, product_id, line_id, condition_type, description, metadata, active, created_at) FROM stdin;
\.


--
-- TOC entry 3912 (class 0 OID 16635)
-- Dependencies: 238
-- Data for Name: product_lines; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_lines (id, tenant_id, name, slug, category, description, active, created_at, updated_at) FROM stdin;
05df24a7-3b52-4460-94b0-3b53ee84cfca	ad434e3f-b929-4ff4-a80d-11feac16b136	OFFIHO BLACK	offiho-black	\N		t	2026-03-28 05:01:28.069	2026-03-28 05:01:28.069
6ad8a902-6241-4b97-9044-54bc7b53753d	843c9ed9-5fce-4111-9839-34949786bed8	Lockers Test	lockers-test	\N	\N	t	2026-03-30 03:33:02.299	2026-03-30 03:33:02.299
82ca08f5-d107-4477-b63b-9a09417bc60d	843c9ed9-5fce-4111-9839-34949786bed8	Escritorios Test	escritorios-test	\N	\N	t	2026-03-30 03:33:02.394	2026-03-30 03:33:02.394
3e80c50b-e8ee-4014-94f5-e951cb4b724a	843c9ed9-5fce-4111-9839-34949786bed8	Sillas Test	sillas-test	\N	\N	t	2026-03-30 03:33:02.483	2026-03-30 03:33:02.483
417393ce-4f25-4fad-8354-adb71a1bc9f9	ad434e3f-b929-4ff4-a80d-11feac16b136	TERRA	terra	\N	\N	t	2026-03-30 22:21:29.612	2026-03-30 22:21:29.612
\.


--
-- TOC entry 3913 (class 0 OID 16642)
-- Dependencies: 239
-- Data for Name: product_prices; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_prices (id, tenant_id, product_id, price_type, currency, base_price, active, valid_from, valid_to, metadata, created_at, updated_at, variant_id) FROM stdin;
c2eed6fb-fc62-4839-ac44-07e5b3682649	ad434e3f-b929-4ff4-a80d-11feac16b136	705bc497-70b8-4c51-ab25-340efcb1b26a	A	MXN	2323.00	t	\N	\N	\N	2026-03-28 05:02:39.487	2026-03-28 05:47:33.661	\N
b41d4bf7-b404-4907-8758-c33e402eed4f	ad434e3f-b929-4ff4-a80d-11feac16b136	8a291cf9-eb81-4404-a35c-0a3859efa369	A	MXN	2323.00	t	\N	\N	\N	2026-03-28 15:02:51.733	2026-03-28 15:02:51.733	\N
d33f4667-14f8-48fb-88da-ea0f6890fcdc	ad434e3f-b929-4ff4-a80d-11feac16b136	8a291cf9-eb81-4404-a35c-0a3859efa369	B	MXN	-0.01	t	\N	\N	\N	2026-03-28 15:02:51.733	2026-03-28 15:02:51.733	\N
5f373305-7abf-4bc9-8355-e346752378df	843c9ed9-5fce-4111-9839-34949786bed8	214c5e59-79a2-4841-868d-a7f14f72ad99	B	MXN	4050.00	t	\N	\N	\N	2026-03-30 03:33:02.35	2026-03-30 03:33:12.671	\N
f8b20a26-9798-4856-9d99-9abd4c730635	843c9ed9-5fce-4111-9839-34949786bed8	214c5e59-79a2-4841-868d-a7f14f72ad99	C	MXN	3600.00	t	\N	\N	\N	2026-03-30 03:33:02.361	2026-03-30 03:33:12.68	\N
cb51c0d7-fa60-4aa5-89d7-9eeb334297da	843c9ed9-5fce-4111-9839-34949786bed8	214c5e59-79a2-4841-868d-a7f14f72ad99	D	MXN	3150.00	t	\N	\N	\N	2026-03-30 03:33:02.37	2026-03-30 03:33:12.687	\N
19b67d28-4089-4747-89e8-790eb8a0c7b8	843c9ed9-5fce-4111-9839-34949786bed8	214c5e59-79a2-4841-868d-a7f14f72ad99	E	MXN	2700.00	t	\N	\N	\N	2026-03-30 03:33:02.382	2026-03-30 03:33:12.694	\N
add57e20-7f38-4466-9553-85bdc4bccef1	843c9ed9-5fce-4111-9839-34949786bed8	2815adb2-fea4-49b8-b9c9-1d9998bc0691	A	MXN	8500.00	t	\N	\N	\N	2026-03-30 03:33:02.425	2026-03-30 03:33:12.705	\N
b324419b-5681-46e1-907d-10824092d725	843c9ed9-5fce-4111-9839-34949786bed8	2815adb2-fea4-49b8-b9c9-1d9998bc0691	B	MXN	7650.00	t	\N	\N	\N	2026-03-30 03:33:02.441	2026-03-30 03:33:12.711	\N
93b75fc9-0bbd-4fdd-ace0-b4a233244fb9	843c9ed9-5fce-4111-9839-34949786bed8	2815adb2-fea4-49b8-b9c9-1d9998bc0691	C	MXN	6800.00	t	\N	\N	\N	2026-03-30 03:33:02.457	2026-03-30 03:33:12.718	\N
93b5076d-d766-4085-b77f-fe762aba1c19	843c9ed9-5fce-4111-9839-34949786bed8	2815adb2-fea4-49b8-b9c9-1d9998bc0691	D	MXN	5950.00	t	\N	\N	\N	2026-03-30 03:33:02.468	2026-03-30 03:33:12.725	\N
0368e78e-0f90-45d6-a053-760820cec933	843c9ed9-5fce-4111-9839-34949786bed8	2815adb2-fea4-49b8-b9c9-1d9998bc0691	E	MXN	5100.00	t	\N	\N	\N	2026-03-30 03:33:02.478	2026-03-30 03:33:12.732	\N
fc011a6c-a9aa-4dbd-bc63-79337c7e2a34	843c9ed9-5fce-4111-9839-34949786bed8	78ce3850-8629-4e56-94ad-61c0f69d1b91	A	MXN	12000.00	t	\N	\N	\N	2026-03-30 03:33:02.5	2026-03-30 03:33:12.742	\N
c08b4265-64e2-48a4-a7e8-b2bfe8555812	843c9ed9-5fce-4111-9839-34949786bed8	78ce3850-8629-4e56-94ad-61c0f69d1b91	B	MXN	10800.00	t	\N	\N	\N	2026-03-30 03:33:02.508	2026-03-30 03:33:12.749	\N
27075682-d728-41f4-bf4c-6ee0e0995d10	843c9ed9-5fce-4111-9839-34949786bed8	78ce3850-8629-4e56-94ad-61c0f69d1b91	C	MXN	9600.00	t	\N	\N	\N	2026-03-30 03:33:02.519	2026-03-30 03:33:12.756	\N
b290f610-4b2a-4729-aac7-75e30d8220c8	843c9ed9-5fce-4111-9839-34949786bed8	78ce3850-8629-4e56-94ad-61c0f69d1b91	D	MXN	8400.00	t	\N	\N	\N	2026-03-30 03:33:02.528	2026-03-30 03:33:12.764	\N
20e78f31-e1cd-4697-82d3-98ea3f3e27e5	843c9ed9-5fce-4111-9839-34949786bed8	78ce3850-8629-4e56-94ad-61c0f69d1b91	E	MXN	7200.00	t	\N	\N	\N	2026-03-30 03:33:02.538	2026-03-30 03:33:12.77	\N
89821fc3-10fd-4b2d-9de0-ccda47edcaa1	843c9ed9-5fce-4111-9839-34949786bed8	214c5e59-79a2-4841-868d-a7f14f72ad99	B	MXN	4050.00	t	\N	\N	\N	2026-03-30 03:33:02.57	2026-03-30 03:33:12.794	b4e77f71-b6c8-4630-a18e-d2d1862ea653
ecf0d94c-e9ac-4523-b680-85e1c66d849c	843c9ed9-5fce-4111-9839-34949786bed8	214c5e59-79a2-4841-868d-a7f14f72ad99	C	MXN	3600.00	t	\N	\N	\N	2026-03-30 03:33:02.579	2026-03-30 03:33:12.801	b4e77f71-b6c8-4630-a18e-d2d1862ea653
2d01a6be-0e2c-4ed7-8923-630f46b3702b	843c9ed9-5fce-4111-9839-34949786bed8	214c5e59-79a2-4841-868d-a7f14f72ad99	D	MXN	3150.00	t	\N	\N	\N	2026-03-30 03:33:02.589	2026-03-30 03:33:12.807	b4e77f71-b6c8-4630-a18e-d2d1862ea653
28fab831-b546-410b-b319-e1627628814f	843c9ed9-5fce-4111-9839-34949786bed8	214c5e59-79a2-4841-868d-a7f14f72ad99	E	MXN	2700.00	t	\N	\N	\N	2026-03-30 03:33:02.597	2026-03-30 03:33:12.815	b4e77f71-b6c8-4630-a18e-d2d1862ea653
b6a72fb5-d2a8-475f-bc28-fe95ee2b120c	843c9ed9-5fce-4111-9839-34949786bed8	214c5e59-79a2-4841-868d-a7f14f72ad99	A	MXN	8200.00	t	\N	\N	\N	2026-03-30 03:33:02.615	2026-03-30 03:33:12.828	602404d0-a22f-43a7-943b-15b9b2f5f642
cee36cb1-7790-46f8-ac8a-397292bba8ee	843c9ed9-5fce-4111-9839-34949786bed8	214c5e59-79a2-4841-868d-a7f14f72ad99	B	MXN	7380.00	t	\N	\N	\N	2026-03-30 03:33:02.624	2026-03-30 03:33:12.835	602404d0-a22f-43a7-943b-15b9b2f5f642
15bd0646-d994-48cc-bba6-e53207ec7b58	843c9ed9-5fce-4111-9839-34949786bed8	214c5e59-79a2-4841-868d-a7f14f72ad99	C	MXN	6560.00	t	\N	\N	\N	2026-03-30 03:33:02.634	2026-03-30 03:33:12.842	602404d0-a22f-43a7-943b-15b9b2f5f642
99d0216a-8fc1-4880-9b62-c9e95e1c4191	843c9ed9-5fce-4111-9839-34949786bed8	214c5e59-79a2-4841-868d-a7f14f72ad99	D	MXN	5740.00	t	\N	\N	\N	2026-03-30 03:33:02.645	2026-03-30 03:33:12.849	602404d0-a22f-43a7-943b-15b9b2f5f642
8c626305-144d-459f-b269-a0c3fc4d17fd	843c9ed9-5fce-4111-9839-34949786bed8	214c5e59-79a2-4841-868d-a7f14f72ad99	E	MXN	4920.00	t	\N	\N	\N	2026-03-30 03:33:02.653	2026-03-30 03:33:12.857	602404d0-a22f-43a7-943b-15b9b2f5f642
026937d6-6da3-4023-9046-4462bc49abc4	843c9ed9-5fce-4111-9839-34949786bed8	214c5e59-79a2-4841-868d-a7f14f72ad99	A	MXN	4700.00	t	\N	\N	\N	2026-03-30 03:33:02.665	2026-03-30 03:33:12.87	99d1bd58-a6a1-4595-8629-f2fbaf118d1c
719aee3f-d6cb-41d3-ae24-82ff7265825e	843c9ed9-5fce-4111-9839-34949786bed8	214c5e59-79a2-4841-868d-a7f14f72ad99	B	MXN	4230.00	t	\N	\N	\N	2026-03-30 03:33:02.673	2026-03-30 03:33:12.877	99d1bd58-a6a1-4595-8629-f2fbaf118d1c
3004f755-aff7-4461-8735-d98c741d9e51	843c9ed9-5fce-4111-9839-34949786bed8	214c5e59-79a2-4841-868d-a7f14f72ad99	C	MXN	3760.00	t	\N	\N	\N	2026-03-30 03:33:02.682	2026-03-30 03:33:12.884	99d1bd58-a6a1-4595-8629-f2fbaf118d1c
68a29993-5cf6-480e-99a1-aa41eb45fc56	843c9ed9-5fce-4111-9839-34949786bed8	214c5e59-79a2-4841-868d-a7f14f72ad99	D	MXN	3290.00	t	\N	\N	\N	2026-03-30 03:33:02.689	2026-03-30 03:33:12.89	99d1bd58-a6a1-4595-8629-f2fbaf118d1c
004ec3b5-6d6d-40af-8d9a-8900e002c47e	843c9ed9-5fce-4111-9839-34949786bed8	214c5e59-79a2-4841-868d-a7f14f72ad99	E	MXN	2820.00	t	\N	\N	\N	2026-03-30 03:33:02.697	2026-03-30 03:33:12.896	99d1bd58-a6a1-4595-8629-f2fbaf118d1c
05844305-66e0-40e2-9ae8-811b26f865dd	843c9ed9-5fce-4111-9839-34949786bed8	2815adb2-fea4-49b8-b9c9-1d9998bc0691	A	MXN	7800.00	t	\N	\N	\N	2026-03-30 03:33:02.713	2026-03-30 03:33:12.908	0310293e-98c6-4d29-b4c3-d8e8ebbd8c45
bf60f4f6-774d-4b1e-9567-1ffad98f7cf8	843c9ed9-5fce-4111-9839-34949786bed8	2815adb2-fea4-49b8-b9c9-1d9998bc0691	B	MXN	7020.00	t	\N	\N	\N	2026-03-30 03:33:02.722	2026-03-30 03:33:12.914	0310293e-98c6-4d29-b4c3-d8e8ebbd8c45
2c60fe71-123f-45f3-ad19-dc7ba6c39d36	843c9ed9-5fce-4111-9839-34949786bed8	2815adb2-fea4-49b8-b9c9-1d9998bc0691	C	MXN	6240.00	t	\N	\N	\N	2026-03-30 03:33:02.729	2026-03-30 03:33:12.92	0310293e-98c6-4d29-b4c3-d8e8ebbd8c45
63382fd0-70d0-417b-9ecf-4368a1e54676	843c9ed9-5fce-4111-9839-34949786bed8	2815adb2-fea4-49b8-b9c9-1d9998bc0691	D	MXN	5460.00	t	\N	\N	\N	2026-03-30 03:33:02.737	2026-03-30 03:33:12.925	0310293e-98c6-4d29-b4c3-d8e8ebbd8c45
ee70e187-9ee9-42a6-97b1-430ad8b1d96b	843c9ed9-5fce-4111-9839-34949786bed8	2815adb2-fea4-49b8-b9c9-1d9998bc0691	E	MXN	4680.00	t	\N	\N	\N	2026-03-30 03:33:02.747	2026-03-30 03:33:12.93	0310293e-98c6-4d29-b4c3-d8e8ebbd8c45
a2dd1a70-d080-48f7-9925-ecd4a07a6022	843c9ed9-5fce-4111-9839-34949786bed8	2815adb2-fea4-49b8-b9c9-1d9998bc0691	A	MXN	9500.00	t	\N	\N	\N	2026-03-30 03:33:02.764	2026-03-30 03:33:12.942	027a9de0-b4f5-482d-9a50-c96c38eb155f
fb1c25f7-b7e7-4c88-8c55-08e67ed6a5d6	843c9ed9-5fce-4111-9839-34949786bed8	2815adb2-fea4-49b8-b9c9-1d9998bc0691	B	MXN	8550.00	t	\N	\N	\N	2026-03-30 03:33:02.771	2026-03-30 03:33:12.947	027a9de0-b4f5-482d-9a50-c96c38eb155f
f0f6c4fd-24bf-49a7-bdcf-6033dc3c561a	843c9ed9-5fce-4111-9839-34949786bed8	214c5e59-79a2-4841-868d-a7f14f72ad99	A	MXN	4500.00	t	\N	\N	\N	2026-03-30 03:33:02.335	2026-03-30 03:33:12.664	\N
b25bd721-4a6b-44ee-8f31-fef2d38723ff	843c9ed9-5fce-4111-9839-34949786bed8	214c5e59-79a2-4841-868d-a7f14f72ad99	A	MXN	4500.00	t	\N	\N	\N	2026-03-30 03:33:02.561	2026-03-30 03:33:12.788	b4e77f71-b6c8-4630-a18e-d2d1862ea653
5619465f-19ac-4429-8b46-12a21948e80d	843c9ed9-5fce-4111-9839-34949786bed8	2815adb2-fea4-49b8-b9c9-1d9998bc0691	C	MXN	7600.00	t	\N	\N	\N	2026-03-30 03:33:02.778	2026-03-30 03:33:12.954	027a9de0-b4f5-482d-9a50-c96c38eb155f
12a75a66-229c-45e5-bb11-89fb74c8a1f7	843c9ed9-5fce-4111-9839-34949786bed8	2815adb2-fea4-49b8-b9c9-1d9998bc0691	D	MXN	6650.00	t	\N	\N	\N	2026-03-30 03:33:02.786	2026-03-30 03:33:12.961	027a9de0-b4f5-482d-9a50-c96c38eb155f
35bf3bd3-27c3-4dda-bda8-f0cb193056d0	843c9ed9-5fce-4111-9839-34949786bed8	2815adb2-fea4-49b8-b9c9-1d9998bc0691	E	MXN	5700.00	t	\N	\N	\N	2026-03-30 03:33:02.793	2026-03-30 03:33:12.967	027a9de0-b4f5-482d-9a50-c96c38eb155f
ed7adcae-74e5-44de-a516-da18f5ab13bb	ad434e3f-b929-4ff4-a80d-11feac16b136	9a0be7a1-0438-43d4-a43a-13f65ca12b09	B	MXN	3233.27	t	\N	\N	\N	2026-03-30 22:21:29.649	2026-03-30 22:21:32.57	\N
7ac2273a-7eae-45cb-8a09-528b4e16b1e0	ad434e3f-b929-4ff4-a80d-11feac16b136	9a0be7a1-0438-43d4-a43a-13f65ca12b09	C	MXN	3394.92	t	\N	\N	\N	2026-03-30 22:21:29.656	2026-03-30 22:21:32.576	\N
629d9bbc-200e-49cf-b056-274c879e68b3	ad434e3f-b929-4ff4-a80d-11feac16b136	9a0be7a1-0438-43d4-a43a-13f65ca12b09	D	MXN	3564.64	t	\N	\N	\N	2026-03-30 22:21:29.663	2026-03-30 22:21:32.584	\N
eaffd5bc-db57-4ff0-9439-87a706248f2a	ad434e3f-b929-4ff4-a80d-11feac16b136	a18ee5db-cad6-45cb-a472-37975cdecc02	A	MXN	3410.52	t	\N	\N	\N	2026-03-30 22:21:29.676	2026-03-30 22:21:32.606	\N
9a305b16-d4b3-4c11-8682-005c7190aa6f	ad434e3f-b929-4ff4-a80d-11feac16b136	a18ee5db-cad6-45cb-a472-37975cdecc02	B	MXN	3581.03	t	\N	\N	\N	2026-03-30 22:21:29.684	2026-03-30 22:21:32.614	\N
eeabd8fa-6f2e-4a3a-b6c0-926744a4f90f	ad434e3f-b929-4ff4-a80d-11feac16b136	a18ee5db-cad6-45cb-a472-37975cdecc02	C	MXN	3760.06	t	\N	\N	\N	2026-03-30 22:21:29.692	2026-03-30 22:21:32.637	\N
5bb1e552-a108-4b31-8ea8-3f52d6ff5b3c	ad434e3f-b929-4ff4-a80d-11feac16b136	a18ee5db-cad6-45cb-a472-37975cdecc02	D	MXN	3948.04	t	\N	\N	\N	2026-03-30 22:21:29.699	2026-03-30 22:21:32.646	\N
33867e81-79d8-44bb-a6d9-ad0b01ab4ef3	ad434e3f-b929-4ff4-a80d-11feac16b136	a65fd618-c46b-4f3a-89a5-016987a46e53	A	MXN	3095.86	t	\N	\N	\N	2026-03-30 22:21:29.712	2026-03-30 22:21:32.662	\N
cb990ceb-f2d7-44b7-9b48-ee7f3472557b	ad434e3f-b929-4ff4-a80d-11feac16b136	a65fd618-c46b-4f3a-89a5-016987a46e53	B	MXN	3250.65	t	\N	\N	\N	2026-03-30 22:21:29.72	2026-03-30 22:21:32.672	\N
e3b2eedf-fb90-4088-896d-11153bf3a878	ad434e3f-b929-4ff4-a80d-11feac16b136	a65fd618-c46b-4f3a-89a5-016987a46e53	C	MXN	3413.16	t	\N	\N	\N	2026-03-30 22:21:29.729	2026-03-30 22:21:32.682	\N
3e0bf630-5c39-4366-bbf9-fb9884cd191a	ad434e3f-b929-4ff4-a80d-11feac16b136	a65fd618-c46b-4f3a-89a5-016987a46e53	D	MXN	3583.78	t	\N	\N	\N	2026-03-30 22:21:29.738	2026-03-30 22:21:32.694	\N
375c8b73-0765-4ac4-af41-2d8309439b0a	ad434e3f-b929-4ff4-a80d-11feac16b136	8f35dd7b-cb84-4b7a-9c17-9de37fdbcf0c	A	MXN	3066.26	t	\N	\N	\N	2026-03-30 22:21:29.75	2026-03-30 22:21:32.709	\N
686a0da1-c9c0-42c6-9e55-0dd32f99a02b	ad434e3f-b929-4ff4-a80d-11feac16b136	8f35dd7b-cb84-4b7a-9c17-9de37fdbcf0c	B	MXN	3219.57	t	\N	\N	\N	2026-03-30 22:21:29.758	2026-03-30 22:21:32.718	\N
7f6249d4-aa4b-4dc7-aee5-39a6c9ee9911	ad434e3f-b929-4ff4-a80d-11feac16b136	8f35dd7b-cb84-4b7a-9c17-9de37fdbcf0c	C	MXN	3380.54	t	\N	\N	\N	2026-03-30 22:21:29.765	2026-03-30 22:21:32.728	\N
ca8aba25-015f-4aff-a3c4-899666e9b29e	ad434e3f-b929-4ff4-a80d-11feac16b136	8f35dd7b-cb84-4b7a-9c17-9de37fdbcf0c	D	MXN	3549.54	t	\N	\N	\N	2026-03-30 22:21:29.772	2026-03-30 22:21:32.739	\N
428b15e9-83d1-412b-b796-da434aea7cf8	ad434e3f-b929-4ff4-a80d-11feac16b136	ebef8308-ebb5-4b75-b25e-0d648cf244ec	A	MXN	2458.20	t	\N	\N	\N	2026-03-30 22:21:29.785	2026-03-30 22:21:32.761	\N
f97e9d2d-34b8-446a-a3f1-6f3bdca28d74	ad434e3f-b929-4ff4-a80d-11feac16b136	ebef8308-ebb5-4b75-b25e-0d648cf244ec	B	MXN	2581.10	t	\N	\N	\N	2026-03-30 22:21:29.792	2026-03-30 22:21:32.771	\N
c0d0306b-e5fa-41b2-b0ca-0df82616d5aa	ad434e3f-b929-4ff4-a80d-11feac16b136	ebef8308-ebb5-4b75-b25e-0d648cf244ec	C	MXN	2710.14	t	\N	\N	\N	2026-03-30 22:21:29.799	2026-03-30 22:21:32.781	\N
7e0ece44-9e40-4875-8e81-435fc4ac271b	ad434e3f-b929-4ff4-a80d-11feac16b136	ebef8308-ebb5-4b75-b25e-0d648cf244ec	D	MXN	2845.62	t	\N	\N	\N	2026-03-30 22:21:29.806	2026-03-30 22:21:32.792	\N
9acda08f-59b7-4c5f-9ad4-7883102bd5a3	ad434e3f-b929-4ff4-a80d-11feac16b136	f8c7e1aa-6839-4b19-b028-4f59d51bc095	B	MXN	2752.26	t	\N	\N	\N	2026-03-30 22:21:29.825	2026-03-30 22:21:32.819	\N
c58e4ea0-eaaf-4aab-b285-d3af7b8ebf53	ad434e3f-b929-4ff4-a80d-11feac16b136	f8c7e1aa-6839-4b19-b028-4f59d51bc095	C	MXN	2889.86	t	\N	\N	\N	2026-03-30 22:21:29.832	2026-03-30 22:21:32.831	\N
c8fa001c-7bee-41fd-8932-349a23f9d6af	ad434e3f-b929-4ff4-a80d-11feac16b136	f8c7e1aa-6839-4b19-b028-4f59d51bc095	D	MXN	3034.33	t	\N	\N	\N	2026-03-30 22:21:29.838	2026-03-30 22:21:32.843	\N
d02c5f20-494e-443b-a363-d1f8d35a7a47	ad434e3f-b929-4ff4-a80d-11feac16b136	be7e9360-211f-46a7-b1e6-9e5fa0d486e7	A	MXN	2463.89	t	\N	\N	\N	2026-03-30 22:21:29.849	2026-03-30 22:21:32.861	\N
f30458a8-0632-4304-9a24-023c811f46f0	ad434e3f-b929-4ff4-a80d-11feac16b136	be7e9360-211f-46a7-b1e6-9e5fa0d486e7	B	MXN	2587.08	t	\N	\N	\N	2026-03-30 22:21:29.855	2026-03-30 22:21:32.87	\N
6e3f86be-fbae-4bcd-a1c9-e7bc8634b889	ad434e3f-b929-4ff4-a80d-11feac16b136	be7e9360-211f-46a7-b1e6-9e5fa0d486e7	C	MXN	2716.42	t	\N	\N	\N	2026-03-30 22:21:29.861	2026-03-30 22:21:32.891	\N
149a816a-370e-4b00-89fb-6ac781c9e73f	ad434e3f-b929-4ff4-a80d-11feac16b136	be7e9360-211f-46a7-b1e6-9e5fa0d486e7	D	MXN	2852.22	t	\N	\N	\N	2026-03-30 22:21:29.867	2026-03-30 22:21:32.902	\N
242ddb64-9fa5-4d99-8c31-5772523eff38	ad434e3f-b929-4ff4-a80d-11feac16b136	b15298f9-bfa6-455f-8c61-b2dc71a0028e	A	MXN	2446.50	t	\N	\N	\N	2026-03-30 22:21:29.878	2026-03-30 22:21:32.92	\N
2d2e60e7-2b20-4186-86d9-471e06f2cabb	ad434e3f-b929-4ff4-a80d-11feac16b136	b15298f9-bfa6-455f-8c61-b2dc71a0028e	B	MXN	2568.82	t	\N	\N	\N	2026-03-30 22:21:29.887	2026-03-30 22:21:32.93	\N
832f6a6a-5a2e-4b45-a96f-57a2d4c1e0a5	ad434e3f-b929-4ff4-a80d-11feac16b136	b15298f9-bfa6-455f-8c61-b2dc71a0028e	C	MXN	2697.25	t	\N	\N	\N	2026-03-30 22:21:29.894	2026-03-30 22:21:32.946	\N
c6b67c37-a771-429a-985d-4b82996db632	ad434e3f-b929-4ff4-a80d-11feac16b136	b15298f9-bfa6-455f-8c61-b2dc71a0028e	D	MXN	2832.09	t	\N	\N	\N	2026-03-30 22:21:29.9	2026-03-30 22:21:32.955	\N
a30dd963-e59a-46b0-9fbf-a16bad9319a9	ad434e3f-b929-4ff4-a80d-11feac16b136	06c7a87d-5bbf-48ec-9a65-899b069cf396	A	MXN	2361.04	t	\N	\N	\N	2026-03-30 22:21:29.915	2026-03-30 22:21:32.974	\N
777ebd20-7651-4f33-aa98-509d607a2925	ad434e3f-b929-4ff4-a80d-11feac16b136	06c7a87d-5bbf-48ec-9a65-899b069cf396	B	MXN	2479.08	t	\N	\N	\N	2026-03-30 22:21:29.922	2026-03-30 22:21:32.985	\N
987f110b-8b6d-429a-afa6-8552f29e9c96	ad434e3f-b929-4ff4-a80d-11feac16b136	06c7a87d-5bbf-48ec-9a65-899b069cf396	C	MXN	2603.02	t	\N	\N	\N	2026-03-30 22:21:29.93	2026-03-30 22:21:32.994	\N
b7412c8f-5cd8-442d-a6e8-ee8f097f1973	ad434e3f-b929-4ff4-a80d-11feac16b136	06c7a87d-5bbf-48ec-9a65-899b069cf396	D	MXN	2733.16	t	\N	\N	\N	2026-03-30 22:21:29.938	2026-03-30 22:21:33.004	\N
5ac13f23-0536-440d-9294-0a5fee425471	ad434e3f-b929-4ff4-a80d-11feac16b136	37c02803-58c5-45c1-941a-e2bf55cc7a8d	A	MXN	2526.64	t	\N	\N	\N	2026-03-30 22:21:29.951	2026-03-30 22:21:33.023	\N
ab7bd419-637c-46e2-90e2-78f45f4dbef0	ad434e3f-b929-4ff4-a80d-11feac16b136	37c02803-58c5-45c1-941a-e2bf55cc7a8d	B	MXN	2652.96	t	\N	\N	\N	2026-03-30 22:21:29.959	2026-03-30 22:21:33.037	\N
01afcd43-deff-477e-96dc-4246d8879aed	ad434e3f-b929-4ff4-a80d-11feac16b136	37c02803-58c5-45c1-941a-e2bf55cc7a8d	C	MXN	2785.59	t	\N	\N	\N	2026-03-30 22:21:29.968	2026-03-30 22:21:33.049	\N
20a2ee73-a23d-4a6b-bb0f-46a97c29c2c0	ad434e3f-b929-4ff4-a80d-11feac16b136	74121cef-f590-4d31-a33e-32c92ef65fd8	A	MXN	2369.31	t	\N	\N	\N	2026-03-30 22:21:29.988	2026-03-30 22:21:33.082	\N
3d79c887-c05b-4476-8583-1cce3f8ecc35	ad434e3f-b929-4ff4-a80d-11feac16b136	74121cef-f590-4d31-a33e-32c92ef65fd8	B	MXN	2487.77	t	\N	\N	\N	2026-03-30 22:21:29.996	2026-03-30 22:21:33.093	\N
37bb8173-2018-4c2d-8cf3-23fbef9f66c7	ad434e3f-b929-4ff4-a80d-11feac16b136	74121cef-f590-4d31-a33e-32c92ef65fd8	C	MXN	2612.14	t	\N	\N	\N	2026-03-30 22:21:30.005	2026-03-30 22:21:33.107	\N
c80e7a19-c7b4-427d-945b-858985b7c27e	ad434e3f-b929-4ff4-a80d-11feac16b136	74121cef-f590-4d31-a33e-32c92ef65fd8	D	MXN	2742.73	t	\N	\N	\N	2026-03-30 22:21:30.013	2026-03-30 22:21:33.117	\N
49975666-d810-4184-9723-7ef722f20d54	ad434e3f-b929-4ff4-a80d-11feac16b136	6407104f-cf91-4ada-8daa-ba613ced763e	A	MXN	2354.51	t	\N	\N	\N	2026-03-30 22:21:30.025	2026-03-30 22:21:33.137	\N
b6c539c5-7a43-4eaa-b3a9-94a78a463dd9	ad434e3f-b929-4ff4-a80d-11feac16b136	6407104f-cf91-4ada-8daa-ba613ced763e	B	MXN	2472.23	t	\N	\N	\N	2026-03-30 22:21:30.032	2026-03-30 22:21:33.148	\N
e4852203-0202-4a3c-a40d-80490cbd6147	ad434e3f-b929-4ff4-a80d-11feac16b136	6407104f-cf91-4ada-8daa-ba613ced763e	C	MXN	2595.83	t	\N	\N	\N	2026-03-30 22:21:30.038	2026-03-30 22:21:33.157	\N
c359dc0e-0fdb-4802-870c-6a7772792559	ad434e3f-b929-4ff4-a80d-11feac16b136	6407104f-cf91-4ada-8daa-ba613ced763e	D	MXN	2725.61	t	\N	\N	\N	2026-03-30 22:21:30.044	2026-03-30 22:21:33.166	\N
c4ca26db-07dc-4b95-8e2d-02faaf8df7ae	ad434e3f-b929-4ff4-a80d-11feac16b136	93b0a71f-5e96-4ddb-b6bf-76ebd51d44eb	A	MXN	2444.29	t	\N	\N	\N	2026-03-30 22:21:30.056	2026-03-30 22:21:33.178	\N
77b42369-a433-46eb-b752-a1361e625b90	ad434e3f-b929-4ff4-a80d-11feac16b136	93b0a71f-5e96-4ddb-b6bf-76ebd51d44eb	B	MXN	2566.49	t	\N	\N	\N	2026-03-30 22:21:30.064	2026-03-30 22:21:33.186	\N
22db8db3-9d84-4066-91d3-e00cb2addbd6	ad434e3f-b929-4ff4-a80d-11feac16b136	93b0a71f-5e96-4ddb-b6bf-76ebd51d44eb	C	MXN	2694.81	t	\N	\N	\N	2026-03-30 22:21:30.072	2026-03-30 22:21:33.195	\N
d1bc9aed-b69e-4f39-86e2-b8f9e19ea864	ad434e3f-b929-4ff4-a80d-11feac16b136	93b0a71f-5e96-4ddb-b6bf-76ebd51d44eb	D	MXN	2829.54	t	\N	\N	\N	2026-03-30 22:21:30.079	2026-03-30 22:21:33.204	\N
799501ac-d4bc-404c-8dcc-84d1d08f7235	ad434e3f-b929-4ff4-a80d-11feac16b136	6671b2b0-0dd0-481f-92f9-1a8b63183027	A	MXN	2633.91	t	\N	\N	\N	2026-03-30 22:21:30.091	2026-03-30 22:21:33.222	\N
4a9d3f9e-cfd0-44c8-82ab-674e4f2ee9bc	ad434e3f-b929-4ff4-a80d-11feac16b136	6671b2b0-0dd0-481f-92f9-1a8b63183027	B	MXN	2765.59	t	\N	\N	\N	2026-03-30 22:21:30.098	2026-03-30 22:21:33.231	\N
31decd90-6f68-420b-a62b-caf89e6592a5	ad434e3f-b929-4ff4-a80d-11feac16b136	6671b2b0-0dd0-481f-92f9-1a8b63183027	C	MXN	2903.86	t	\N	\N	\N	2026-03-30 22:21:30.105	2026-03-30 22:21:33.24	\N
ac97d355-5330-482f-a120-ee29fae4cc86	ad434e3f-b929-4ff4-a80d-11feac16b136	6671b2b0-0dd0-481f-92f9-1a8b63183027	D	MXN	3049.05	t	\N	\N	\N	2026-03-30 22:21:30.114	2026-03-30 22:21:33.249	\N
1d4def56-0358-4d07-9688-b6781adb1c02	ad434e3f-b929-4ff4-a80d-11feac16b136	87dd282b-52da-4ff9-8998-5b825b13c5c9	A	MXN	2462.98	t	\N	\N	\N	2026-03-30 22:21:30.129	2026-03-30 22:21:33.264	\N
736010ba-4607-4bed-becd-f5592f8737fc	ad434e3f-b929-4ff4-a80d-11feac16b136	87dd282b-52da-4ff9-8998-5b825b13c5c9	C	MXN	2715.42	t	\N	\N	\N	2026-03-30 22:21:30.145	2026-03-30 22:21:33.287	\N
e8eb0689-092b-4714-86a0-651a330a40ea	ad434e3f-b929-4ff4-a80d-11feac16b136	87dd282b-52da-4ff9-8998-5b825b13c5c9	D	MXN	2851.19	t	\N	\N	\N	2026-03-30 22:21:30.153	2026-03-30 22:21:33.296	\N
fd3fc286-bd31-4898-be10-c44ecb64a8bf	ad434e3f-b929-4ff4-a80d-11feac16b136	879eda6d-128f-4680-b285-53bab6334a3e	A	MXN	2440.99	t	\N	\N	\N	2026-03-30 22:21:30.166	2026-03-30 22:21:33.311	\N
06e5ed7f-7791-49c9-b164-33655a6c9b90	ad434e3f-b929-4ff4-a80d-11feac16b136	879eda6d-128f-4680-b285-53bab6334a3e	B	MXN	2563.03	t	\N	\N	\N	2026-03-30 22:21:30.173	2026-03-30 22:21:33.319	\N
669343f1-fd1d-48eb-93ee-8dbe5ee35f06	ad434e3f-b929-4ff4-a80d-11feac16b136	879eda6d-128f-4680-b285-53bab6334a3e	C	MXN	2691.17	t	\N	\N	\N	2026-03-30 22:21:30.181	2026-03-30 22:21:33.327	\N
85da73a8-a1b4-4e4a-96e9-1e8ba85d87aa	ad434e3f-b929-4ff4-a80d-11feac16b136	879eda6d-128f-4680-b285-53bab6334a3e	D	MXN	2825.72	t	\N	\N	\N	2026-03-30 22:21:30.188	2026-03-30 22:21:33.334	\N
bd54123e-0c1d-447f-90e0-eafc715dc773	ad434e3f-b929-4ff4-a80d-11feac16b136	ada8d0ac-6b3d-46a8-ac98-8a1b1192a7ae	A	MXN	3295.91	t	\N	\N	\N	2026-03-30 22:21:30.205	2026-03-30 22:21:33.35	\N
124085d1-b0ad-4983-a3be-1b7e878d3649	ad434e3f-b929-4ff4-a80d-11feac16b136	ada8d0ac-6b3d-46a8-ac98-8a1b1192a7ae	B	MXN	3460.69	t	\N	\N	\N	2026-03-30 22:21:30.214	2026-03-30 22:21:33.361	\N
46d392fe-31dc-4ee4-9398-4fadb70fd6bd	ad434e3f-b929-4ff4-a80d-11feac16b136	ada8d0ac-6b3d-46a8-ac98-8a1b1192a7ae	C	MXN	3633.72	t	\N	\N	\N	2026-03-30 22:21:30.223	2026-03-30 22:21:33.373	\N
0b8d113d-338c-4805-a681-4e050d0ce8b3	ad434e3f-b929-4ff4-a80d-11feac16b136	ada8d0ac-6b3d-46a8-ac98-8a1b1192a7ae	D	MXN	3815.37	t	\N	\N	\N	2026-03-30 22:21:30.232	2026-03-30 22:21:33.382	\N
1ce6cc1e-3d0b-432e-bd4a-b57e6a292a4a	ad434e3f-b929-4ff4-a80d-11feac16b136	e934b4ff-1597-44df-8d7f-640c6d7e8707	A	MXN	3675.15	t	\N	\N	\N	2026-03-30 22:21:30.246	2026-03-30 22:21:33.396	\N
6ca4a2c2-8607-489e-8175-98a5a8b93a89	ad434e3f-b929-4ff4-a80d-11feac16b136	e934b4ff-1597-44df-8d7f-640c6d7e8707	B	MXN	3858.89	t	\N	\N	\N	2026-03-30 22:21:30.253	2026-03-30 22:21:33.404	\N
8680714b-16c5-42d5-9efd-7eee26596e9f	ad434e3f-b929-4ff4-a80d-11feac16b136	e934b4ff-1597-44df-8d7f-640c6d7e8707	C	MXN	4051.82	t	\N	\N	\N	2026-03-30 22:21:30.261	2026-03-30 22:21:33.412	\N
c3207893-dcfb-4864-bfba-940ace42104b	ad434e3f-b929-4ff4-a80d-11feac16b136	e934b4ff-1597-44df-8d7f-640c6d7e8707	D	MXN	4254.39	t	\N	\N	\N	2026-03-30 22:21:30.269	2026-03-30 22:21:33.422	\N
20d4f71b-32c4-4f12-8226-c75f290f6e35	ad434e3f-b929-4ff4-a80d-11feac16b136	73f4aef0-f656-4768-9818-07129ee45791	A	MXN	3333.29	t	\N	\N	\N	2026-03-30 22:21:30.283	2026-03-30 22:21:33.443	\N
eb33c93d-d917-4edf-b089-720df8a6a6a5	ad434e3f-b929-4ff4-a80d-11feac16b136	73f4aef0-f656-4768-9818-07129ee45791	B	MXN	3499.95	t	\N	\N	\N	2026-03-30 22:21:30.289	2026-03-30 22:21:33.453	\N
0d7cabce-d70b-4ff7-8e24-cc4531f194b6	ad434e3f-b929-4ff4-a80d-11feac16b136	73f4aef0-f656-4768-9818-07129ee45791	C	MXN	3674.94	t	\N	\N	\N	2026-03-30 22:21:30.296	2026-03-30 22:21:33.466	\N
cde3d579-65fb-4e13-9887-a4ee6f4d1249	ad434e3f-b929-4ff4-a80d-11feac16b136	73f4aef0-f656-4768-9818-07129ee45791	D	MXN	3858.67	t	\N	\N	\N	2026-03-30 22:21:30.303	2026-03-30 22:21:33.482	\N
4b454a65-8fef-462c-a818-1488275c7a1a	ad434e3f-b929-4ff4-a80d-11feac16b136	8f63d311-722f-4b90-b890-fe271b51a9b4	A	MXN	3289.31	t	\N	\N	\N	2026-03-30 22:21:30.315	2026-03-30 22:21:33.496	\N
7f812880-8de3-4878-8ba3-13d058c187af	ad434e3f-b929-4ff4-a80d-11feac16b136	8f63d311-722f-4b90-b890-fe271b51a9b4	B	MXN	3453.77	t	\N	\N	\N	2026-03-30 22:21:30.324	2026-03-30 22:21:33.506	\N
83c1efce-dc4a-4454-8643-043d37d414ac	ad434e3f-b929-4ff4-a80d-11feac16b136	8f63d311-722f-4b90-b890-fe271b51a9b4	C	MXN	3626.44	t	\N	\N	\N	2026-03-30 22:21:30.332	2026-03-30 22:21:33.535	\N
5b1c388f-24cf-43c5-a333-42060c949c7b	ad434e3f-b929-4ff4-a80d-11feac16b136	8f63d311-722f-4b90-b890-fe271b51a9b4	D	MXN	3807.73	t	\N	\N	\N	2026-03-30 22:21:30.34	2026-03-30 22:21:33.551	\N
d57935e6-2581-4b56-be16-85599cc644f0	ad434e3f-b929-4ff4-a80d-11feac16b136	1b778817-d9ab-428b-bdf1-9ebe3ed039ae	A	MXN	2648.20	t	\N	\N	\N	2026-03-30 22:21:30.355	2026-03-30 22:21:33.573	\N
18e45b60-926f-45a9-ad73-927a3449ac98	ad434e3f-b929-4ff4-a80d-11feac16b136	1b778817-d9ab-428b-bdf1-9ebe3ed039ae	B	MXN	2780.60	t	\N	\N	\N	2026-03-30 22:21:30.362	2026-03-30 22:21:33.589	\N
ac3ff756-9d2e-4ef8-8b71-6d6d1cf66883	ad434e3f-b929-4ff4-a80d-11feac16b136	1b778817-d9ab-428b-bdf1-9ebe3ed039ae	C	MXN	2919.62	t	\N	\N	\N	2026-03-30 22:21:30.37	2026-03-30 22:21:33.606	\N
d85738d3-2a90-4f16-9fb8-5d9af450d18f	ad434e3f-b929-4ff4-a80d-11feac16b136	1b778817-d9ab-428b-bdf1-9ebe3ed039ae	D	MXN	3065.58	t	\N	\N	\N	2026-03-30 22:21:30.377	2026-03-30 22:21:33.619	\N
1dff0a1a-50e1-4152-b216-c9205fb4df0b	ad434e3f-b929-4ff4-a80d-11feac16b136	e6e416d8-32ee-409e-9816-17c5e6f8b420	B	MXN	2944.95	t	\N	\N	\N	2026-03-30 22:21:30.4	2026-03-30 22:21:33.654	\N
ade75f7c-013b-4a1e-a205-5c082e963bbc	ad434e3f-b929-4ff4-a80d-11feac16b136	e6e416d8-32ee-409e-9816-17c5e6f8b420	C	MXN	3092.19	t	\N	\N	\N	2026-03-30 22:21:30.408	2026-03-30 22:21:33.663	\N
31f643cb-70f8-4cf1-b9a7-a4d14d433743	ad434e3f-b929-4ff4-a80d-11feac16b136	e6e416d8-32ee-409e-9816-17c5e6f8b420	D	MXN	3246.78	t	\N	\N	\N	2026-03-30 22:21:30.417	2026-03-30 22:21:33.673	\N
aa48590a-43ef-451f-ab7e-ce41572c99ed	ad434e3f-b929-4ff4-a80d-11feac16b136	fc47eeb3-86e6-4a97-8964-821b5861a39d	A	MXN	2666.88	t	\N	\N	\N	2026-03-30 22:21:30.432	2026-03-30 22:21:33.688	\N
49a161ef-a60c-459a-abfc-56f7d57af088	ad434e3f-b929-4ff4-a80d-11feac16b136	fc47eeb3-86e6-4a97-8964-821b5861a39d	B	MXN	2800.22	t	\N	\N	\N	2026-03-30 22:21:30.439	2026-03-30 22:21:33.702	\N
dac4f27b-e020-4700-b4b7-9927aa2487c6	ad434e3f-b929-4ff4-a80d-11feac16b136	fc47eeb3-86e6-4a97-8964-821b5861a39d	C	MXN	2940.22	t	\N	\N	\N	2026-03-30 22:21:30.446	2026-03-30 22:21:33.715	\N
763dab71-6770-4e25-ba93-a01a23e250b6	ad434e3f-b929-4ff4-a80d-11feac16b136	fc47eeb3-86e6-4a97-8964-821b5861a39d	D	MXN	3087.21	t	\N	\N	\N	2026-03-30 22:21:30.454	2026-03-30 22:21:33.725	\N
2882fa93-9e85-41e0-9f85-7c56a2c52ad6	ad434e3f-b929-4ff4-a80d-11feac16b136	4cb2e968-181c-4d39-be42-ef153c26cc63	A	MXN	2639.53	t	\N	\N	\N	2026-03-30 22:21:30.469	2026-03-30 22:21:33.743	\N
0e706931-a313-4afb-b33c-36d32d28ffa9	ad434e3f-b929-4ff4-a80d-11feac16b136	4cb2e968-181c-4d39-be42-ef153c26cc63	B	MXN	2771.50	t	\N	\N	\N	2026-03-30 22:21:30.478	2026-03-30 22:21:33.758	\N
8d9518a7-eac7-459a-adbe-e96d53b90b1f	ad434e3f-b929-4ff4-a80d-11feac16b136	4cb2e968-181c-4d39-be42-ef153c26cc63	C	MXN	2910.07	t	\N	\N	\N	2026-03-30 22:21:30.486	2026-03-30 22:21:33.774	\N
4a1ff0c2-8366-4e0c-b5df-9104e16e59f0	ad434e3f-b929-4ff4-a80d-11feac16b136	4cb2e968-181c-4d39-be42-ef153c26cc63	D	MXN	3055.55	t	\N	\N	\N	2026-03-30 22:21:30.495	2026-03-30 22:21:33.796	\N
0fe996be-7f20-46fb-82e1-4a047ff5aa8d	ad434e3f-b929-4ff4-a80d-11feac16b136	d9bc9698-afef-47a5-b7a9-226ed87f142a	A	MXN	2264.21	t	\N	\N	\N	2026-03-30 22:21:30.508	2026-03-30 22:21:33.815	\N
65a5db26-ce70-4947-a406-e444f8441598	ad434e3f-b929-4ff4-a80d-11feac16b136	d9bc9698-afef-47a5-b7a9-226ed87f142a	B	MXN	2377.40	t	\N	\N	\N	2026-03-30 22:21:30.515	2026-03-30 22:21:33.823	\N
09262b3b-bf47-4a68-ac40-3baf7cd05b0d	ad434e3f-b929-4ff4-a80d-11feac16b136	d9bc9698-afef-47a5-b7a9-226ed87f142a	C	MXN	2496.25	t	\N	\N	\N	2026-03-30 22:21:30.524	2026-03-30 22:21:33.833	\N
a7e79ffb-3840-4a0e-86e7-1950d0137ab0	ad434e3f-b929-4ff4-a80d-11feac16b136	d9bc9698-afef-47a5-b7a9-226ed87f142a	D	MXN	2621.05	t	\N	\N	\N	2026-03-30 22:21:30.532	2026-03-30 22:21:33.842	\N
4cf3cb97-f66b-4678-88c5-9afe5828d72c	ad434e3f-b929-4ff4-a80d-11feac16b136	61ccce64-d1d1-4e44-b290-287fcddf40cc	A	MXN	2429.81	t	\N	\N	\N	2026-03-30 22:21:30.545	2026-03-30 22:21:33.858	\N
ec81c103-4083-4ba8-abf5-b24c2a04c1c4	ad434e3f-b929-4ff4-a80d-11feac16b136	61ccce64-d1d1-4e44-b290-287fcddf40cc	B	MXN	2551.28	t	\N	\N	\N	2026-03-30 22:21:30.557	2026-03-30 22:21:33.866	\N
c821b02f-b8c7-47c5-b4d9-44c737f6fd6a	ad434e3f-b929-4ff4-a80d-11feac16b136	61ccce64-d1d1-4e44-b290-287fcddf40cc	D	MXN	2812.75	t	\N	\N	\N	2026-03-30 22:21:30.578	2026-03-30 22:21:33.885	\N
fc04c4d9-6da1-4ed2-8ab8-e8b5e812fd7a	ad434e3f-b929-4ff4-a80d-11feac16b136	5d3decde-b899-4682-9dc6-d4cb91338e7a	A	MXN	2272.48	t	\N	\N	\N	2026-03-30 22:21:30.591	2026-03-30 22:21:33.902	\N
1910c8cc-9395-44b6-b5ae-18baf8c48277	ad434e3f-b929-4ff4-a80d-11feac16b136	5d3decde-b899-4682-9dc6-d4cb91338e7a	B	MXN	2386.09	t	\N	\N	\N	2026-03-30 22:21:30.599	2026-03-30 22:21:33.915	\N
39455bf6-07b8-44a6-abab-242f9818fc11	ad434e3f-b929-4ff4-a80d-11feac16b136	5d3decde-b899-4682-9dc6-d4cb91338e7a	C	MXN	2505.37	t	\N	\N	\N	2026-03-30 22:21:30.613	2026-03-30 22:21:33.926	\N
96b08bf8-5e04-426f-b3e0-574ffcbd2732	ad434e3f-b929-4ff4-a80d-11feac16b136	5d3decde-b899-4682-9dc6-d4cb91338e7a	D	MXN	2630.62	t	\N	\N	\N	2026-03-30 22:21:30.629	2026-03-30 22:21:33.938	\N
2ead2430-a586-4e4f-9447-16e1385e4fb2	ad434e3f-b929-4ff4-a80d-11feac16b136	7595d52a-b509-4c49-9d77-87b8a8c0e0d5	A	MXN	2257.68	t	\N	\N	\N	2026-03-30 22:21:30.645	2026-03-30 22:21:33.956	\N
f98dcb3f-8827-4213-a860-bf74448b0f3e	ad434e3f-b929-4ff4-a80d-11feac16b136	7595d52a-b509-4c49-9d77-87b8a8c0e0d5	B	MXN	2370.55	t	\N	\N	\N	2026-03-30 22:21:30.654	2026-03-30 22:21:33.966	\N
e6e355f3-87b7-4685-a6ea-e249de6511b7	ad434e3f-b929-4ff4-a80d-11feac16b136	7595d52a-b509-4c49-9d77-87b8a8c0e0d5	C	MXN	2489.06	t	\N	\N	\N	2026-03-30 22:21:30.662	2026-03-30 22:21:33.975	\N
bbb8d859-eb36-4cd5-9d2e-fda67d095b86	ad434e3f-b929-4ff4-a80d-11feac16b136	7595d52a-b509-4c49-9d77-87b8a8c0e0d5	D	MXN	2613.50	t	\N	\N	\N	2026-03-30 22:21:30.67	2026-03-30 22:21:33.988	\N
9f700919-71e3-4226-9291-e890f1322495	ad434e3f-b929-4ff4-a80d-11feac16b136	37ae24e2-6337-4eaf-916b-9f1a9f8252c9	A	MXN	2421.37	t	\N	\N	\N	2026-03-30 22:21:30.685	2026-03-30 22:21:34.006	\N
d7d2cbd5-e428-4907-a8b2-14f8c4f3efb4	ad434e3f-b929-4ff4-a80d-11feac16b136	37ae24e2-6337-4eaf-916b-9f1a9f8252c9	B	MXN	2542.42	t	\N	\N	\N	2026-03-30 22:21:30.694	2026-03-30 22:21:34.015	\N
820e44c4-d057-409b-8c1c-2a389b7c6d50	ad434e3f-b929-4ff4-a80d-11feac16b136	37ae24e2-6337-4eaf-916b-9f1a9f8252c9	C	MXN	2669.52	t	\N	\N	\N	2026-03-30 22:21:30.703	2026-03-30 22:21:34.025	\N
cb3f3afd-6b1a-461c-b07f-5261880f178f	ad434e3f-b929-4ff4-a80d-11feac16b136	37ae24e2-6337-4eaf-916b-9f1a9f8252c9	D	MXN	2802.97	t	\N	\N	\N	2026-03-30 22:21:30.71	2026-03-30 22:21:34.037	\N
c0604376-a305-4cbf-ab98-705a7fdf9d92	ad434e3f-b929-4ff4-a80d-11feac16b136	4d35c1d2-e088-4393-b2fb-ed2e7b7b511d	A	MXN	2610.99	t	\N	\N	\N	2026-03-30 22:21:30.723	2026-03-30 22:21:34.057	\N
57e2b4ec-5bac-4a44-b729-49061b6878a8	ad434e3f-b929-4ff4-a80d-11feac16b136	4d35c1d2-e088-4393-b2fb-ed2e7b7b511d	B	MXN	2741.52	t	\N	\N	\N	2026-03-30 22:21:30.732	2026-03-30 22:21:34.07	\N
add9cc85-0fdb-4e40-902e-b3ba62ae7a66	ad434e3f-b929-4ff4-a80d-11feac16b136	4d35c1d2-e088-4393-b2fb-ed2e7b7b511d	C	MXN	2878.57	t	\N	\N	\N	2026-03-30 22:21:30.739	2026-03-30 22:21:34.08	\N
0cb9a151-d0be-425f-ab40-720010a3f651	ad434e3f-b929-4ff4-a80d-11feac16b136	4d35c1d2-e088-4393-b2fb-ed2e7b7b511d	D	MXN	3022.48	t	\N	\N	\N	2026-03-30 22:21:30.747	2026-03-30 22:21:34.092	\N
c4f2496c-4bc0-401a-bd97-35f6d916fe4d	ad434e3f-b929-4ff4-a80d-11feac16b136	ab6dd978-ac6b-4d6c-b43e-393cfc8f1f38	A	MXN	2440.06	t	\N	\N	\N	2026-03-30 22:21:30.761	2026-03-30 22:21:34.106	\N
0a4f4f66-142a-492b-b447-62838a4e269a	ad434e3f-b929-4ff4-a80d-11feac16b136	ab6dd978-ac6b-4d6c-b43e-393cfc8f1f38	B	MXN	2562.05	t	\N	\N	\N	2026-03-30 22:21:30.769	2026-03-30 22:21:34.114	\N
0a8c7742-4b31-4b53-bc8f-5e81ed7eae14	ad434e3f-b929-4ff4-a80d-11feac16b136	ab6dd978-ac6b-4d6c-b43e-393cfc8f1f38	C	MXN	2690.13	t	\N	\N	\N	2026-03-30 22:21:30.776	2026-03-30 22:21:34.124	\N
c4d06524-fcf2-4bef-985a-9532c7e08c04	ad434e3f-b929-4ff4-a80d-11feac16b136	ab6dd978-ac6b-4d6c-b43e-393cfc8f1f38	D	MXN	2824.62	t	\N	\N	\N	2026-03-30 22:21:30.785	2026-03-30 22:21:34.134	\N
06e352e7-11fa-4a3e-8f79-949060dc0715	ad434e3f-b929-4ff4-a80d-11feac16b136	e8b0d497-0784-48dc-9622-fa1c0ff0afc6	A	MXN	2418.07	t	\N	\N	\N	2026-03-30 22:21:30.797	2026-03-30 22:21:34.153	\N
9db97ba4-a398-4561-8d76-879400a3e604	ad434e3f-b929-4ff4-a80d-11feac16b136	e8b0d497-0784-48dc-9622-fa1c0ff0afc6	B	MXN	2538.96	t	\N	\N	\N	2026-03-30 22:21:30.805	2026-03-30 22:21:34.168	\N
6d02a2f7-691f-4b18-9c00-fe05e296f614	ad434e3f-b929-4ff4-a80d-11feac16b136	e8b0d497-0784-48dc-9622-fa1c0ff0afc6	C	MXN	2665.88	t	\N	\N	\N	2026-03-30 22:21:30.813	2026-03-30 22:21:34.183	\N
38a37364-aa56-42d5-a0f3-053975bf732b	ad434e3f-b929-4ff4-a80d-11feac16b136	e8b0d497-0784-48dc-9622-fa1c0ff0afc6	D	MXN	2799.15	t	\N	\N	\N	2026-03-30 22:21:30.821	2026-03-30 22:21:34.191	\N
fcb7ce56-fae1-46f9-ae4e-34f79440b558	ad434e3f-b929-4ff4-a80d-11feac16b136	e4bc3270-0a38-461e-a321-211a7ebd94b3	A	MXN	5102.04	t	\N	\N	\N	2026-03-30 22:21:30.84	2026-03-30 22:21:34.205	\N
bc37deb7-4acd-41e7-a454-707c15dc8150	ad434e3f-b929-4ff4-a80d-11feac16b136	e4bc3270-0a38-461e-a321-211a7ebd94b3	C	MXN	5624.96	t	\N	\N	\N	2026-03-30 22:21:30.856	2026-03-30 22:21:34.224	\N
948bf913-7e10-456b-97be-a2a6c4d5466f	ad434e3f-b929-4ff4-a80d-11feac16b136	e4bc3270-0a38-461e-a321-211a7ebd94b3	D	MXN	5906.16	t	\N	\N	\N	2026-03-30 22:21:30.867	2026-03-30 22:21:34.233	\N
17887f5c-f7b7-4fa2-8293-088fdfd09e10	ad434e3f-b929-4ff4-a80d-11feac16b136	d6d4bb71-ab21-43b4-9187-41dc7eb19dc1	A	MXN	5553.52	t	\N	\N	\N	2026-03-30 22:21:30.882	2026-03-30 22:21:34.253	\N
ce59b886-8eef-44f6-88a3-066ec4b47ad8	ad434e3f-b929-4ff4-a80d-11feac16b136	d6d4bb71-ab21-43b4-9187-41dc7eb19dc1	B	MXN	5831.18	t	\N	\N	\N	2026-03-30 22:21:30.891	2026-03-30 22:21:34.265	\N
bb804c0c-c38f-4ef0-b407-a595df051983	ad434e3f-b929-4ff4-a80d-11feac16b136	d6d4bb71-ab21-43b4-9187-41dc7eb19dc1	C	MXN	6122.72	t	\N	\N	\N	2026-03-30 22:21:30.9	2026-03-30 22:21:34.275	\N
fb249b51-eecc-4e16-ba5e-c9190f266d59	ad434e3f-b929-4ff4-a80d-11feac16b136	d6d4bb71-ab21-43b4-9187-41dc7eb19dc1	D	MXN	6428.80	t	\N	\N	\N	2026-03-30 22:21:30.91	2026-03-30 22:21:34.284	\N
2232fe58-ac21-419b-8e89-1f15b298241f	ad434e3f-b929-4ff4-a80d-11feac16b136	26d54ae1-6589-404b-b97e-5844a49a4126	A	MXN	5185.42	t	\N	\N	\N	2026-03-30 22:21:30.922	2026-03-30 22:21:34.303	\N
61650d04-dd29-40aa-be98-aaf70886d879	ad434e3f-b929-4ff4-a80d-11feac16b136	26d54ae1-6589-404b-b97e-5844a49a4126	B	MXN	5444.68	t	\N	\N	\N	2026-03-30 22:21:30.931	2026-03-30 22:21:34.313	\N
2cf71c81-948b-410e-8ac5-a4fd0898c635	ad434e3f-b929-4ff4-a80d-11feac16b136	26d54ae1-6589-404b-b97e-5844a49a4126	C	MXN	5716.90	t	\N	\N	\N	2026-03-30 22:21:30.939	2026-03-30 22:21:34.322	\N
b21f346b-dafa-4558-b3d6-d27cb7a8f6d6	ad434e3f-b929-4ff4-a80d-11feac16b136	26d54ae1-6589-404b-b97e-5844a49a4126	D	MXN	6002.70	t	\N	\N	\N	2026-03-30 22:21:30.946	2026-03-30 22:21:34.334	\N
cfad14a8-343b-447c-91e3-aec08cd2a93a	ad434e3f-b929-4ff4-a80d-11feac16b136	bcd1b43e-9c32-4fb2-a63a-791fd575e91c	A	MXN	4382.93	t	\N	\N	\N	2026-03-30 22:21:30.962	2026-03-30 22:21:34.35	\N
e5dc2884-1ef5-4804-988b-4be750cf6bf9	ad434e3f-b929-4ff4-a80d-11feac16b136	bcd1b43e-9c32-4fb2-a63a-791fd575e91c	B	MXN	4602.07	t	\N	\N	\N	2026-03-30 22:21:30.97	2026-03-30 22:21:34.359	\N
85849a1a-abfc-47b3-ac50-8db7efaee744	ad434e3f-b929-4ff4-a80d-11feac16b136	bcd1b43e-9c32-4fb2-a63a-791fd575e91c	C	MXN	4832.16	t	\N	\N	\N	2026-03-30 22:21:30.977	2026-03-30 22:21:34.369	\N
568f9ccd-c6b5-4663-9078-6da7642e30f1	ad434e3f-b929-4ff4-a80d-11feac16b136	bcd1b43e-9c32-4fb2-a63a-791fd575e91c	D	MXN	5073.72	t	\N	\N	\N	2026-03-30 22:21:30.985	2026-03-30 22:21:34.378	\N
39513297-3a1a-470c-abd1-5a08f5076e65	ad434e3f-b929-4ff4-a80d-11feac16b136	008b256d-38f7-4781-83cf-04b1f624051e	A	MXN	4605.40	t	\N	\N	\N	2026-03-30 22:21:31	2026-03-30 22:21:34.393	\N
a2df4f0c-2d9b-4aa1-8cb4-9e31badf4a3d	ad434e3f-b929-4ff4-a80d-11feac16b136	008b256d-38f7-4781-83cf-04b1f624051e	B	MXN	4835.66	t	\N	\N	\N	2026-03-30 22:21:31.01	2026-03-30 22:21:34.4	\N
3c0ef453-94b2-4c69-a8d6-06f0bff65f57	ad434e3f-b929-4ff4-a80d-11feac16b136	008b256d-38f7-4781-83cf-04b1f624051e	C	MXN	5077.43	t	\N	\N	\N	2026-03-30 22:21:31.019	2026-03-30 22:21:34.407	\N
2d276df4-0404-43a9-8303-6e2fa28f8408	ad434e3f-b929-4ff4-a80d-11feac16b136	9cca5e76-de22-447c-a1bd-e5d16142d93e	A	MXN	4424.62	t	\N	\N	\N	2026-03-30 22:21:31.043	2026-03-30 22:21:34.428	\N
b7fec1b3-5401-4b5b-a4b7-0543616a33bb	ad434e3f-b929-4ff4-a80d-11feac16b136	9cca5e76-de22-447c-a1bd-e5d16142d93e	B	MXN	4645.84	t	\N	\N	\N	2026-03-30 22:21:31.051	2026-03-30 22:21:34.437	\N
dfd0044e-48c9-45c4-927e-6daf4d152ab3	ad434e3f-b929-4ff4-a80d-11feac16b136	9cca5e76-de22-447c-a1bd-e5d16142d93e	C	MXN	4878.12	t	\N	\N	\N	2026-03-30 22:21:31.06	2026-03-30 22:21:34.448	\N
ef3b7bf1-54e3-42e8-bab1-7bf4879b5d5e	ad434e3f-b929-4ff4-a80d-11feac16b136	9cca5e76-de22-447c-a1bd-e5d16142d93e	D	MXN	5121.98	t	\N	\N	\N	2026-03-30 22:21:31.068	2026-03-30 22:21:34.456	\N
d8991e3d-00b4-48de-83d8-7dff8beca1ea	ad434e3f-b929-4ff4-a80d-11feac16b136	bd2b7acf-9367-419f-a8b1-7e4053fd4ff9	A	MXN	4466.11	t	\N	\N	\N	2026-03-30 22:21:31.083	2026-03-30 22:21:34.467	\N
f955ee67-f0d3-4755-ab89-9f9b04e00f50	ad434e3f-b929-4ff4-a80d-11feac16b136	bd2b7acf-9367-419f-a8b1-7e4053fd4ff9	B	MXN	4689.41	t	\N	\N	\N	2026-03-30 22:21:31.091	2026-03-30 22:21:34.475	\N
e6711579-1d12-49a5-a262-5f34b11b853b	ad434e3f-b929-4ff4-a80d-11feac16b136	bd2b7acf-9367-419f-a8b1-7e4053fd4ff9	C	MXN	4923.86	t	\N	\N	\N	2026-03-30 22:21:31.1	2026-03-30 22:21:34.482	\N
a0144c81-cacf-4da9-b779-de347bc18da8	ad434e3f-b929-4ff4-a80d-11feac16b136	bd2b7acf-9367-419f-a8b1-7e4053fd4ff9	D	MXN	5170.01	t	\N	\N	\N	2026-03-30 22:21:31.109	2026-03-30 22:21:34.488	\N
849d0535-e262-47d0-a6a1-68df2f0de614	ad434e3f-b929-4ff4-a80d-11feac16b136	86e0de54-1f22-4556-9437-1b640d3d08cf	A	MXN	4633.17	t	\N	\N	\N	2026-03-30 22:21:31.123	2026-03-30 22:21:34.501	\N
a8d1aad3-952d-4cee-9965-5fcb765abb8b	ad434e3f-b929-4ff4-a80d-11feac16b136	86e0de54-1f22-4556-9437-1b640d3d08cf	B	MXN	4864.82	t	\N	\N	\N	2026-03-30 22:21:31.131	2026-03-30 22:21:34.511	\N
fee904da-6092-4374-82f3-fdc35865e2d1	ad434e3f-b929-4ff4-a80d-11feac16b136	86e0de54-1f22-4556-9437-1b640d3d08cf	C	MXN	5108.05	t	\N	\N	\N	2026-03-30 22:21:31.139	2026-03-30 22:21:34.52	\N
1af81942-be2f-40ca-aadf-f81371e0978d	ad434e3f-b929-4ff4-a80d-11feac16b136	86e0de54-1f22-4556-9437-1b640d3d08cf	D	MXN	5363.41	t	\N	\N	\N	2026-03-30 22:21:31.147	2026-03-30 22:21:34.53	\N
b95a8686-0242-4d9d-bf95-f2facfce7631	ad434e3f-b929-4ff4-a80d-11feac16b136	a3539472-03d3-4625-831f-246f355c82aa	A	MXN	4420.76	t	\N	\N	\N	2026-03-30 22:21:31.159	2026-03-30 22:21:34.545	\N
d3e5888e-dabc-4cce-a792-a283a325e6ac	ad434e3f-b929-4ff4-a80d-11feac16b136	a3539472-03d3-4625-831f-246f355c82aa	B	MXN	4641.77	t	\N	\N	\N	2026-03-30 22:21:31.167	2026-03-30 22:21:34.555	\N
4714b5ef-fcc1-4790-a8cd-c575f9b98ebd	ad434e3f-b929-4ff4-a80d-11feac16b136	a3539472-03d3-4625-831f-246f355c82aa	C	MXN	4873.82	t	\N	\N	\N	2026-03-30 22:21:31.174	2026-03-30 22:21:34.564	\N
3a46c5c6-8cda-4068-b95e-7fa53b54afbd	ad434e3f-b929-4ff4-a80d-11feac16b136	a3539472-03d3-4625-831f-246f355c82aa	D	MXN	5117.48	t	\N	\N	\N	2026-03-30 22:21:31.182	2026-03-30 22:21:34.572	\N
25e56750-165b-4e55-acf9-980c70e51647	ad434e3f-b929-4ff4-a80d-11feac16b136	6d125e00-87ce-487a-9ab2-cc15e442d3af	A	MXN	4646.50	t	\N	\N	\N	2026-03-30 22:21:31.195	2026-03-30 22:21:34.586	\N
d8278ae0-3c49-4378-905d-abd865fec24c	ad434e3f-b929-4ff4-a80d-11feac16b136	6d125e00-87ce-487a-9ab2-cc15e442d3af	B	MXN	4878.80	t	\N	\N	\N	2026-03-30 22:21:31.205	2026-03-30 22:21:34.594	\N
ab8d46ce-6769-422e-89c5-25c03b9b9fa9	ad434e3f-b929-4ff4-a80d-11feac16b136	6d125e00-87ce-487a-9ab2-cc15e442d3af	C	MXN	5122.70	t	\N	\N	\N	2026-03-30 22:21:31.221	2026-03-30 22:21:34.603	\N
43ac13f5-4e55-43fc-9f6d-82a2b347c9da	ad434e3f-b929-4ff4-a80d-11feac16b136	6d125e00-87ce-487a-9ab2-cc15e442d3af	D	MXN	5378.80	t	\N	\N	\N	2026-03-30 22:21:31.232	2026-03-30 22:21:34.613	\N
aef0cc91-4328-4027-8d6f-6e1acb1bd3b5	ad434e3f-b929-4ff4-a80d-11feac16b136	421a93a9-10a5-418f-bb61-8c29065e7a8b	A	MXN	4462.45	t	\N	\N	\N	2026-03-30 22:21:31.245	2026-03-30 22:21:34.626	\N
a641386b-20a0-4602-978c-8e25be622fae	ad434e3f-b929-4ff4-a80d-11feac16b136	421a93a9-10a5-418f-bb61-8c29065e7a8b	B	MXN	4685.55	t	\N	\N	\N	2026-03-30 22:21:31.253	2026-03-30 22:21:34.634	\N
f92cf2a0-e0a3-4dc3-84bf-d52b93e88094	ad434e3f-b929-4ff4-a80d-11feac16b136	421a93a9-10a5-418f-bb61-8c29065e7a8b	C	MXN	4919.79	t	\N	\N	\N	2026-03-30 22:21:31.261	2026-03-30 22:21:34.641	\N
0dceb207-76b9-4e14-8677-f786b89387b7	ad434e3f-b929-4ff4-a80d-11feac16b136	421a93a9-10a5-418f-bb61-8c29065e7a8b	D	MXN	5165.75	t	\N	\N	\N	2026-03-30 22:21:31.267	2026-03-30 22:21:34.649	\N
f5d3d37d-00cf-45f5-a790-9211df18b4a9	ad434e3f-b929-4ff4-a80d-11feac16b136	083a6238-60db-4b53-8617-f63f09870c1f	A	MXN	4484.41	t	\N	\N	\N	2026-03-30 22:21:31.282	2026-03-30 22:21:34.661	\N
cc2ae461-66cd-482c-9fd5-265f5fd131cc	ad434e3f-b929-4ff4-a80d-11feac16b136	083a6238-60db-4b53-8617-f63f09870c1f	B	MXN	4708.61	t	\N	\N	\N	2026-03-30 22:21:31.29	2026-03-30 22:21:34.669	\N
405a86a6-b7b6-4843-8dcd-29a1f8447c03	ad434e3f-b929-4ff4-a80d-11feac16b136	083a6238-60db-4b53-8617-f63f09870c1f	D	MXN	5191.17	t	\N	\N	\N	2026-03-30 22:21:31.31	2026-03-30 22:21:34.685	\N
07c3819f-86ff-47fa-8aac-0c3ef31af438	ad434e3f-b929-4ff4-a80d-11feac16b136	cf163728-3824-4dae-a07c-4396b0da3382	A	MXN	4784.94	t	\N	\N	\N	2026-03-30 22:21:31.327	2026-03-30 22:21:34.697	\N
7f5f6e21-7ebb-4ada-b8d8-6565dcabb8c9	ad434e3f-b929-4ff4-a80d-11feac16b136	cf163728-3824-4dae-a07c-4396b0da3382	B	MXN	5024.16	t	\N	\N	\N	2026-03-30 22:21:31.339	2026-03-30 22:21:34.705	\N
dbde59e7-455c-4c17-bc79-30472a5ae476	ad434e3f-b929-4ff4-a80d-11feac16b136	cf163728-3824-4dae-a07c-4396b0da3382	C	MXN	5275.33	t	\N	\N	\N	2026-03-30 22:21:31.347	2026-03-30 22:21:34.712	\N
5ffee316-b748-4ea5-aa37-ab75b9bc476a	ad434e3f-b929-4ff4-a80d-11feac16b136	cf163728-3824-4dae-a07c-4396b0da3382	D	MXN	5539.06	t	\N	\N	\N	2026-03-30 22:21:31.354	2026-03-30 22:21:34.719	\N
1ac1d48b-e85b-472c-a1e7-3536149136a3	ad434e3f-b929-4ff4-a80d-11feac16b136	9adabc28-d0a0-4175-b24b-0ee84e43d89b	A	MXN	4522.87	t	\N	\N	\N	2026-03-30 22:21:31.369	2026-03-30 22:21:34.736	\N
c09654ae-bd76-446f-8523-2da250c61cbc	ad434e3f-b929-4ff4-a80d-11feac16b136	9adabc28-d0a0-4175-b24b-0ee84e43d89b	B	MXN	4748.99	t	\N	\N	\N	2026-03-30 22:21:31.376	2026-03-30 22:21:34.745	\N
58daad9e-d35d-4726-aa05-8368626cc296	ad434e3f-b929-4ff4-a80d-11feac16b136	9adabc28-d0a0-4175-b24b-0ee84e43d89b	C	MXN	4986.40	t	\N	\N	\N	2026-03-30 22:21:31.384	2026-03-30 22:21:34.753	\N
1fc015d2-673e-4360-9d45-8a879c6ccf18	ad434e3f-b929-4ff4-a80d-11feac16b136	9adabc28-d0a0-4175-b24b-0ee84e43d89b	D	MXN	5235.69	t	\N	\N	\N	2026-03-30 22:21:31.391	2026-03-30 22:21:34.761	\N
0480091a-c79b-432a-a181-e0b145ca8fca	ad434e3f-b929-4ff4-a80d-11feac16b136	5aab8c35-7477-495e-aa07-b6e4f6dbe457	A	MXN	5556.12	t	\N	\N	\N	2026-03-30 22:21:31.404	2026-03-30 22:21:34.775	\N
93b4202c-f2c9-4c74-9cb1-f768786998eb	ad434e3f-b929-4ff4-a80d-11feac16b136	5aab8c35-7477-495e-aa07-b6e4f6dbe457	B	MXN	5833.92	t	\N	\N	\N	2026-03-30 22:21:31.412	2026-03-30 22:21:34.784	\N
d1415ec6-4bcf-481b-a1c7-eb423e8fe80f	ad434e3f-b929-4ff4-a80d-11feac16b136	5aab8c35-7477-495e-aa07-b6e4f6dbe457	C	MXN	6125.60	t	\N	\N	\N	2026-03-30 22:21:31.421	2026-03-30 22:21:34.792	\N
7bdd52f5-f6b6-4fc4-a151-c7400cb59b87	ad434e3f-b929-4ff4-a80d-11feac16b136	5aab8c35-7477-495e-aa07-b6e4f6dbe457	D	MXN	6431.84	t	\N	\N	\N	2026-03-30 22:21:31.429	2026-03-30 22:21:34.801	\N
bc137d0b-5299-4808-a3f9-fe5e8a57a9ab	ad434e3f-b929-4ff4-a80d-11feac16b136	a2cec753-8d86-42f4-9f45-16aaf894e4b2	A	MXN	6157.18	t	\N	\N	\N	2026-03-30 22:21:31.442	2026-03-30 22:21:34.823	\N
afb6b8c9-2227-485e-a09c-c5d492dd1c73	ad434e3f-b929-4ff4-a80d-11feac16b136	a2cec753-8d86-42f4-9f45-16aaf894e4b2	B	MXN	6465.02	t	\N	\N	\N	2026-03-30 22:21:31.449	2026-03-30 22:21:34.831	\N
3a761489-710b-4fec-98b3-974125b54a3e	ad434e3f-b929-4ff4-a80d-11feac16b136	a2cec753-8d86-42f4-9f45-16aaf894e4b2	C	MXN	6788.26	t	\N	\N	\N	2026-03-30 22:21:31.457	2026-03-30 22:21:34.838	\N
51dc344b-5a93-4adf-b3a8-1c09dc1fc96b	ad434e3f-b929-4ff4-a80d-11feac16b136	a2cec753-8d86-42f4-9f45-16aaf894e4b2	D	MXN	7127.62	t	\N	\N	\N	2026-03-30 22:21:31.465	2026-03-30 22:21:34.845	\N
2486df68-0d01-4995-846e-16f81eec0370	ad434e3f-b929-4ff4-a80d-11feac16b136	4bbf5039-4c8e-4d07-80b1-b36bec5151d0	B	MXN	5914.68	t	\N	\N	\N	2026-03-30 22:21:31.484	2026-03-30 22:21:34.867	\N
6d693cd1-9213-4aee-8304-79b9a81626d6	ad434e3f-b929-4ff4-a80d-11feac16b136	4bbf5039-4c8e-4d07-80b1-b36bec5151d0	C	MXN	6210.40	t	\N	\N	\N	2026-03-30 22:21:31.492	2026-03-30 22:21:34.874	\N
ddbe7a0f-1b85-4d6a-970d-5dbac7bbd1d3	ad434e3f-b929-4ff4-a80d-11feac16b136	4bbf5039-4c8e-4d07-80b1-b36bec5151d0	D	MXN	6520.88	t	\N	\N	\N	2026-03-30 22:21:31.499	2026-03-30 22:21:34.881	\N
210f2b84-8e12-4d1e-a878-6d0562a1e9ac	ad434e3f-b929-4ff4-a80d-11feac16b136	2ad80db8-2357-474a-8524-b88768b795cf	A	MXN	6557.64	t	\N	\N	\N	2026-03-30 22:21:31.509	2026-03-30 22:21:34.895	\N
59386af5-ab55-4140-a757-1246c8f613ea	ad434e3f-b929-4ff4-a80d-11feac16b136	2ad80db8-2357-474a-8524-b88768b795cf	B	MXN	6885.49	t	\N	\N	\N	2026-03-30 22:21:31.516	2026-03-30 22:21:34.903	\N
fa12dd33-c510-49f6-9595-7d0a18e574a9	ad434e3f-b929-4ff4-a80d-11feac16b136	2ad80db8-2357-474a-8524-b88768b795cf	C	MXN	7229.72	t	\N	\N	\N	2026-03-30 22:21:31.523	2026-03-30 22:21:34.912	\N
6f453b1b-55d7-4556-bd1d-fbf54ff00344	ad434e3f-b929-4ff4-a80d-11feac16b136	2ad80db8-2357-474a-8524-b88768b795cf	D	MXN	7591.18	t	\N	\N	\N	2026-03-30 22:21:31.53	2026-03-30 22:21:34.921	\N
60f7e42d-f4e1-4cb2-93bc-a29e6c1bda47	ad434e3f-b929-4ff4-a80d-11feac16b136	a0244668-d009-42cf-a2e3-16e02a19e6aa	A	MXN	4227.10	t	\N	\N	\N	2026-03-30 22:21:31.542	2026-03-30 22:21:34.934	\N
0d88f7dc-527d-4974-b0a7-3878ce8b22a0	ad434e3f-b929-4ff4-a80d-11feac16b136	a0244668-d009-42cf-a2e3-16e02a19e6aa	B	MXN	4438.41	t	\N	\N	\N	2026-03-30 22:21:31.549	2026-03-30 22:21:34.941	\N
cc749e94-81d5-437d-90d9-e93585760017	ad434e3f-b929-4ff4-a80d-11feac16b136	a0244668-d009-42cf-a2e3-16e02a19e6aa	C	MXN	4660.28	t	\N	\N	\N	2026-03-30 22:21:31.556	2026-03-30 22:21:34.949	\N
24959ad2-77ef-472d-bf26-9c27b01b0df4	ad434e3f-b929-4ff4-a80d-11feac16b136	a0244668-d009-42cf-a2e3-16e02a19e6aa	D	MXN	4893.26	t	\N	\N	\N	2026-03-30 22:21:31.564	2026-03-30 22:21:34.959	\N
f5752b2c-2068-44dd-9fd6-31bd4d3ac4eb	ad434e3f-b929-4ff4-a80d-11feac16b136	c369fbbb-e024-4b2c-915f-8034bc0c3d97	A	MXN	4452.84	t	\N	\N	\N	2026-03-30 22:21:31.575	2026-03-30 22:21:34.983	\N
0c1f1cd6-fb16-4306-999d-59a50deea223	ad434e3f-b929-4ff4-a80d-11feac16b136	c369fbbb-e024-4b2c-915f-8034bc0c3d97	B	MXN	4675.44	t	\N	\N	\N	2026-03-30 22:21:31.581	2026-03-30 22:21:35.009	\N
146dad5b-6c17-4594-8ece-c5f332adc62c	ad434e3f-b929-4ff4-a80d-11feac16b136	c369fbbb-e024-4b2c-915f-8034bc0c3d97	C	MXN	4909.16	t	\N	\N	\N	2026-03-30 22:21:31.588	2026-03-30 22:21:35.02	\N
f1e8a7fd-517a-456b-9db9-45ac2a478415	ad434e3f-b929-4ff4-a80d-11feac16b136	c369fbbb-e024-4b2c-915f-8034bc0c3d97	D	MXN	5154.58	t	\N	\N	\N	2026-03-30 22:21:31.595	2026-03-30 22:21:35.03	\N
eda902d4-e600-44b5-9694-9ba7f1c64627	ad434e3f-b929-4ff4-a80d-11feac16b136	5c0d7eb9-23c1-4bed-a617-859d68cc53a1	A	MXN	4268.79	t	\N	\N	\N	2026-03-30 22:21:31.609	2026-03-30 22:21:35.048	\N
f909bbf3-5393-4850-bc84-e519b7b9ba9c	ad434e3f-b929-4ff4-a80d-11feac16b136	5c0d7eb9-23c1-4bed-a617-859d68cc53a1	B	MXN	4482.19	t	\N	\N	\N	2026-03-30 22:21:31.615	2026-03-30 22:21:35.056	\N
3c50ef03-8c10-48d8-98df-542ba102a2e9	ad434e3f-b929-4ff4-a80d-11feac16b136	5c0d7eb9-23c1-4bed-a617-859d68cc53a1	C	MXN	4706.25	t	\N	\N	\N	2026-03-30 22:21:31.621	2026-03-30 22:21:35.065	\N
8a628253-b04e-42eb-ac89-32115313efbb	ad434e3f-b929-4ff4-a80d-11feac16b136	5c0d7eb9-23c1-4bed-a617-859d68cc53a1	D	MXN	4941.53	t	\N	\N	\N	2026-03-30 22:21:31.628	2026-03-30 22:21:35.072	\N
ff45c9d6-9158-405e-87ac-3bcaa5e5c679	ad434e3f-b929-4ff4-a80d-11feac16b136	7a074413-4859-4c63-b201-f5202c6b320d	A	MXN	4551.87	t	\N	\N	\N	2026-03-30 22:21:31.639	2026-03-30 22:21:35.089	\N
56d46335-60e4-4baf-b70b-fbcc56cdd986	ad434e3f-b929-4ff4-a80d-11feac16b136	7a074413-4859-4c63-b201-f5202c6b320d	B	MXN	4779.43	t	\N	\N	\N	2026-03-30 22:21:31.644	2026-03-30 22:21:35.106	\N
e7d4b583-0a92-40dc-9afb-4b0e1a2e3196	ad434e3f-b929-4ff4-a80d-11feac16b136	7a074413-4859-4c63-b201-f5202c6b320d	C	MXN	5018.34	t	\N	\N	\N	2026-03-30 22:21:31.651	2026-03-30 22:21:35.114	\N
decf3e05-fea3-48ef-96ad-347b7afeace3	ad434e3f-b929-4ff4-a80d-11feac16b136	7a074413-4859-4c63-b201-f5202c6b320d	D	MXN	5269.21	t	\N	\N	\N	2026-03-30 22:21:31.656	2026-03-30 22:21:35.123	\N
73aeeec0-6a43-484d-843b-227952d6abbd	ad434e3f-b929-4ff4-a80d-11feac16b136	1a0d7974-ee17-486d-97b1-14297369167f	A	MXN	4852.40	t	\N	\N	\N	2026-03-30 22:21:31.668	2026-03-30 22:21:35.142	\N
8b4518ad-e02d-4560-b830-6f9ac6a9df85	ad434e3f-b929-4ff4-a80d-11feac16b136	1a0d7974-ee17-486d-97b1-14297369167f	B	MXN	5094.98	t	\N	\N	\N	2026-03-30 22:21:31.676	2026-03-30 22:21:35.149	\N
67093a1f-f25a-41e3-a15c-fd78c5a83b94	ad434e3f-b929-4ff4-a80d-11feac16b136	1a0d7974-ee17-486d-97b1-14297369167f	C	MXN	5349.67	t	\N	\N	\N	2026-03-30 22:21:31.685	2026-03-30 22:21:35.157	\N
1c9ea28e-4b3a-437f-8166-99006170e81f	ad434e3f-b929-4ff4-a80d-11feac16b136	82324aa9-e3d8-4b37-aa7e-e5dc2141a42d	A	MXN	4590.33	t	\N	\N	\N	2026-03-30 22:21:31.709	2026-03-30 22:21:35.185	\N
126f1fb3-909c-46ab-8f86-d9cce7751991	ad434e3f-b929-4ff4-a80d-11feac16b136	82324aa9-e3d8-4b37-aa7e-e5dc2141a42d	B	MXN	4819.81	t	\N	\N	\N	2026-03-30 22:21:31.719	2026-03-30 22:21:35.198	\N
0bc13546-8f5d-471d-a3ab-7de00da4af44	ad434e3f-b929-4ff4-a80d-11feac16b136	82324aa9-e3d8-4b37-aa7e-e5dc2141a42d	C	MXN	5060.74	t	\N	\N	\N	2026-03-30 22:21:31.727	2026-03-30 22:21:35.219	\N
124cbc2f-e2fa-4a9f-9a1a-8680f9e023df	ad434e3f-b929-4ff4-a80d-11feac16b136	82324aa9-e3d8-4b37-aa7e-e5dc2141a42d	D	MXN	5313.73	t	\N	\N	\N	2026-03-30 22:21:31.737	2026-03-30 22:21:35.23	\N
ca0a2ffc-a3e5-4ce0-aa91-f7e9c5fb9de6	ad434e3f-b929-4ff4-a80d-11feac16b136	e4ac4776-1f09-435a-b0e8-14eee92909e9	A	MXN	23627.16	t	\N	\N	\N	2026-03-30 22:21:31.757	2026-03-30 22:21:35.245	\N
8a9e925e-8031-4490-a397-adbae9c7281a	ad434e3f-b929-4ff4-a80d-11feac16b136	e4ac4776-1f09-435a-b0e8-14eee92909e9	B	MXN	24808.33	t	\N	\N	\N	2026-03-30 22:21:31.765	2026-03-30 22:21:35.255	\N
d62b1886-d9a0-4d11-b32e-849dd5de6f87	ad434e3f-b929-4ff4-a80d-11feac16b136	e4ac4776-1f09-435a-b0e8-14eee92909e9	C	MXN	26048.56	t	\N	\N	\N	2026-03-30 22:21:31.772	2026-03-30 22:21:35.264	\N
24b7113f-9a33-47bc-b09c-1a75cc78ff24	ad434e3f-b929-4ff4-a80d-11feac16b136	e4ac4776-1f09-435a-b0e8-14eee92909e9	D	MXN	27350.82	t	\N	\N	\N	2026-03-30 22:21:31.781	2026-03-30 22:21:35.273	\N
91170ff0-93f4-4b40-8342-a9d8d0a9e6bf	ad434e3f-b929-4ff4-a80d-11feac16b136	88e01dc1-93ce-4ce4-b370-5d72da53f6f0	A	MXN	24304.38	t	\N	\N	\N	2026-03-30 22:21:31.795	2026-03-30 22:21:35.286	\N
f012b314-b4bd-4e45-a440-0c4dc65c1587	ad434e3f-b929-4ff4-a80d-11feac16b136	88e01dc1-93ce-4ce4-b370-5d72da53f6f0	B	MXN	25519.42	t	\N	\N	\N	2026-03-30 22:21:31.803	2026-03-30 22:21:35.295	\N
1dede43e-8870-4b22-94b2-adf40a9325e0	ad434e3f-b929-4ff4-a80d-11feac16b136	88e01dc1-93ce-4ce4-b370-5d72da53f6f0	C	MXN	26795.20	t	\N	\N	\N	2026-03-30 22:21:31.81	2026-03-30 22:21:35.305	\N
a2b7d996-f2f7-468c-a606-b225671f5c27	ad434e3f-b929-4ff4-a80d-11feac16b136	88e01dc1-93ce-4ce4-b370-5d72da53f6f0	D	MXN	28134.78	t	\N	\N	\N	2026-03-30 22:21:31.818	2026-03-30 22:21:35.313	\N
1b7107d9-30dd-49a5-ae7c-0fb3472b43c3	ad434e3f-b929-4ff4-a80d-11feac16b136	e15bab3a-f5cf-48de-8ddd-595beb0b19c5	A	MXN	23752.23	t	\N	\N	\N	2026-03-30 22:21:31.83	2026-03-30 22:21:35.331	\N
67d83829-6f58-4d53-9d3b-f0b98acbd9e9	ad434e3f-b929-4ff4-a80d-11feac16b136	e15bab3a-f5cf-48de-8ddd-595beb0b19c5	B	MXN	24939.67	t	\N	\N	\N	2026-03-30 22:21:31.838	2026-03-30 22:21:35.343	\N
24b7b3a9-d002-4087-935d-d90c3d4de0e5	ad434e3f-b929-4ff4-a80d-11feac16b136	e15bab3a-f5cf-48de-8ddd-595beb0b19c5	C	MXN	26186.47	t	\N	\N	\N	2026-03-30 22:21:31.845	2026-03-30 22:21:35.352	\N
1c0c873f-d3e3-4416-982b-1af8f56bc200	ad434e3f-b929-4ff4-a80d-11feac16b136	e15bab3a-f5cf-48de-8ddd-595beb0b19c5	D	MXN	27495.63	t	\N	\N	\N	2026-03-30 22:21:31.852	2026-03-30 22:21:35.36	\N
e7a3bdea-7f41-448b-ba71-2d4a87993153	ad434e3f-b929-4ff4-a80d-11feac16b136	e90e7af5-db3b-4808-9e35-8121478294c7	A	MXN	23772.81	t	\N	\N	\N	2026-03-30 22:21:31.867	2026-03-30 22:21:35.374	\N
14c24570-998d-4264-931f-2bbb5f28778c	ad434e3f-b929-4ff4-a80d-11feac16b136	e90e7af5-db3b-4808-9e35-8121478294c7	B	MXN	24961.27	t	\N	\N	\N	2026-03-30 22:21:31.874	2026-03-30 22:21:35.382	\N
ee44ac43-2d29-4d2a-b38c-82e3563d3adc	ad434e3f-b929-4ff4-a80d-11feac16b136	e90e7af5-db3b-4808-9e35-8121478294c7	C	MXN	26209.14	t	\N	\N	\N	2026-03-30 22:21:31.881	2026-03-30 22:21:35.391	\N
212182be-9e28-41ca-a7b6-7887caef8cb6	ad434e3f-b929-4ff4-a80d-11feac16b136	e90e7af5-db3b-4808-9e35-8121478294c7	D	MXN	27519.43	t	\N	\N	\N	2026-03-30 22:21:31.887	2026-03-30 22:21:35.399	\N
2e6e03c5-98dc-43e0-b908-511b1238031a	ad434e3f-b929-4ff4-a80d-11feac16b136	71510889-5d8f-4f84-bc76-becbd3ca10be	A	MXN	24224.29	t	\N	\N	\N	2026-03-30 22:21:31.899	2026-03-30 22:21:35.419	\N
b279fcbb-ff55-478e-8625-35622e61b412	ad434e3f-b929-4ff4-a80d-11feac16b136	71510889-5d8f-4f84-bc76-becbd3ca10be	B	MXN	25435.33	t	\N	\N	\N	2026-03-30 22:21:31.907	2026-03-30 22:21:35.431	\N
e57806f7-22a7-4bf1-8dfe-e908b9ce517b	ad434e3f-b929-4ff4-a80d-11feac16b136	71510889-5d8f-4f84-bc76-becbd3ca10be	D	MXN	28042.07	t	\N	\N	\N	2026-03-30 22:21:31.922	2026-03-30 22:21:35.451	\N
1e5f90b3-5932-48a8-bc4f-20bbe5d4fb11	ad434e3f-b929-4ff4-a80d-11feac16b136	7a335d35-c7be-4220-8142-1d5b28e22710	A	MXN	23856.19	t	\N	\N	\N	2026-03-30 22:21:31.94	2026-03-30 22:21:35.465	\N
582cbbd7-90ce-4580-bc1a-4cd57fcbd2d0	ad434e3f-b929-4ff4-a80d-11feac16b136	7a335d35-c7be-4220-8142-1d5b28e22710	B	MXN	25048.83	t	\N	\N	\N	2026-03-30 22:21:31.948	2026-03-30 22:21:35.474	\N
45ad2475-2e3c-49bc-a0ca-cbd30453013e	ad434e3f-b929-4ff4-a80d-11feac16b136	7a335d35-c7be-4220-8142-1d5b28e22710	C	MXN	26301.08	t	\N	\N	\N	2026-03-30 22:21:31.956	2026-03-30 22:21:35.481	\N
30e4b134-a46e-4953-ad3a-c8375315cad4	ad434e3f-b929-4ff4-a80d-11feac16b136	7a335d35-c7be-4220-8142-1d5b28e22710	D	MXN	27615.97	t	\N	\N	\N	2026-03-30 22:21:31.965	2026-03-30 22:21:35.492	\N
3dce2ea6-8f95-4147-bf7f-1b7477a58f60	ad434e3f-b929-4ff4-a80d-11feac16b136	9a0be7a1-0438-43d4-a43a-13f65ca12b09	A	MXN	3441.30	t	\N	\N	\N	2026-03-30 22:21:31.985	2026-03-30 22:21:35.511	aba72031-2ffc-4178-87d8-19ae461dff65
6268dfaa-7243-4da5-aedc-95c8a3507658	ad434e3f-b929-4ff4-a80d-11feac16b136	9a0be7a1-0438-43d4-a43a-13f65ca12b09	B	MXN	3613.34	t	\N	\N	\N	2026-03-30 22:21:31.992	2026-03-30 22:21:35.518	aba72031-2ffc-4178-87d8-19ae461dff65
baf97984-1ce9-4186-8a97-1f0008f9691e	ad434e3f-b929-4ff4-a80d-11feac16b136	9a0be7a1-0438-43d4-a43a-13f65ca12b09	C	MXN	3793.98	t	\N	\N	\N	2026-03-30 22:21:32	2026-03-30 22:21:35.527	aba72031-2ffc-4178-87d8-19ae461dff65
ecae0480-a076-45f7-948b-c266245b58ec	ad434e3f-b929-4ff4-a80d-11feac16b136	9a0be7a1-0438-43d4-a43a-13f65ca12b09	D	MXN	3983.66	t	\N	\N	\N	2026-03-30 22:21:32.008	2026-03-30 22:21:35.536	aba72031-2ffc-4178-87d8-19ae461dff65
357ba4f7-f7a3-45d2-8991-8b08dffd370e	ad434e3f-b929-4ff4-a80d-11feac16b136	9a0be7a1-0438-43d4-a43a-13f65ca12b09	A	MXN	3448.46	t	\N	\N	\N	2026-03-30 22:21:32.026	2026-03-30 22:21:35.552	e0609a75-0565-49e7-ac37-3d3ad54e6947
9354e28f-a168-4b37-8956-5d837df51133	ad434e3f-b929-4ff4-a80d-11feac16b136	9a0be7a1-0438-43d4-a43a-13f65ca12b09	B	MXN	3620.85	t	\N	\N	\N	2026-03-30 22:21:32.034	2026-03-30 22:21:35.558	e0609a75-0565-49e7-ac37-3d3ad54e6947
e5bf17f0-cc86-48c8-b17b-539dcd7b87e7	ad434e3f-b929-4ff4-a80d-11feac16b136	9a0be7a1-0438-43d4-a43a-13f65ca12b09	C	MXN	3801.87	t	\N	\N	\N	2026-03-30 22:21:32.042	2026-03-30 22:21:35.567	e0609a75-0565-49e7-ac37-3d3ad54e6947
f74ed6b2-62c4-42e4-9129-600b2bb81217	ad434e3f-b929-4ff4-a80d-11feac16b136	9a0be7a1-0438-43d4-a43a-13f65ca12b09	D	MXN	3991.95	t	\N	\N	\N	2026-03-30 22:21:32.048	2026-03-30 22:21:35.575	e0609a75-0565-49e7-ac37-3d3ad54e6947
34c95be9-d6b0-4d33-b420-4bb2489e380f	ad434e3f-b929-4ff4-a80d-11feac16b136	9a0be7a1-0438-43d4-a43a-13f65ca12b09	A	MXN	3578.93	t	\N	\N	\N	2026-03-30 22:21:32.065	2026-03-30 22:21:35.591	253c9023-cf64-484f-961b-29152878f4ad
7a97c7a4-d2c6-402c-8b59-3ee2a8fd42e8	ad434e3f-b929-4ff4-a80d-11feac16b136	9a0be7a1-0438-43d4-a43a-13f65ca12b09	B	MXN	3757.84	t	\N	\N	\N	2026-03-30 22:21:32.073	2026-03-30 22:21:35.601	253c9023-cf64-484f-961b-29152878f4ad
1a226ae0-b25c-4a6a-94be-49b747330992	ad434e3f-b929-4ff4-a80d-11feac16b136	9a0be7a1-0438-43d4-a43a-13f65ca12b09	C	MXN	3945.71	t	\N	\N	\N	2026-03-30 22:21:32.081	2026-03-30 22:21:35.613	253c9023-cf64-484f-961b-29152878f4ad
80a7e4eb-c352-49c2-bf48-7fe7dd0e2bca	ad434e3f-b929-4ff4-a80d-11feac16b136	9a0be7a1-0438-43d4-a43a-13f65ca12b09	D	MXN	4142.97	t	\N	\N	\N	2026-03-30 22:21:32.089	2026-03-30 22:21:35.623	253c9023-cf64-484f-961b-29152878f4ad
2af3426a-5046-4ff0-b7c5-59ee770148ea	ad434e3f-b929-4ff4-a80d-11feac16b136	9a0be7a1-0438-43d4-a43a-13f65ca12b09	A	MXN	3660.58	t	\N	\N	\N	2026-03-30 22:21:32.107	2026-03-30 22:21:35.641	ee5ec61e-2da0-4d99-9c6e-92608139d324
dae3885d-d23b-46dd-b065-ceb9c2502439	ad434e3f-b929-4ff4-a80d-11feac16b136	9a0be7a1-0438-43d4-a43a-13f65ca12b09	A	MXN	3079.32	t	\N	\N	\N	2026-03-30 22:21:29.639	2026-03-30 22:21:32.561	\N
7f547584-dc60-4477-91c3-ae7e6e95abfe	ad434e3f-b929-4ff4-a80d-11feac16b136	9a0be7a1-0438-43d4-a43a-13f65ca12b09	C	MXN	4035.73	t	\N	\N	\N	2026-03-30 22:21:32.128	2026-03-30 22:21:35.657	ee5ec61e-2da0-4d99-9c6e-92608139d324
e5234fda-3dd7-460d-83d9-c6ce9702ccd8	ad434e3f-b929-4ff4-a80d-11feac16b136	9a0be7a1-0438-43d4-a43a-13f65ca12b09	D	MXN	4237.50	t	\N	\N	\N	2026-03-30 22:21:32.152	2026-03-30 22:21:35.665	ee5ec61e-2da0-4d99-9c6e-92608139d324
c86ef142-d1c4-483c-924a-72c4e717922a	ad434e3f-b929-4ff4-a80d-11feac16b136	a18ee5db-cad6-45cb-a472-37975cdecc02	A	MXN	3772.50	t	\N	\N	\N	2026-03-30 22:21:32.176	2026-03-30 22:21:35.688	e79e0874-4b29-4fde-ab5c-e63a1323ae7d
8391c666-366f-464e-a481-30cd0f122f7d	ad434e3f-b929-4ff4-a80d-11feac16b136	a18ee5db-cad6-45cb-a472-37975cdecc02	B	MXN	3961.10	t	\N	\N	\N	2026-03-30 22:21:32.185	2026-03-30 22:21:35.697	e79e0874-4b29-4fde-ab5c-e63a1323ae7d
0f19efe9-f3e2-49d8-981e-d84fed07d733	ad434e3f-b929-4ff4-a80d-11feac16b136	a18ee5db-cad6-45cb-a472-37975cdecc02	C	MXN	4159.12	t	\N	\N	\N	2026-03-30 22:21:32.194	2026-03-30 22:21:35.705	e79e0874-4b29-4fde-ab5c-e63a1323ae7d
e507a95d-8ab0-4dad-b99a-07f8a72d3445	ad434e3f-b929-4ff4-a80d-11feac16b136	a18ee5db-cad6-45cb-a472-37975cdecc02	D	MXN	4367.06	t	\N	\N	\N	2026-03-30 22:21:32.202	2026-03-30 22:21:35.712	e79e0874-4b29-4fde-ab5c-e63a1323ae7d
9dff3664-52bb-4c00-8245-51ec79c6a9d4	ad434e3f-b929-4ff4-a80d-11feac16b136	a18ee5db-cad6-45cb-a472-37975cdecc02	A	MXN	3779.66	t	\N	\N	\N	2026-03-30 22:21:32.219	2026-03-30 22:21:35.731	f7d28355-046b-4012-930d-8ab2ddd3dae7
20e88795-145e-4f74-93b6-6f10dcbeb454	ad434e3f-b929-4ff4-a80d-11feac16b136	a18ee5db-cad6-45cb-a472-37975cdecc02	B	MXN	3968.61	t	\N	\N	\N	2026-03-30 22:21:32.229	2026-03-30 22:21:35.738	f7d28355-046b-4012-930d-8ab2ddd3dae7
59c5205a-0111-49e4-95f4-577e09a32f63	ad434e3f-b929-4ff4-a80d-11feac16b136	a18ee5db-cad6-45cb-a472-37975cdecc02	C	MXN	4167.01	t	\N	\N	\N	2026-03-30 22:21:32.244	2026-03-30 22:21:35.745	f7d28355-046b-4012-930d-8ab2ddd3dae7
180ea8db-c191-4107-8966-cc5477e3c48f	ad434e3f-b929-4ff4-a80d-11feac16b136	a18ee5db-cad6-45cb-a472-37975cdecc02	D	MXN	4375.35	t	\N	\N	\N	2026-03-30 22:21:32.254	2026-03-30 22:21:35.753	f7d28355-046b-4012-930d-8ab2ddd3dae7
b29c1f4f-7128-4cce-9d51-3fb9545b421f	ad434e3f-b929-4ff4-a80d-11feac16b136	a18ee5db-cad6-45cb-a472-37975cdecc02	A	MXN	3910.13	t	\N	\N	\N	2026-03-30 22:21:32.273	2026-03-30 22:21:35.768	761551bb-04f6-43b0-8eaa-49ffc8cff79d
27bad610-038b-4fe0-992f-2fe8b726d540	ad434e3f-b929-4ff4-a80d-11feac16b136	a18ee5db-cad6-45cb-a472-37975cdecc02	B	MXN	4105.60	t	\N	\N	\N	2026-03-30 22:21:32.28	2026-03-30 22:21:35.778	761551bb-04f6-43b0-8eaa-49ffc8cff79d
aa67369d-7b4c-40dc-b2b5-521b1298589c	ad434e3f-b929-4ff4-a80d-11feac16b136	a18ee5db-cad6-45cb-a472-37975cdecc02	C	MXN	4310.85	t	\N	\N	\N	2026-03-30 22:21:32.289	2026-03-30 22:21:35.786	761551bb-04f6-43b0-8eaa-49ffc8cff79d
ffe0849f-8b0d-437c-9cb4-598c7a6a439e	ad434e3f-b929-4ff4-a80d-11feac16b136	a18ee5db-cad6-45cb-a472-37975cdecc02	D	MXN	4526.37	t	\N	\N	\N	2026-03-30 22:21:32.298	2026-03-30 22:21:35.795	761551bb-04f6-43b0-8eaa-49ffc8cff79d
ef0d2aa0-7920-4396-bd2c-8488359f0d2f	ad434e3f-b929-4ff4-a80d-11feac16b136	a18ee5db-cad6-45cb-a472-37975cdecc02	A	MXN	3991.78	t	\N	\N	\N	2026-03-30 22:21:32.315	2026-03-30 22:21:35.81	c1d7fd57-440c-4240-808e-2352e855e377
0a6e35ae-8220-4674-9aa8-c41c0f216e5f	ad434e3f-b929-4ff4-a80d-11feac16b136	a18ee5db-cad6-45cb-a472-37975cdecc02	B	MXN	4191.34	t	\N	\N	\N	2026-03-30 22:21:32.337	2026-03-30 22:21:35.82	c1d7fd57-440c-4240-808e-2352e855e377
495db535-2d09-4e42-963f-883d533d1bbd	ad434e3f-b929-4ff4-a80d-11feac16b136	a18ee5db-cad6-45cb-a472-37975cdecc02	C	MXN	4400.87	t	\N	\N	\N	2026-03-30 22:21:32.347	2026-03-30 22:21:35.828	c1d7fd57-440c-4240-808e-2352e855e377
2c0fb807-f40a-49a3-a896-a244d2df081d	ad434e3f-b929-4ff4-a80d-11feac16b136	a65fd618-c46b-4f3a-89a5-016987a46e53	A	MXN	3457.84	t	\N	\N	\N	2026-03-30 22:21:32.38	2026-03-30 22:21:35.858	cddc835c-39b2-4053-8830-afc558d91504
fcd8a1b1-d26f-4acc-b946-3f51ac883372	ad434e3f-b929-4ff4-a80d-11feac16b136	a65fd618-c46b-4f3a-89a5-016987a46e53	B	MXN	3630.72	t	\N	\N	\N	2026-03-30 22:21:32.39	2026-03-30 22:21:35.867	cddc835c-39b2-4053-8830-afc558d91504
24122097-714e-4222-acff-f96caef163a6	ad434e3f-b929-4ff4-a80d-11feac16b136	a65fd618-c46b-4f3a-89a5-016987a46e53	C	MXN	3812.22	t	\N	\N	\N	2026-03-30 22:21:32.4	2026-03-30 22:21:35.874	cddc835c-39b2-4053-8830-afc558d91504
bd35b5ac-fdd1-428e-b19b-4b8a81112f2d	ad434e3f-b929-4ff4-a80d-11feac16b136	a65fd618-c46b-4f3a-89a5-016987a46e53	D	MXN	4002.80	t	\N	\N	\N	2026-03-30 22:21:32.413	2026-03-30 22:21:35.881	cddc835c-39b2-4053-8830-afc558d91504
028f2f16-7c2e-4844-864b-f3da572ac12c	ad434e3f-b929-4ff4-a80d-11feac16b136	a65fd618-c46b-4f3a-89a5-016987a46e53	A	MXN	3465.00	t	\N	\N	\N	2026-03-30 22:21:32.446	2026-03-30 22:21:35.898	97cd585f-2b7e-47ce-b0ba-e7d76643d402
ab396c3e-ad84-4379-a153-8e4779d815ff	ad434e3f-b929-4ff4-a80d-11feac16b136	a65fd618-c46b-4f3a-89a5-016987a46e53	B	MXN	3638.23	t	\N	\N	\N	2026-03-30 22:21:32.454	2026-03-30 22:21:35.905	97cd585f-2b7e-47ce-b0ba-e7d76643d402
b8db6eb4-62a5-4f65-9f1b-ba1437f52e2b	ad434e3f-b929-4ff4-a80d-11feac16b136	a65fd618-c46b-4f3a-89a5-016987a46e53	C	MXN	3820.11	t	\N	\N	\N	2026-03-30 22:21:32.465	2026-03-30 22:21:35.913	97cd585f-2b7e-47ce-b0ba-e7d76643d402
08a5a432-06b6-4956-966d-cd50f96b5b6b	ad434e3f-b929-4ff4-a80d-11feac16b136	a65fd618-c46b-4f3a-89a5-016987a46e53	D	MXN	4011.09	t	\N	\N	\N	2026-03-30 22:21:32.48	2026-03-30 22:21:35.923	97cd585f-2b7e-47ce-b0ba-e7d76643d402
4f9ee404-c04d-4058-9c24-7b24acbe2fc4	ad434e3f-b929-4ff4-a80d-11feac16b136	a65fd618-c46b-4f3a-89a5-016987a46e53	A	MXN	3595.47	t	\N	\N	\N	2026-03-30 22:21:32.5	2026-03-30 22:21:35.939	3f434c13-113e-4926-bb62-ce8116fced2a
6d31dc76-6b5d-4528-a057-8ff5f6d21a63	ad434e3f-b929-4ff4-a80d-11feac16b136	a65fd618-c46b-4f3a-89a5-016987a46e53	B	MXN	3775.22	t	\N	\N	\N	2026-03-30 22:21:32.511	2026-03-30 22:21:35.947	3f434c13-113e-4926-bb62-ce8116fced2a
316510d7-6c6b-4dac-976f-d04c137ba038	ad434e3f-b929-4ff4-a80d-11feac16b136	a65fd618-c46b-4f3a-89a5-016987a46e53	C	MXN	3963.95	t	\N	\N	\N	2026-03-30 22:21:32.524	2026-03-30 22:21:35.957	3f434c13-113e-4926-bb62-ce8116fced2a
38046aef-4428-4c06-ab04-f1cc85e801c3	ad434e3f-b929-4ff4-a80d-11feac16b136	a65fd618-c46b-4f3a-89a5-016987a46e53	D	MXN	4162.11	t	\N	\N	\N	2026-03-30 22:21:32.535	2026-03-30 22:21:35.967	3f434c13-113e-4926-bb62-ce8116fced2a
ddb5f709-b8dc-45f1-a348-f7d71a534c71	ad434e3f-b929-4ff4-a80d-11feac16b136	a65fd618-c46b-4f3a-89a5-016987a46e53	A	MXN	3677.12	t	\N	\N	\N	2026-03-30 22:21:32.556	2026-03-30 22:21:35.99	988192ae-9d9a-423b-8337-a8d581ff1792
3b96bcd2-714a-4017-aaf6-2477bcc457e7	ad434e3f-b929-4ff4-a80d-11feac16b136	a65fd618-c46b-4f3a-89a5-016987a46e53	B	MXN	3860.96	t	\N	\N	\N	2026-03-30 22:21:32.568	2026-03-30 22:21:35.998	988192ae-9d9a-423b-8337-a8d581ff1792
c29a3038-1d65-430e-a6e4-7edb60e3bd9f	ad434e3f-b929-4ff4-a80d-11feac16b136	a65fd618-c46b-4f3a-89a5-016987a46e53	C	MXN	4053.97	t	\N	\N	\N	2026-03-30 22:21:32.577	2026-03-30 22:21:36.008	988192ae-9d9a-423b-8337-a8d581ff1792
2423480c-be9c-4690-85e1-6e27dca624da	ad434e3f-b929-4ff4-a80d-11feac16b136	a65fd618-c46b-4f3a-89a5-016987a46e53	D	MXN	4256.64	t	\N	\N	\N	2026-03-30 22:21:32.587	2026-03-30 22:21:36.016	988192ae-9d9a-423b-8337-a8d581ff1792
50757ed5-810b-4203-837b-fd9f63379711	ad434e3f-b929-4ff4-a80d-11feac16b136	8f35dd7b-cb84-4b7a-9c17-9de37fdbcf0c	A	MXN	3428.24	t	\N	\N	\N	2026-03-30 22:21:32.605	2026-03-30 22:21:36.032	66892415-6ff3-407c-a22f-703cc3543486
3e1ff95f-070d-473e-aff2-49116e8f0ee4	ad434e3f-b929-4ff4-a80d-11feac16b136	8f35dd7b-cb84-4b7a-9c17-9de37fdbcf0c	C	MXN	3779.60	t	\N	\N	\N	2026-03-30 22:21:32.641	2026-03-30 22:21:36.051	66892415-6ff3-407c-a22f-703cc3543486
518d1085-3396-4e0f-b287-169189540cca	ad434e3f-b929-4ff4-a80d-11feac16b136	8f35dd7b-cb84-4b7a-9c17-9de37fdbcf0c	D	MXN	3968.56	t	\N	\N	\N	2026-03-30 22:21:32.659	2026-03-30 22:21:36.061	66892415-6ff3-407c-a22f-703cc3543486
74f862ef-95cd-4ea4-835a-4f377a7516bd	ad434e3f-b929-4ff4-a80d-11feac16b136	8f35dd7b-cb84-4b7a-9c17-9de37fdbcf0c	A	MXN	3565.87	t	\N	\N	\N	2026-03-30 22:21:32.682	2026-03-30 22:21:36.08	523891aa-d048-41e4-a9b9-956ec85a5518
a9e51b4a-115c-45ab-b4c1-7a3eb5ce3f7f	ad434e3f-b929-4ff4-a80d-11feac16b136	8f35dd7b-cb84-4b7a-9c17-9de37fdbcf0c	B	MXN	3744.14	t	\N	\N	\N	2026-03-30 22:21:32.689	2026-03-30 22:21:36.089	523891aa-d048-41e4-a9b9-956ec85a5518
cfe0e462-7c91-41bb-af5c-998e1664ba0d	ad434e3f-b929-4ff4-a80d-11feac16b136	8f35dd7b-cb84-4b7a-9c17-9de37fdbcf0c	C	MXN	3931.33	t	\N	\N	\N	2026-03-30 22:21:32.7	2026-03-30 22:21:36.099	523891aa-d048-41e4-a9b9-956ec85a5518
743ab454-9ef8-46bb-a680-bb925ec1f6b3	ad434e3f-b929-4ff4-a80d-11feac16b136	8f35dd7b-cb84-4b7a-9c17-9de37fdbcf0c	D	MXN	4127.87	t	\N	\N	\N	2026-03-30 22:21:32.71	2026-03-30 22:21:36.107	523891aa-d048-41e4-a9b9-956ec85a5518
af252e2b-688c-4d65-a9f2-ba69e4159956	ad434e3f-b929-4ff4-a80d-11feac16b136	8f35dd7b-cb84-4b7a-9c17-9de37fdbcf0c	A	MXN	3435.40	t	\N	\N	\N	2026-03-30 22:21:32.725	2026-03-30 22:21:36.124	eeb421ef-52ec-4b87-a90a-a70e320322dd
1763fc07-5aa5-4430-970f-128d15ff3c8d	ad434e3f-b929-4ff4-a80d-11feac16b136	8f35dd7b-cb84-4b7a-9c17-9de37fdbcf0c	C	MXN	3787.49	t	\N	\N	\N	2026-03-30 22:21:32.745	2026-03-30 22:21:36.143	eeb421ef-52ec-4b87-a90a-a70e320322dd
f08cf4bd-adda-4c40-b48a-0a39dc872492	ad434e3f-b929-4ff4-a80d-11feac16b136	8f35dd7b-cb84-4b7a-9c17-9de37fdbcf0c	D	MXN	3976.85	t	\N	\N	\N	2026-03-30 22:21:32.757	2026-03-30 22:21:36.151	eeb421ef-52ec-4b87-a90a-a70e320322dd
5ea722bd-1da1-4682-b0e9-ce631b75ebea	ad434e3f-b929-4ff4-a80d-11feac16b136	8f35dd7b-cb84-4b7a-9c17-9de37fdbcf0c	A	MXN	3647.52	t	\N	\N	\N	2026-03-30 22:21:32.776	2026-03-30 22:21:36.17	ddac1262-b2e3-4c77-a80c-8d6aef3a6625
8f63b77c-66a7-497d-907b-7edd7bc2f57a	ad434e3f-b929-4ff4-a80d-11feac16b136	8f35dd7b-cb84-4b7a-9c17-9de37fdbcf0c	B	MXN	3829.88	t	\N	\N	\N	2026-03-30 22:21:32.787	2026-03-30 22:21:36.178	ddac1262-b2e3-4c77-a80c-8d6aef3a6625
e77c858b-b600-471b-9b2b-7323bd4825c4	ad434e3f-b929-4ff4-a80d-11feac16b136	8f35dd7b-cb84-4b7a-9c17-9de37fdbcf0c	C	MXN	4021.35	t	\N	\N	\N	2026-03-30 22:21:32.796	2026-03-30 22:21:36.188	ddac1262-b2e3-4c77-a80c-8d6aef3a6625
68043c43-1b1c-4c8b-8113-7ccc5a27953c	ad434e3f-b929-4ff4-a80d-11feac16b136	8f35dd7b-cb84-4b7a-9c17-9de37fdbcf0c	D	MXN	4222.40	t	\N	\N	\N	2026-03-30 22:21:32.804	2026-03-30 22:21:36.198	ddac1262-b2e3-4c77-a80c-8d6aef3a6625
6cca4537-c150-42e8-9c76-b3ebe67c996c	ad434e3f-b929-4ff4-a80d-11feac16b136	ebef8308-ebb5-4b75-b25e-0d648cf244ec	A	MXN	2820.18	t	\N	\N	\N	2026-03-30 22:21:32.821	2026-03-30 22:21:36.221	cef547a6-012b-4e2e-bb6e-0f0c7b755bd0
2d580fcf-60e6-493d-a2f3-1d8cfcd9efb8	ad434e3f-b929-4ff4-a80d-11feac16b136	ebef8308-ebb5-4b75-b25e-0d648cf244ec	B	MXN	2961.17	t	\N	\N	\N	2026-03-30 22:21:32.831	2026-03-30 22:21:36.233	cef547a6-012b-4e2e-bb6e-0f0c7b755bd0
60bed908-9d26-4dbc-8ec8-007a1f38ed0f	ad434e3f-b929-4ff4-a80d-11feac16b136	ebef8308-ebb5-4b75-b25e-0d648cf244ec	C	MXN	3109.20	t	\N	\N	\N	2026-03-30 22:21:32.842	2026-03-30 22:21:36.241	cef547a6-012b-4e2e-bb6e-0f0c7b755bd0
67f91b5c-5c71-41ec-9c86-144477fbb2eb	ad434e3f-b929-4ff4-a80d-11feac16b136	ebef8308-ebb5-4b75-b25e-0d648cf244ec	D	MXN	3264.64	t	\N	\N	\N	2026-03-30 22:21:32.851	2026-03-30 22:21:36.252	cef547a6-012b-4e2e-bb6e-0f0c7b755bd0
64625798-f24b-4824-b798-2a39e11f6639	ad434e3f-b929-4ff4-a80d-11feac16b136	ebef8308-ebb5-4b75-b25e-0d648cf244ec	A	MXN	2827.34	t	\N	\N	\N	2026-03-30 22:21:32.87	2026-03-30 22:21:36.286	de341d58-44f2-4749-98bb-6baede3fb116
9d65709f-e68f-48b3-9f05-e67c5e52f5a9	ad434e3f-b929-4ff4-a80d-11feac16b136	ebef8308-ebb5-4b75-b25e-0d648cf244ec	B	MXN	2968.68	t	\N	\N	\N	2026-03-30 22:21:32.883	2026-03-30 22:21:36.296	de341d58-44f2-4749-98bb-6baede3fb116
d287f1c7-3dba-4513-beee-d12d65d39316	ad434e3f-b929-4ff4-a80d-11feac16b136	ebef8308-ebb5-4b75-b25e-0d648cf244ec	C	MXN	3117.09	t	\N	\N	\N	2026-03-30 22:21:32.897	2026-03-30 22:21:36.304	de341d58-44f2-4749-98bb-6baede3fb116
8ae4806c-9014-4660-8642-cc4ce80c042b	ad434e3f-b929-4ff4-a80d-11feac16b136	ebef8308-ebb5-4b75-b25e-0d648cf244ec	D	MXN	3272.93	t	\N	\N	\N	2026-03-30 22:21:32.91	2026-03-30 22:21:36.314	de341d58-44f2-4749-98bb-6baede3fb116
72cf6d3a-0dc2-4a18-823d-0137388bf298	ad434e3f-b929-4ff4-a80d-11feac16b136	ebef8308-ebb5-4b75-b25e-0d648cf244ec	A	MXN	2957.81	t	\N	\N	\N	2026-03-30 22:21:32.933	2026-03-30 22:21:36.33	3f466380-daf6-4914-9ef4-ab4fc38b48a7
c09d439e-ea0e-4a93-9dfe-6dfe03873eb1	ad434e3f-b929-4ff4-a80d-11feac16b136	ebef8308-ebb5-4b75-b25e-0d648cf244ec	B	MXN	3105.67	t	\N	\N	\N	2026-03-30 22:21:32.946	2026-03-30 22:21:36.338	3f466380-daf6-4914-9ef4-ab4fc38b48a7
90027fd2-76e4-415d-bdeb-48d183588d2a	ad434e3f-b929-4ff4-a80d-11feac16b136	ebef8308-ebb5-4b75-b25e-0d648cf244ec	C	MXN	3260.93	t	\N	\N	\N	2026-03-30 22:21:32.956	2026-03-30 22:21:36.345	3f466380-daf6-4914-9ef4-ab4fc38b48a7
6d72a3c5-84d3-461a-a913-dc42fb859b02	ad434e3f-b929-4ff4-a80d-11feac16b136	ebef8308-ebb5-4b75-b25e-0d648cf244ec	D	MXN	3423.95	t	\N	\N	\N	2026-03-30 22:21:32.967	2026-03-30 22:21:36.357	3f466380-daf6-4914-9ef4-ab4fc38b48a7
3d96d677-0c6e-4465-9aa6-bd7ab09fb204	ad434e3f-b929-4ff4-a80d-11feac16b136	ebef8308-ebb5-4b75-b25e-0d648cf244ec	A	MXN	3039.46	t	\N	\N	\N	2026-03-30 22:21:32.993	2026-03-30 22:21:36.375	99aab12d-4c6d-40e1-8b17-da000e386280
ba435844-6a2f-4cd1-b4b2-bab76cbbdf2d	ad434e3f-b929-4ff4-a80d-11feac16b136	ebef8308-ebb5-4b75-b25e-0d648cf244ec	B	MXN	3191.41	t	\N	\N	\N	2026-03-30 22:21:33.006	2026-03-30 22:21:36.384	99aab12d-4c6d-40e1-8b17-da000e386280
76fa2711-ffc9-4faa-9498-670c74ed5d70	ad434e3f-b929-4ff4-a80d-11feac16b136	ebef8308-ebb5-4b75-b25e-0d648cf244ec	C	MXN	3350.95	t	\N	\N	\N	2026-03-30 22:21:33.017	2026-03-30 22:21:36.396	99aab12d-4c6d-40e1-8b17-da000e386280
7145a652-ab62-4c13-9c21-f135f21c5df7	ad434e3f-b929-4ff4-a80d-11feac16b136	ebef8308-ebb5-4b75-b25e-0d648cf244ec	D	MXN	3518.48	t	\N	\N	\N	2026-03-30 22:21:33.032	2026-03-30 22:21:36.412	99aab12d-4c6d-40e1-8b17-da000e386280
3d69e0d7-8525-4728-ad08-604289ed717b	ad434e3f-b929-4ff4-a80d-11feac16b136	f8c7e1aa-6839-4b19-b028-4f59d51bc095	A	MXN	2983.19	t	\N	\N	\N	2026-03-30 22:21:33.05	2026-03-30 22:21:36.435	717c4d0b-0c05-4a2c-be8e-0c4dddccf2b2
730dc532-0e05-43a6-9af1-359ffe2f600b	ad434e3f-b929-4ff4-a80d-11feac16b136	f8c7e1aa-6839-4b19-b028-4f59d51bc095	B	MXN	3132.33	t	\N	\N	\N	2026-03-30 22:21:33.06	2026-03-30 22:21:36.445	717c4d0b-0c05-4a2c-be8e-0c4dddccf2b2
85d537e0-5f70-4359-a844-c93074cbeec5	ad434e3f-b929-4ff4-a80d-11feac16b136	f8c7e1aa-6839-4b19-b028-4f59d51bc095	C	MXN	3288.92	t	\N	\N	\N	2026-03-30 22:21:33.07	2026-03-30 22:21:36.455	717c4d0b-0c05-4a2c-be8e-0c4dddccf2b2
84ea47ae-904f-472f-8059-472f7f47ea3b	ad434e3f-b929-4ff4-a80d-11feac16b136	f8c7e1aa-6839-4b19-b028-4f59d51bc095	D	MXN	3453.35	t	\N	\N	\N	2026-03-30 22:21:33.085	2026-03-30 22:21:36.466	717c4d0b-0c05-4a2c-be8e-0c4dddccf2b2
9306af4f-77e0-457f-aed2-9a53698627b5	ad434e3f-b929-4ff4-a80d-11feac16b136	f8c7e1aa-6839-4b19-b028-4f59d51bc095	A	MXN	2990.35	t	\N	\N	\N	2026-03-30 22:21:33.106	2026-03-30 22:21:36.484	29a9988a-3f3b-4a1b-b817-c7a8adc049d7
f52458ca-b575-4724-95d5-3eb0886605cc	ad434e3f-b929-4ff4-a80d-11feac16b136	f8c7e1aa-6839-4b19-b028-4f59d51bc095	B	MXN	3139.84	t	\N	\N	\N	2026-03-30 22:21:33.116	2026-03-30 22:21:36.494	29a9988a-3f3b-4a1b-b817-c7a8adc049d7
56bff625-04a9-4dda-84bd-65c945bd1938	ad434e3f-b929-4ff4-a80d-11feac16b136	f8c7e1aa-6839-4b19-b028-4f59d51bc095	A	MXN	2621.21	t	\N	\N	\N	2026-03-30 22:21:29.819	2026-03-30 22:21:32.808	\N
30bbb88a-bff4-4cc8-b92f-1ce289cc6c9e	ad434e3f-b929-4ff4-a80d-11feac16b136	37c02803-58c5-45c1-941a-e2bf55cc7a8d	D	MXN	2924.86	t	\N	\N	\N	2026-03-30 22:21:29.975	2026-03-30 22:21:33.06	\N
adc86220-a3d4-4042-b93c-31c416a606c9	ad434e3f-b929-4ff4-a80d-11feac16b136	87dd282b-52da-4ff9-8998-5b825b13c5c9	B	MXN	2586.12	t	\N	\N	\N	2026-03-30 22:21:30.137	2026-03-30 22:21:33.278	\N
d13a9e45-b3ac-4bda-a924-72ef45dc92b8	ad434e3f-b929-4ff4-a80d-11feac16b136	e6e416d8-32ee-409e-9816-17c5e6f8b420	A	MXN	2804.72	t	\N	\N	\N	2026-03-30 22:21:30.39	2026-03-30 22:21:33.646	\N
ab692ad0-4422-4e3f-9583-f042175a88d7	ad434e3f-b929-4ff4-a80d-11feac16b136	61ccce64-d1d1-4e44-b290-287fcddf40cc	C	MXN	2678.82	t	\N	\N	\N	2026-03-30 22:21:30.569	2026-03-30 22:21:33.875	\N
6c0acb1f-863f-40cc-99ee-b7fc834ee392	ad434e3f-b929-4ff4-a80d-11feac16b136	e4bc3270-0a38-461e-a321-211a7ebd94b3	B	MXN	5357.12	t	\N	\N	\N	2026-03-30 22:21:30.849	2026-03-30 22:21:34.215	\N
1161d3cc-6eda-495d-b394-ae78960e2b92	ad434e3f-b929-4ff4-a80d-11feac16b136	008b256d-38f7-4781-83cf-04b1f624051e	D	MXN	5331.26	t	\N	\N	\N	2026-03-30 22:21:31.029	2026-03-30 22:21:34.415	\N
469d0f45-b5a5-4650-8de1-c032830cf98f	ad434e3f-b929-4ff4-a80d-11feac16b136	083a6238-60db-4b53-8617-f63f09870c1f	C	MXN	4944.00	t	\N	\N	\N	2026-03-30 22:21:31.303	2026-03-30 22:21:34.677	\N
df1ca66b-697d-4cb3-b44c-73daee29978f	ad434e3f-b929-4ff4-a80d-11feac16b136	4bbf5039-4c8e-4d07-80b1-b36bec5151d0	A	MXN	5633.04	t	\N	\N	\N	2026-03-30 22:21:31.477	2026-03-30 22:21:34.858	\N
7c8ee129-2327-4f55-bac4-ce621a451ceb	ad434e3f-b929-4ff4-a80d-11feac16b136	1a0d7974-ee17-486d-97b1-14297369167f	D	MXN	5617.10	t	\N	\N	\N	2026-03-30 22:21:31.692	2026-03-30 22:21:35.165	\N
62b39060-058f-423d-a2b9-860749d3bde4	ad434e3f-b929-4ff4-a80d-11feac16b136	71510889-5d8f-4f84-bc76-becbd3ca10be	C	MXN	26706.90	t	\N	\N	\N	2026-03-30 22:21:31.915	2026-03-30 22:21:35.44	\N
4b9edb0c-1eb1-489b-ad25-3a6cfa2143a0	ad434e3f-b929-4ff4-a80d-11feac16b136	9a0be7a1-0438-43d4-a43a-13f65ca12b09	B	MXN	3843.58	t	\N	\N	\N	2026-03-30 22:21:32.116	2026-03-30 22:21:35.648	ee5ec61e-2da0-4d99-9c6e-92608139d324
572fcb94-206e-4583-9968-d71f79885369	ad434e3f-b929-4ff4-a80d-11feac16b136	a18ee5db-cad6-45cb-a472-37975cdecc02	D	MXN	4620.90	t	\N	\N	\N	2026-03-30 22:21:32.359	2026-03-30 22:21:35.837	c1d7fd57-440c-4240-808e-2352e855e377
bad907e2-ad51-4671-857b-1c0d35b35089	ad434e3f-b929-4ff4-a80d-11feac16b136	8f35dd7b-cb84-4b7a-9c17-9de37fdbcf0c	B	MXN	3599.64	t	\N	\N	\N	2026-03-30 22:21:32.614	2026-03-30 22:21:36.04	66892415-6ff3-407c-a22f-703cc3543486
9ce28b8a-4c46-4aac-b2d2-b6e75c0b3fbe	ad434e3f-b929-4ff4-a80d-11feac16b136	8f35dd7b-cb84-4b7a-9c17-9de37fdbcf0c	B	MXN	3607.15	t	\N	\N	\N	2026-03-30 22:21:32.732	2026-03-30 22:21:36.134	eeb421ef-52ec-4b87-a90a-a70e320322dd
d20859a1-9ecf-4dc5-b497-78c8a4822244	ad434e3f-b929-4ff4-a80d-11feac16b136	f8c7e1aa-6839-4b19-b028-4f59d51bc095	C	MXN	3296.81	t	\N	\N	\N	2026-03-30 22:21:33.125	2026-03-30 22:21:36.503	29a9988a-3f3b-4a1b-b817-c7a8adc049d7
b8e08037-cd7d-4b07-a070-1bb56bcc3a50	ad434e3f-b929-4ff4-a80d-11feac16b136	f8c7e1aa-6839-4b19-b028-4f59d51bc095	C	MXN	3530.67	t	\N	\N	\N	2026-03-30 22:21:33.217	2026-03-30 22:21:36.584	67380c1f-994e-40ee-b5c7-6b606a9891e1
adc30999-a6cf-48fa-adc4-aa920e798a63	ad434e3f-b929-4ff4-a80d-11feac16b136	b15298f9-bfa6-455f-8c61-b2dc71a0028e	D	MXN	3410.42	t	\N	\N	\N	2026-03-30 22:21:33.583	2026-03-30 22:21:36.858	fbc4caaf-b78e-47b6-817e-88be0f7a60bb
ac872db3-fcf0-4c1e-b6a6-9c640ec235e9	ad434e3f-b929-4ff4-a80d-11feac16b136	06c7a87d-5bbf-48ec-9a65-899b069cf396	D	MXN	3137.62	t	\N	\N	\N	2026-03-30 22:21:33.692	2026-03-30 22:21:36.939	8b3ce486-2880-47e2-89ae-4de080826b9a
9d5ccfd6-468b-40cd-9873-ba9e31340f07	ad434e3f-b929-4ff4-a80d-11feac16b136	ada8d0ac-6b3d-46a8-ac98-8a1b1192a7ae	A	MXN	3818.96	t	\N	\N	\N	2026-03-30 22:21:34.054	2026-03-30 22:21:37.262	51d2205d-1d44-4a3f-81ce-defe85beb38b
b94744a1-f8dd-4af8-97e9-0b704f9b1ccf	ad434e3f-b929-4ff4-a80d-11feac16b136	ada8d0ac-6b3d-46a8-ac98-8a1b1192a7ae	A	MXN	3954.10	t	\N	\N	\N	2026-03-30 22:21:34.141	2026-03-30 22:21:37.385	8bc594fe-1343-4eaf-97a5-7aa6801fdf31
38cc5106-02a3-435e-848b-89f60c003ac1	ad434e3f-b929-4ff4-a80d-11feac16b136	73f4aef0-f656-4768-9818-07129ee45791	B	MXN	4054.36	t	\N	\N	\N	2026-03-30 22:21:34.471	2026-03-30 22:21:37.833	d2b40e91-b109-4082-ac23-072fb43cd14d
2c80797a-8dea-4282-93a6-97c823b3123d	ad434e3f-b929-4ff4-a80d-11feac16b136	73f4aef0-f656-4768-9818-07129ee45791	B	MXN	4274.48	t	\N	\N	\N	2026-03-30 22:21:34.548	2026-03-30 22:21:37.942	f0c01c30-d31d-420f-a434-a1354beb7d90
16016a9a-2c9f-4ec8-b151-9361659e26da	ad434e3f-b929-4ff4-a80d-11feac16b136	1b778817-d9ab-428b-bdf1-9ebe3ed039ae	C	MXN	3645.24	t	\N	\N	\N	2026-03-30 22:21:34.816	2026-03-30 22:21:38.318	006f2288-6372-4c73-8186-879d6b4de577
b695727e-988c-4c43-b05f-0e6685262c86	ad434e3f-b929-4ff4-a80d-11feac16b136	e6e416d8-32ee-409e-9816-17c5e6f8b420	C	MXN	3668.83	t	\N	\N	\N	2026-03-30 22:21:34.891	2026-03-30 22:21:38.406	04e79f99-bdf3-46f5-aed9-6e4d79cfbc98
55633751-458f-49cc-b105-ad0d7519dd28	ad434e3f-b929-4ff4-a80d-11feac16b136	fc47eeb3-86e6-4a97-8964-821b5861a39d	D	MXN	3941.12	t	\N	\N	\N	2026-03-30 22:21:35.249	2026-03-30 22:21:38.759	2b5fcf25-3601-479a-b829-c76e07c88da5
b50b2f08-a0db-40f4-a364-c8c4df8cad2a	ad434e3f-b929-4ff4-a80d-11feac16b136	4cb2e968-181c-4d39-be42-ef153c26cc63	D	MXN	3666.78	t	\N	\N	\N	2026-03-30 22:21:35.324	2026-03-30 22:21:38.905	c74ba569-cd40-4ea7-ab94-dda33e35a403
3e0041fe-ca56-4b2f-8e84-0e6869734b45	ad434e3f-b929-4ff4-a80d-11feac16b136	4d35c1d2-e088-4393-b2fb-ed2e7b7b511d	A	MXN	3047.58	t	\N	\N	\N	2026-03-30 22:21:35.632	2026-03-30 22:21:39.281	029a73b5-1508-42b8-8409-cf6d31991cbe
d113a350-e89f-4fe9-9085-7c6cd89f8c59	ad434e3f-b929-4ff4-a80d-11feac16b136	e8b0d497-0784-48dc-9622-fa1c0ff0afc6	A	MXN	2854.66	t	\N	\N	\N	2026-03-30 22:21:35.702	2026-03-30 22:21:39.364	9aaf4531-2747-47d4-aec4-3b3e3d7470e5
9b7a8e4e-1cd6-4cfb-8848-412db00ca837	ad434e3f-b929-4ff4-a80d-11feac16b136	d6d4bb71-ab21-43b4-9187-41dc7eb19dc1	B	MXN	6880.32	t	\N	\N	\N	2026-03-30 22:21:35.991	2026-03-30 22:21:39.7	7616453f-08d1-4fe2-9463-d22d04401c88
9f2d8180-85bb-4da4-8cf2-91abe8c95d9d	ad434e3f-b929-4ff4-a80d-11feac16b136	26d54ae1-6589-404b-b97e-5844a49a4126	B	MXN	6204.82	t	\N	\N	\N	2026-03-30 22:21:36.074	2026-03-30 22:21:39.787	762ef71e-b6c3-4311-81e9-b7ef591e442c
1ee326d8-692e-449d-abe5-0d63ca7c1f58	ad434e3f-b929-4ff4-a80d-11feac16b136	bcd1b43e-9c32-4fb2-a63a-791fd575e91c	C	MXN	6113.78	t	\N	\N	\N	2026-03-30 22:21:36.42	2026-03-30 22:21:40.104	9d0373fb-cc23-451a-9b90-cf01c2f65e74
883e54d5-2922-4f89-b2f5-6a696964dbde	ad434e3f-b929-4ff4-a80d-11feac16b136	008b256d-38f7-4781-83cf-04b1f624051e	C	MXN	5891.33	t	\N	\N	\N	2026-03-30 22:21:36.506	2026-03-30 22:21:40.191	2c571442-156d-4258-b1d1-4a369f742bd4
67c29a9b-c802-49b3-827c-b4f1cf5cdd1b	ad434e3f-b929-4ff4-a80d-11feac16b136	bd2b7acf-9367-419f-a8b1-7e4053fd4ff9	D	MXN	6008.05	t	\N	\N	\N	2026-03-30 22:21:36.778	2026-03-30 22:21:40.472	d6beb8d9-dbf3-46cf-a9a7-ac7f8f01665c
4f653c9c-8f01-4d69-ba12-7a673bd5a4b8	ad434e3f-b929-4ff4-a80d-11feac16b136	bd2b7acf-9367-419f-a8b1-7e4053fd4ff9	D	MXN	6326.67	t	\N	\N	\N	2026-03-30 22:21:36.848	2026-03-30 22:21:40.544	a441d2fb-8dc3-42f8-a4bb-4eeb0a42fbf1
8af3094b-8a12-41b2-8558-1edb3e10bae8	ad434e3f-b929-4ff4-a80d-11feac16b136	421a93a9-10a5-418f-bb61-8c29065e7a8b	A	MXN	5161.23	t	\N	\N	\N	2026-03-30 22:21:37.148	2026-03-30 22:21:40.829	d6df0e90-98cf-416e-90dc-9c18f2b3a32b
913a68a6-a32d-4cd9-ad95-e3150855f879	ad434e3f-b929-4ff4-a80d-11feac16b136	cf163728-3824-4dae-a07c-4396b0da3382	A	MXN	5483.72	t	\N	\N	\N	2026-03-30 22:21:37.227	2026-03-30 22:21:40.897	e6de4041-2cd2-4c7a-bfc7-1124707d13da
aab672f9-d678-4c10-9002-70362e6a24b9	ad434e3f-b929-4ff4-a80d-11feac16b136	a2cec753-8d86-42f4-9f45-16aaf894e4b2	B	MXN	7573.84	t	\N	\N	\N	2026-03-30 22:21:37.688	2026-03-30 22:21:41.16	7fb776aa-f13b-44b2-9091-d89f40ded4fd
cd8f5785-80ad-4b3a-994e-2a940fd03155	ad434e3f-b929-4ff4-a80d-11feac16b136	a2cec753-8d86-42f4-9f45-16aaf894e4b2	B	MXN	8014.08	t	\N	\N	\N	2026-03-30 22:21:37.786	2026-03-30 22:21:41.252	a54cbdf6-0d40-4541-898d-397dcb8bd715
f4303fc0-3f44-423e-8e6a-e1b89bae2ab7	ad434e3f-b929-4ff4-a80d-11feac16b136	f8c7e1aa-6839-4b19-b028-4f59d51bc095	D	MXN	3461.64	t	\N	\N	\N	2026-03-30 22:21:33.136	2026-03-30 22:21:36.511	29a9988a-3f3b-4a1b-b817-c7a8adc049d7
90c1411d-228c-44ff-ad56-c660defa8a70	ad434e3f-b929-4ff4-a80d-11feac16b136	f8c7e1aa-6839-4b19-b028-4f59d51bc095	A	MXN	3120.82	t	\N	\N	\N	2026-03-30 22:21:33.157	2026-03-30 22:21:36.527	196f8b13-af1d-4a46-8fdd-07172ddab25c
4ed89b4e-9388-4c8f-a55f-1135334e2c96	ad434e3f-b929-4ff4-a80d-11feac16b136	f8c7e1aa-6839-4b19-b028-4f59d51bc095	B	MXN	3276.83	t	\N	\N	\N	2026-03-30 22:21:33.165	2026-03-30 22:21:36.534	196f8b13-af1d-4a46-8fdd-07172ddab25c
c53506d4-8bb8-459e-a97e-b84fb9a0e04c	ad434e3f-b929-4ff4-a80d-11feac16b136	f8c7e1aa-6839-4b19-b028-4f59d51bc095	C	MXN	3440.65	t	\N	\N	\N	2026-03-30 22:21:33.173	2026-03-30 22:21:36.54	196f8b13-af1d-4a46-8fdd-07172ddab25c
72cd7c1e-3e84-4d9f-82d1-bad3df5fbf00	ad434e3f-b929-4ff4-a80d-11feac16b136	f8c7e1aa-6839-4b19-b028-4f59d51bc095	D	MXN	3612.66	t	\N	\N	\N	2026-03-30 22:21:33.181	2026-03-30 22:21:36.55	196f8b13-af1d-4a46-8fdd-07172ddab25c
4cb6df03-51c0-4503-93f6-0ef3e6b55fc1	ad434e3f-b929-4ff4-a80d-11feac16b136	f8c7e1aa-6839-4b19-b028-4f59d51bc095	A	MXN	3202.47	t	\N	\N	\N	2026-03-30 22:21:33.198	2026-03-30 22:21:36.566	67380c1f-994e-40ee-b5c7-6b606a9891e1
983a1975-0c91-4648-9be9-a81b680b2f23	ad434e3f-b929-4ff4-a80d-11feac16b136	f8c7e1aa-6839-4b19-b028-4f59d51bc095	B	MXN	3362.57	t	\N	\N	\N	2026-03-30 22:21:33.205	2026-03-30 22:21:36.575	67380c1f-994e-40ee-b5c7-6b606a9891e1
9dc162f6-bd8f-4461-8ddf-a2def60ed71f	ad434e3f-b929-4ff4-a80d-11feac16b136	f8c7e1aa-6839-4b19-b028-4f59d51bc095	D	MXN	3707.19	t	\N	\N	\N	2026-03-30 22:21:33.226	2026-03-30 22:21:36.591	67380c1f-994e-40ee-b5c7-6b606a9891e1
81fd444e-ee5e-4c2e-8b1f-b99a5e2d69b6	ad434e3f-b929-4ff4-a80d-11feac16b136	be7e9360-211f-46a7-b1e6-9e5fa0d486e7	A	MXN	2825.87	t	\N	\N	\N	2026-03-30 22:21:33.243	2026-03-30 22:21:36.609	101dfe1f-4d63-47b8-b9f6-19f58ce66063
b88f5df7-d01c-41b8-8efa-4fa686599f40	ad434e3f-b929-4ff4-a80d-11feac16b136	be7e9360-211f-46a7-b1e6-9e5fa0d486e7	B	MXN	2967.15	t	\N	\N	\N	2026-03-30 22:21:33.252	2026-03-30 22:21:36.618	101dfe1f-4d63-47b8-b9f6-19f58ce66063
2edd08f9-0bcf-40ec-b374-381e51761c20	ad434e3f-b929-4ff4-a80d-11feac16b136	be7e9360-211f-46a7-b1e6-9e5fa0d486e7	C	MXN	3115.48	t	\N	\N	\N	2026-03-30 22:21:33.262	2026-03-30 22:21:36.628	101dfe1f-4d63-47b8-b9f6-19f58ce66063
9fecc211-95e8-4b43-9602-ae9c443c1888	ad434e3f-b929-4ff4-a80d-11feac16b136	be7e9360-211f-46a7-b1e6-9e5fa0d486e7	D	MXN	3271.24	t	\N	\N	\N	2026-03-30 22:21:33.277	2026-03-30 22:21:36.637	101dfe1f-4d63-47b8-b9f6-19f58ce66063
26f5787d-61a9-44b6-8c0d-9411e37ccea4	ad434e3f-b929-4ff4-a80d-11feac16b136	be7e9360-211f-46a7-b1e6-9e5fa0d486e7	A	MXN	2833.03	t	\N	\N	\N	2026-03-30 22:21:33.292	2026-03-30 22:21:36.652	cf9584cf-24d0-4cee-b6be-2993ba34f9bb
3cc15b57-d8fc-433d-a38e-6510111494d9	ad434e3f-b929-4ff4-a80d-11feac16b136	be7e9360-211f-46a7-b1e6-9e5fa0d486e7	B	MXN	2974.66	t	\N	\N	\N	2026-03-30 22:21:33.299	2026-03-30 22:21:36.659	cf9584cf-24d0-4cee-b6be-2993ba34f9bb
715fbc8c-d446-406d-8c57-387af922e2ca	ad434e3f-b929-4ff4-a80d-11feac16b136	be7e9360-211f-46a7-b1e6-9e5fa0d486e7	C	MXN	3123.37	t	\N	\N	\N	2026-03-30 22:21:33.306	2026-03-30 22:21:36.668	cf9584cf-24d0-4cee-b6be-2993ba34f9bb
96e42826-b97c-4d96-b53d-45ca59f0db19	ad434e3f-b929-4ff4-a80d-11feac16b136	be7e9360-211f-46a7-b1e6-9e5fa0d486e7	D	MXN	3279.53	t	\N	\N	\N	2026-03-30 22:21:33.315	2026-03-30 22:21:36.676	cf9584cf-24d0-4cee-b6be-2993ba34f9bb
52990698-41ad-4ceb-9eeb-57a7e115256d	ad434e3f-b929-4ff4-a80d-11feac16b136	be7e9360-211f-46a7-b1e6-9e5fa0d486e7	A	MXN	2963.50	t	\N	\N	\N	2026-03-30 22:21:33.329	2026-03-30 22:21:36.692	7c4afeae-7beb-4ebf-8313-75ec187e9d14
351cb0ef-6fe6-44b4-b127-b6861ddf505b	ad434e3f-b929-4ff4-a80d-11feac16b136	be7e9360-211f-46a7-b1e6-9e5fa0d486e7	B	MXN	3111.65	t	\N	\N	\N	2026-03-30 22:21:33.338	2026-03-30 22:21:36.7	7c4afeae-7beb-4ebf-8313-75ec187e9d14
29daf2e7-3ab4-43b6-9169-86656b3bbb80	ad434e3f-b929-4ff4-a80d-11feac16b136	be7e9360-211f-46a7-b1e6-9e5fa0d486e7	C	MXN	3267.21	t	\N	\N	\N	2026-03-30 22:21:33.347	2026-03-30 22:21:36.708	7c4afeae-7beb-4ebf-8313-75ec187e9d14
22c1759c-b1b7-4ab4-97de-692e79efb96e	ad434e3f-b929-4ff4-a80d-11feac16b136	be7e9360-211f-46a7-b1e6-9e5fa0d486e7	D	MXN	3430.55	t	\N	\N	\N	2026-03-30 22:21:33.354	2026-03-30 22:21:36.715	7c4afeae-7beb-4ebf-8313-75ec187e9d14
59deb47d-d7c1-4dd7-8ea5-14b2035762d4	ad434e3f-b929-4ff4-a80d-11feac16b136	be7e9360-211f-46a7-b1e6-9e5fa0d486e7	A	MXN	3045.15	t	\N	\N	\N	2026-03-30 22:21:33.37	2026-03-30 22:21:36.731	feb4eb22-43a6-4ea9-8cb0-dc8e7ff060b3
b14ce263-2756-4def-8d02-6fbf69b262e2	ad434e3f-b929-4ff4-a80d-11feac16b136	be7e9360-211f-46a7-b1e6-9e5fa0d486e7	B	MXN	3197.39	t	\N	\N	\N	2026-03-30 22:21:33.377	2026-03-30 22:21:36.738	feb4eb22-43a6-4ea9-8cb0-dc8e7ff060b3
4b9402b6-2714-403a-bcdc-f05ed28a448d	ad434e3f-b929-4ff4-a80d-11feac16b136	be7e9360-211f-46a7-b1e6-9e5fa0d486e7	C	MXN	3357.23	t	\N	\N	\N	2026-03-30 22:21:33.386	2026-03-30 22:21:36.744	feb4eb22-43a6-4ea9-8cb0-dc8e7ff060b3
b5c4fc75-17a3-4c26-9bbc-a0fae4123594	ad434e3f-b929-4ff4-a80d-11feac16b136	be7e9360-211f-46a7-b1e6-9e5fa0d486e7	D	MXN	3525.08	t	\N	\N	\N	2026-03-30 22:21:33.395	2026-03-30 22:21:36.75	feb4eb22-43a6-4ea9-8cb0-dc8e7ff060b3
47407bfe-e5ea-4b28-a226-202fa5390856	ad434e3f-b929-4ff4-a80d-11feac16b136	b15298f9-bfa6-455f-8c61-b2dc71a0028e	A	MXN	2808.48	t	\N	\N	\N	2026-03-30 22:21:33.411	2026-03-30 22:21:36.765	c90fd1e9-2d31-43e4-869f-15eb2bff11f8
8c19d18d-c5cf-424d-8701-93c0343b98db	ad434e3f-b929-4ff4-a80d-11feac16b136	b15298f9-bfa6-455f-8c61-b2dc71a0028e	B	MXN	2948.89	t	\N	\N	\N	2026-03-30 22:21:33.422	2026-03-30 22:21:36.771	c90fd1e9-2d31-43e4-869f-15eb2bff11f8
9425e9d3-b1c2-40ac-b0c6-8b2e298fd112	ad434e3f-b929-4ff4-a80d-11feac16b136	b15298f9-bfa6-455f-8c61-b2dc71a0028e	C	MXN	3096.31	t	\N	\N	\N	2026-03-30 22:21:33.44	2026-03-30 22:21:36.778	c90fd1e9-2d31-43e4-869f-15eb2bff11f8
8ed67732-d238-4d46-8a8f-636c0b68dab7	ad434e3f-b929-4ff4-a80d-11feac16b136	b15298f9-bfa6-455f-8c61-b2dc71a0028e	D	MXN	3251.11	t	\N	\N	\N	2026-03-30 22:21:33.447	2026-03-30 22:21:36.786	c90fd1e9-2d31-43e4-869f-15eb2bff11f8
7839fbcd-dd4e-479e-8218-841035261041	ad434e3f-b929-4ff4-a80d-11feac16b136	b15298f9-bfa6-455f-8c61-b2dc71a0028e	A	MXN	2815.64	t	\N	\N	\N	2026-03-30 22:21:33.47	2026-03-30 22:21:36.803	72a9fb66-c4e2-49bc-bead-db7ee8bd5998
9d9571fc-f9d2-4e9e-81b4-13db26782b95	ad434e3f-b929-4ff4-a80d-11feac16b136	b15298f9-bfa6-455f-8c61-b2dc71a0028e	B	MXN	2956.40	t	\N	\N	\N	2026-03-30 22:21:33.485	2026-03-30 22:21:36.811	72a9fb66-c4e2-49bc-bead-db7ee8bd5998
d8558b9b-c914-4217-a277-e0e14562bed7	ad434e3f-b929-4ff4-a80d-11feac16b136	b15298f9-bfa6-455f-8c61-b2dc71a0028e	C	MXN	3104.20	t	\N	\N	\N	2026-03-30 22:21:33.493	2026-03-30 22:21:36.818	72a9fb66-c4e2-49bc-bead-db7ee8bd5998
cf39beaf-77f5-4cdc-adcd-de53815fda5d	ad434e3f-b929-4ff4-a80d-11feac16b136	b15298f9-bfa6-455f-8c61-b2dc71a0028e	D	MXN	3259.40	t	\N	\N	\N	2026-03-30 22:21:33.501	2026-03-30 22:21:36.825	72a9fb66-c4e2-49bc-bead-db7ee8bd5998
7b9761b2-0a1f-4f15-a953-4fac0ee6c3b0	ad434e3f-b929-4ff4-a80d-11feac16b136	b15298f9-bfa6-455f-8c61-b2dc71a0028e	A	MXN	2946.11	t	\N	\N	\N	2026-03-30 22:21:33.54	2026-03-30 22:21:36.838	fbc4caaf-b78e-47b6-817e-88be0f7a60bb
d7ab2363-5126-4064-a5eb-76aed0fa41f4	ad434e3f-b929-4ff4-a80d-11feac16b136	b15298f9-bfa6-455f-8c61-b2dc71a0028e	B	MXN	3093.39	t	\N	\N	\N	2026-03-30 22:21:33.554	2026-03-30 22:21:36.844	fbc4caaf-b78e-47b6-817e-88be0f7a60bb
24f3a6eb-e243-4cdb-af6d-4965115b9fe5	ad434e3f-b929-4ff4-a80d-11feac16b136	b15298f9-bfa6-455f-8c61-b2dc71a0028e	C	MXN	3248.04	t	\N	\N	\N	2026-03-30 22:21:33.566	2026-03-30 22:21:36.851	fbc4caaf-b78e-47b6-817e-88be0f7a60bb
67269213-745c-435e-8098-6f296773a5cf	ad434e3f-b929-4ff4-a80d-11feac16b136	b15298f9-bfa6-455f-8c61-b2dc71a0028e	A	MXN	3027.76	t	\N	\N	\N	2026-03-30 22:21:33.608	2026-03-30 22:21:36.875	267b31dd-3018-419b-b0f9-c1912b372420
3e94fdd8-5468-4e7b-9ed3-573c4f203db9	ad434e3f-b929-4ff4-a80d-11feac16b136	b15298f9-bfa6-455f-8c61-b2dc71a0028e	B	MXN	3179.13	t	\N	\N	\N	2026-03-30 22:21:33.621	2026-03-30 22:21:36.884	267b31dd-3018-419b-b0f9-c1912b372420
b49d1c9f-5181-4a6e-b5f8-29439ea241ef	ad434e3f-b929-4ff4-a80d-11feac16b136	b15298f9-bfa6-455f-8c61-b2dc71a0028e	C	MXN	3338.06	t	\N	\N	\N	2026-03-30 22:21:33.64	2026-03-30 22:21:36.891	267b31dd-3018-419b-b0f9-c1912b372420
27802fec-35dd-43c7-a340-eb51d6f93372	ad434e3f-b929-4ff4-a80d-11feac16b136	b15298f9-bfa6-455f-8c61-b2dc71a0028e	D	MXN	3504.95	t	\N	\N	\N	2026-03-30 22:21:33.647	2026-03-30 22:21:36.9	267b31dd-3018-419b-b0f9-c1912b372420
03f7eb3f-8bfa-4913-af21-dad44e529d00	ad434e3f-b929-4ff4-a80d-11feac16b136	06c7a87d-5bbf-48ec-9a65-899b069cf396	A	MXN	2710.43	t	\N	\N	\N	2026-03-30 22:21:33.663	2026-03-30 22:21:36.917	8b3ce486-2880-47e2-89ae-4de080826b9a
b6983ef7-2282-4dea-b3a4-a20192ebc491	ad434e3f-b929-4ff4-a80d-11feac16b136	06c7a87d-5bbf-48ec-9a65-899b069cf396	B	MXN	2845.94	t	\N	\N	\N	2026-03-30 22:21:33.673	2026-03-30 22:21:36.924	8b3ce486-2880-47e2-89ae-4de080826b9a
bc1b21e9-93e9-4223-b178-3c466d6f5c0e	ad434e3f-b929-4ff4-a80d-11feac16b136	06c7a87d-5bbf-48ec-9a65-899b069cf396	C	MXN	2988.22	t	\N	\N	\N	2026-03-30 22:21:33.683	2026-03-30 22:21:36.932	8b3ce486-2880-47e2-89ae-4de080826b9a
5cfacecb-fdb3-4dbe-aeee-35246e0573be	ad434e3f-b929-4ff4-a80d-11feac16b136	37c02803-58c5-45c1-941a-e2bf55cc7a8d	A	MXN	2876.03	t	\N	\N	\N	2026-03-30 22:21:33.714	2026-03-30 22:21:36.956	edae2faf-3ccc-42a6-a12f-cd76f29935c5
80197464-c8c6-4c5f-9d71-7677f454ca96	ad434e3f-b929-4ff4-a80d-11feac16b136	37c02803-58c5-45c1-941a-e2bf55cc7a8d	B	MXN	3019.82	t	\N	\N	\N	2026-03-30 22:21:33.721	2026-03-30 22:21:36.964	edae2faf-3ccc-42a6-a12f-cd76f29935c5
373f083c-ff2a-4dcc-a9ec-92296d9314df	ad434e3f-b929-4ff4-a80d-11feac16b136	37c02803-58c5-45c1-941a-e2bf55cc7a8d	C	MXN	3170.79	t	\N	\N	\N	2026-03-30 22:21:33.738	2026-03-30 22:21:36.971	edae2faf-3ccc-42a6-a12f-cd76f29935c5
5da9f3dd-b271-4437-b67c-468c6ab6883a	ad434e3f-b929-4ff4-a80d-11feac16b136	37c02803-58c5-45c1-941a-e2bf55cc7a8d	D	MXN	3329.32	t	\N	\N	\N	2026-03-30 22:21:33.748	2026-03-30 22:21:36.979	edae2faf-3ccc-42a6-a12f-cd76f29935c5
60d3a12f-189a-4f37-8145-9caf4aaa5522	ad434e3f-b929-4ff4-a80d-11feac16b136	74121cef-f590-4d31-a33e-32c92ef65fd8	A	MXN	2718.70	t	\N	\N	\N	2026-03-30 22:21:33.773	2026-03-30 22:21:36.993	a649fef5-8804-4668-9a77-1392d947eb14
624ac737-84f6-4946-8582-5540f6c1c008	ad434e3f-b929-4ff4-a80d-11feac16b136	74121cef-f590-4d31-a33e-32c92ef65fd8	B	MXN	2854.63	t	\N	\N	\N	2026-03-30 22:21:33.794	2026-03-30 22:21:37.002	a649fef5-8804-4668-9a77-1392d947eb14
9ae2b98d-3259-4799-b984-350fb685be0b	ad434e3f-b929-4ff4-a80d-11feac16b136	74121cef-f590-4d31-a33e-32c92ef65fd8	C	MXN	2997.34	t	\N	\N	\N	2026-03-30 22:21:33.805	2026-03-30 22:21:37.009	a649fef5-8804-4668-9a77-1392d947eb14
a9e5a167-c46a-4182-abc6-8f7fbc4811f7	ad434e3f-b929-4ff4-a80d-11feac16b136	74121cef-f590-4d31-a33e-32c92ef65fd8	D	MXN	3147.19	t	\N	\N	\N	2026-03-30 22:21:33.811	2026-03-30 22:21:37.018	a649fef5-8804-4668-9a77-1392d947eb14
d84e345e-6bcd-4285-bff5-89425f800f0d	ad434e3f-b929-4ff4-a80d-11feac16b136	6407104f-cf91-4ada-8daa-ba613ced763e	A	MXN	2703.90	t	\N	\N	\N	2026-03-30 22:21:33.825	2026-03-30 22:21:37.039	f3b253ff-6323-4831-9410-1e7916dc7437
f11cbe9c-40a9-482b-aabc-f11c7dcd43d0	ad434e3f-b929-4ff4-a80d-11feac16b136	6407104f-cf91-4ada-8daa-ba613ced763e	B	MXN	2839.09	t	\N	\N	\N	2026-03-30 22:21:33.834	2026-03-30 22:21:37.048	f3b253ff-6323-4831-9410-1e7916dc7437
25a42622-ebf2-49ae-9019-860ed025a19b	ad434e3f-b929-4ff4-a80d-11feac16b136	6407104f-cf91-4ada-8daa-ba613ced763e	C	MXN	2981.03	t	\N	\N	\N	2026-03-30 22:21:33.842	2026-03-30 22:21:37.056	f3b253ff-6323-4831-9410-1e7916dc7437
2a92c345-9ab2-42a1-a952-10462d1ad4d5	ad434e3f-b929-4ff4-a80d-11feac16b136	6407104f-cf91-4ada-8daa-ba613ced763e	D	MXN	3130.07	t	\N	\N	\N	2026-03-30 22:21:33.849	2026-03-30 22:21:37.065	f3b253ff-6323-4831-9410-1e7916dc7437
0b08324b-17f5-4a60-8ca7-bce06ddaa92b	ad434e3f-b929-4ff4-a80d-11feac16b136	93b0a71f-5e96-4ddb-b6bf-76ebd51d44eb	A	MXN	2900.42	t	\N	\N	\N	2026-03-30 22:21:33.865	2026-03-30 22:21:37.085	a3193b94-f506-44dc-bbb3-e51442f82ee8
c723dea2-0fc0-4fdb-8f93-877c7e35e0c4	ad434e3f-b929-4ff4-a80d-11feac16b136	93b0a71f-5e96-4ddb-b6bf-76ebd51d44eb	B	MXN	3045.43	t	\N	\N	\N	2026-03-30 22:21:33.874	2026-03-30 22:21:37.095	a3193b94-f506-44dc-bbb3-e51442f82ee8
afaa6207-d5b1-4213-bc25-47918eab66f8	ad434e3f-b929-4ff4-a80d-11feac16b136	93b0a71f-5e96-4ddb-b6bf-76ebd51d44eb	C	MXN	3197.69	t	\N	\N	\N	2026-03-30 22:21:33.883	2026-03-30 22:21:37.103	a3193b94-f506-44dc-bbb3-e51442f82ee8
bb9e3eff-0566-44d2-aa91-fb0b74257b55	ad434e3f-b929-4ff4-a80d-11feac16b136	93b0a71f-5e96-4ddb-b6bf-76ebd51d44eb	D	MXN	3357.55	t	\N	\N	\N	2026-03-30 22:21:33.891	2026-03-30 22:21:37.111	a3193b94-f506-44dc-bbb3-e51442f82ee8
4c86f225-72ae-4dde-a226-91cda72d3b4a	ad434e3f-b929-4ff4-a80d-11feac16b136	6671b2b0-0dd0-481f-92f9-1a8b63183027	A	MXN	3090.04	t	\N	\N	\N	2026-03-30 22:21:33.91	2026-03-30 22:21:37.129	862ee54c-d67e-4fea-8582-c75b899765e7
a024cfec-5f14-40cc-854d-72e25be5d25e	ad434e3f-b929-4ff4-a80d-11feac16b136	6671b2b0-0dd0-481f-92f9-1a8b63183027	B	MXN	3244.53	t	\N	\N	\N	2026-03-30 22:21:33.921	2026-03-30 22:21:37.14	862ee54c-d67e-4fea-8582-c75b899765e7
3c58d86c-a9ba-4e0a-a2c4-c0d0cb371236	ad434e3f-b929-4ff4-a80d-11feac16b136	6671b2b0-0dd0-481f-92f9-1a8b63183027	C	MXN	3406.74	t	\N	\N	\N	2026-03-30 22:21:33.929	2026-03-30 22:21:37.149	862ee54c-d67e-4fea-8582-c75b899765e7
a0e23419-c6a9-4e3c-9607-89a8511bae76	ad434e3f-b929-4ff4-a80d-11feac16b136	6671b2b0-0dd0-481f-92f9-1a8b63183027	D	MXN	3577.06	t	\N	\N	\N	2026-03-30 22:21:33.939	2026-03-30 22:21:37.157	862ee54c-d67e-4fea-8582-c75b899765e7
0c65bfeb-05f6-4b18-a2b6-26c33ee4c608	ad434e3f-b929-4ff4-a80d-11feac16b136	87dd282b-52da-4ff9-8998-5b825b13c5c9	A	MXN	2919.11	t	\N	\N	\N	2026-03-30 22:21:33.963	2026-03-30 22:21:37.171	061d45b0-ac8b-43d5-a62d-c293c65f0557
f817c9e3-5f1d-48a8-b402-57998a6d034b	ad434e3f-b929-4ff4-a80d-11feac16b136	87dd282b-52da-4ff9-8998-5b825b13c5c9	B	MXN	3065.06	t	\N	\N	\N	2026-03-30 22:21:33.973	2026-03-30 22:21:37.179	061d45b0-ac8b-43d5-a62d-c293c65f0557
a125a1e1-61ba-472e-bbe4-94cb74b05844	ad434e3f-b929-4ff4-a80d-11feac16b136	87dd282b-52da-4ff9-8998-5b825b13c5c9	C	MXN	3218.30	t	\N	\N	\N	2026-03-30 22:21:33.983	2026-03-30 22:21:37.187	061d45b0-ac8b-43d5-a62d-c293c65f0557
3f9d5d09-4283-45cf-b748-3389936c8445	ad434e3f-b929-4ff4-a80d-11feac16b136	87dd282b-52da-4ff9-8998-5b825b13c5c9	D	MXN	3379.20	t	\N	\N	\N	2026-03-30 22:21:33.992	2026-03-30 22:21:37.195	061d45b0-ac8b-43d5-a62d-c293c65f0557
eb1bf263-7c41-4f62-aaaa-d8025e48dfcc	ad434e3f-b929-4ff4-a80d-11feac16b136	879eda6d-128f-4680-b285-53bab6334a3e	A	MXN	2897.12	t	\N	\N	\N	2026-03-30 22:21:34.011	2026-03-30 22:21:37.214	7d2d18ee-6693-44ea-b96b-1811a159aa8c
e60d950b-d8fd-4b54-b78c-3e18dd71f211	ad434e3f-b929-4ff4-a80d-11feac16b136	879eda6d-128f-4680-b285-53bab6334a3e	B	MXN	3041.97	t	\N	\N	\N	2026-03-30 22:21:34.021	2026-03-30 22:21:37.223	7d2d18ee-6693-44ea-b96b-1811a159aa8c
6d1642d9-3cb3-4459-b66e-19fcc2beae69	ad434e3f-b929-4ff4-a80d-11feac16b136	879eda6d-128f-4680-b285-53bab6334a3e	C	MXN	3194.05	t	\N	\N	\N	2026-03-30 22:21:34.029	2026-03-30 22:21:37.231	7d2d18ee-6693-44ea-b96b-1811a159aa8c
206d8f77-9c0e-4fd3-bbe2-3b91b9a57867	ad434e3f-b929-4ff4-a80d-11feac16b136	879eda6d-128f-4680-b285-53bab6334a3e	D	MXN	3353.73	t	\N	\N	\N	2026-03-30 22:21:34.036	2026-03-30 22:21:37.24	7d2d18ee-6693-44ea-b96b-1811a159aa8c
fdd9f59a-bda8-431f-a309-8c3ddcc52864	ad434e3f-b929-4ff4-a80d-11feac16b136	ada8d0ac-6b3d-46a8-ac98-8a1b1192a7ae	B	MXN	4009.88	t	\N	\N	\N	2026-03-30 22:21:34.064	2026-03-30 22:21:37.274	51d2205d-1d44-4a3f-81ce-defe85beb38b
72032d3a-9f89-4eec-a234-7dd9e974f6a0	ad434e3f-b929-4ff4-a80d-11feac16b136	ada8d0ac-6b3d-46a8-ac98-8a1b1192a7ae	C	MXN	4210.36	t	\N	\N	\N	2026-03-30 22:21:34.071	2026-03-30 22:21:37.29	51d2205d-1d44-4a3f-81ce-defe85beb38b
db334714-50d1-4308-b288-997ecc119ac9	ad434e3f-b929-4ff4-a80d-11feac16b136	ada8d0ac-6b3d-46a8-ac98-8a1b1192a7ae	D	MXN	4420.85	t	\N	\N	\N	2026-03-30 22:21:34.079	2026-03-30 22:21:37.299	51d2205d-1d44-4a3f-81ce-defe85beb38b
69856377-afe5-451a-bb0a-740613c5f7fb	ad434e3f-b929-4ff4-a80d-11feac16b136	ada8d0ac-6b3d-46a8-ac98-8a1b1192a7ae	A	MXN	3823.93	t	\N	\N	\N	2026-03-30 22:21:34.1	2026-03-30 22:21:37.323	8ce1c577-6396-4dd6-a143-87727a63f172
d471c9e6-054f-4ba2-aadf-b6cba1393409	ad434e3f-b929-4ff4-a80d-11feac16b136	ada8d0ac-6b3d-46a8-ac98-8a1b1192a7ae	B	MXN	4015.10	t	\N	\N	\N	2026-03-30 22:21:34.106	2026-03-30 22:21:37.333	8ce1c577-6396-4dd6-a143-87727a63f172
82e44e4e-293b-406d-8a18-5ac13fedce67	ad434e3f-b929-4ff4-a80d-11feac16b136	ada8d0ac-6b3d-46a8-ac98-8a1b1192a7ae	C	MXN	4215.84	t	\N	\N	\N	2026-03-30 22:21:34.112	2026-03-30 22:21:37.345	8ce1c577-6396-4dd6-a143-87727a63f172
147d3a18-ff92-4a8d-8b54-fa5b52c5a717	ad434e3f-b929-4ff4-a80d-11feac16b136	ada8d0ac-6b3d-46a8-ac98-8a1b1192a7ae	D	MXN	4426.60	t	\N	\N	\N	2026-03-30 22:21:34.12	2026-03-30 22:21:37.356	8ce1c577-6396-4dd6-a143-87727a63f172
cf73f5b8-8331-4e0c-a6e6-a22d7de9d736	ad434e3f-b929-4ff4-a80d-11feac16b136	ada8d0ac-6b3d-46a8-ac98-8a1b1192a7ae	B	MXN	4151.77	t	\N	\N	\N	2026-03-30 22:21:34.148	2026-03-30 22:21:37.396	8bc594fe-1343-4eaf-97a5-7aa6801fdf31
00b236f1-d5c1-4508-b5c3-40596647c266	ad434e3f-b929-4ff4-a80d-11feac16b136	ada8d0ac-6b3d-46a8-ac98-8a1b1192a7ae	C	MXN	4359.34	t	\N	\N	\N	2026-03-30 22:21:34.159	2026-03-30 22:21:37.404	8bc594fe-1343-4eaf-97a5-7aa6801fdf31
72c5d000-4722-4118-96fd-bbba88549c9f	ad434e3f-b929-4ff4-a80d-11feac16b136	ada8d0ac-6b3d-46a8-ac98-8a1b1192a7ae	D	MXN	4577.27	t	\N	\N	\N	2026-03-30 22:21:34.169	2026-03-30 22:21:37.414	8bc594fe-1343-4eaf-97a5-7aa6801fdf31
e8f7146e-862b-441a-a446-c051c5196897	ad434e3f-b929-4ff4-a80d-11feac16b136	ada8d0ac-6b3d-46a8-ac98-8a1b1192a7ae	A	MXN	4033.57	t	\N	\N	\N	2026-03-30 22:21:34.195	2026-03-30 22:21:37.434	562018ba-2459-409e-b535-3c0d43410718
9de0b88d-bf7e-400d-b629-7f03f8ede3a6	ad434e3f-b929-4ff4-a80d-11feac16b136	ada8d0ac-6b3d-46a8-ac98-8a1b1192a7ae	B	MXN	4235.22	t	\N	\N	\N	2026-03-30 22:21:34.21	2026-03-30 22:21:37.442	562018ba-2459-409e-b535-3c0d43410718
e732395b-194f-4359-a1ca-fc84ca47e9b2	ad434e3f-b929-4ff4-a80d-11feac16b136	ada8d0ac-6b3d-46a8-ac98-8a1b1192a7ae	C	MXN	4446.96	t	\N	\N	\N	2026-03-30 22:21:34.221	2026-03-30 22:21:37.452	562018ba-2459-409e-b535-3c0d43410718
d42d04ff-da24-4a49-a381-25c1dc89efa0	ad434e3f-b929-4ff4-a80d-11feac16b136	ada8d0ac-6b3d-46a8-ac98-8a1b1192a7ae	D	MXN	4669.28	t	\N	\N	\N	2026-03-30 22:21:34.228	2026-03-30 22:21:37.463	562018ba-2459-409e-b535-3c0d43410718
d8babbf7-9941-44fd-8058-2992d614d0e1	ad434e3f-b929-4ff4-a80d-11feac16b136	e934b4ff-1597-44df-8d7f-640c6d7e8707	A	MXN	4198.20	t	\N	\N	\N	2026-03-30 22:21:34.248	2026-03-30 22:21:37.479	f4f7e489-c01f-41f2-99a4-9334c0d6fc21
774ea48a-b59d-4a80-98c1-8b272fee1618	ad434e3f-b929-4ff4-a80d-11feac16b136	e934b4ff-1597-44df-8d7f-640c6d7e8707	B	MXN	4408.08	t	\N	\N	\N	2026-03-30 22:21:34.257	2026-03-30 22:21:37.49	f4f7e489-c01f-41f2-99a4-9334c0d6fc21
787844f9-06f6-4a63-bc87-c7f291b8cc44	ad434e3f-b929-4ff4-a80d-11feac16b136	e934b4ff-1597-44df-8d7f-640c6d7e8707	C	MXN	4628.46	t	\N	\N	\N	2026-03-30 22:21:34.265	2026-03-30 22:21:37.506	f4f7e489-c01f-41f2-99a4-9334c0d6fc21
7d4c5436-a360-4967-9cc6-1989e07838ad	ad434e3f-b929-4ff4-a80d-11feac16b136	e934b4ff-1597-44df-8d7f-640c6d7e8707	D	MXN	4859.87	t	\N	\N	\N	2026-03-30 22:21:34.272	2026-03-30 22:21:37.515	f4f7e489-c01f-41f2-99a4-9334c0d6fc21
60d9e6ae-3535-49db-8529-fa4073558907	ad434e3f-b929-4ff4-a80d-11feac16b136	e934b4ff-1597-44df-8d7f-640c6d7e8707	A	MXN	4203.17	t	\N	\N	\N	2026-03-30 22:21:34.288	2026-03-30 22:21:37.548	9a78bee8-0d41-4f43-b924-eae301192c91
4c2af727-e768-41fb-bb35-e58b754f0af8	ad434e3f-b929-4ff4-a80d-11feac16b136	e934b4ff-1597-44df-8d7f-640c6d7e8707	B	MXN	4413.30	t	\N	\N	\N	2026-03-30 22:21:34.299	2026-03-30 22:21:37.59	9a78bee8-0d41-4f43-b924-eae301192c91
f9e0b665-3467-4841-8601-4658f7cc4dd9	ad434e3f-b929-4ff4-a80d-11feac16b136	e934b4ff-1597-44df-8d7f-640c6d7e8707	C	MXN	4633.94	t	\N	\N	\N	2026-03-30 22:21:34.309	2026-03-30 22:21:37.625	9a78bee8-0d41-4f43-b924-eae301192c91
9bb51229-ee45-46ee-92c4-66874ba9aed6	ad434e3f-b929-4ff4-a80d-11feac16b136	e934b4ff-1597-44df-8d7f-640c6d7e8707	D	MXN	4865.62	t	\N	\N	\N	2026-03-30 22:21:34.317	2026-03-30 22:21:37.646	9a78bee8-0d41-4f43-b924-eae301192c91
cdbf4f17-639b-4b0d-b8d2-89813f79a7b8	ad434e3f-b929-4ff4-a80d-11feac16b136	e934b4ff-1597-44df-8d7f-640c6d7e8707	A	MXN	4333.34	t	\N	\N	\N	2026-03-30 22:21:34.334	2026-03-30 22:21:37.67	08b60d49-f649-4d41-bf86-bc7bc5812d36
ee3ff7aa-7c2f-40e2-9c91-5cd214a8bafa	ad434e3f-b929-4ff4-a80d-11feac16b136	e934b4ff-1597-44df-8d7f-640c6d7e8707	B	MXN	4549.97	t	\N	\N	\N	2026-03-30 22:21:34.346	2026-03-30 22:21:37.68	08b60d49-f649-4d41-bf86-bc7bc5812d36
eb1ce5e9-6d67-4d44-8c16-2a9de7a0c2b7	ad434e3f-b929-4ff4-a80d-11feac16b136	e934b4ff-1597-44df-8d7f-640c6d7e8707	C	MXN	4777.44	t	\N	\N	\N	2026-03-30 22:21:34.358	2026-03-30 22:21:37.701	08b60d49-f649-4d41-bf86-bc7bc5812d36
f5c81e83-2bc0-4b61-91d5-5e39cc10ef7e	ad434e3f-b929-4ff4-a80d-11feac16b136	e934b4ff-1597-44df-8d7f-640c6d7e8707	D	MXN	5016.29	t	\N	\N	\N	2026-03-30 22:21:34.367	2026-03-30 22:21:37.715	08b60d49-f649-4d41-bf86-bc7bc5812d36
250bb04b-6417-411b-b9ab-980e1bbe528a	ad434e3f-b929-4ff4-a80d-11feac16b136	e934b4ff-1597-44df-8d7f-640c6d7e8707	A	MXN	4412.81	t	\N	\N	\N	2026-03-30 22:21:34.383	2026-03-30 22:21:37.738	62e7461e-b0ae-4c98-8a0c-836ad7c59a47
fc7525eb-4b20-4c7e-94a8-10987210a192	ad434e3f-b929-4ff4-a80d-11feac16b136	e934b4ff-1597-44df-8d7f-640c6d7e8707	B	MXN	4633.42	t	\N	\N	\N	2026-03-30 22:21:34.391	2026-03-30 22:21:37.748	62e7461e-b0ae-4c98-8a0c-836ad7c59a47
56e3ee4e-7a15-417d-aec1-0cc78939793f	ad434e3f-b929-4ff4-a80d-11feac16b136	e934b4ff-1597-44df-8d7f-640c6d7e8707	C	MXN	4865.06	t	\N	\N	\N	2026-03-30 22:21:34.401	2026-03-30 22:21:37.76	62e7461e-b0ae-4c98-8a0c-836ad7c59a47
4b264016-9cfa-4c6c-bc4d-7488d35d4a73	ad434e3f-b929-4ff4-a80d-11feac16b136	e934b4ff-1597-44df-8d7f-640c6d7e8707	D	MXN	5108.30	t	\N	\N	\N	2026-03-30 22:21:34.41	2026-03-30 22:21:37.768	62e7461e-b0ae-4c98-8a0c-836ad7c59a47
a7a666b1-f856-4f5e-9c6b-61d929144fe1	ad434e3f-b929-4ff4-a80d-11feac16b136	73f4aef0-f656-4768-9818-07129ee45791	A	MXN	3856.34	t	\N	\N	\N	2026-03-30 22:21:34.425	2026-03-30 22:21:37.784	9f5f9cb3-f9fe-4f16-bf52-a0114278af8a
5c0afbcd-b04c-4378-928d-eb71c1ae7573	ad434e3f-b929-4ff4-a80d-11feac16b136	73f4aef0-f656-4768-9818-07129ee45791	B	MXN	4049.14	t	\N	\N	\N	2026-03-30 22:21:34.433	2026-03-30 22:21:37.791	9f5f9cb3-f9fe-4f16-bf52-a0114278af8a
84c9488f-ea37-4f1f-ba5d-3441a7a34888	ad434e3f-b929-4ff4-a80d-11feac16b136	73f4aef0-f656-4768-9818-07129ee45791	C	MXN	4251.58	t	\N	\N	\N	2026-03-30 22:21:34.441	2026-03-30 22:21:37.801	9f5f9cb3-f9fe-4f16-bf52-a0114278af8a
8d12e39b-368c-408e-84f5-84bcb8a52805	ad434e3f-b929-4ff4-a80d-11feac16b136	73f4aef0-f656-4768-9818-07129ee45791	D	MXN	4464.15	t	\N	\N	\N	2026-03-30 22:21:34.449	2026-03-30 22:21:37.808	9f5f9cb3-f9fe-4f16-bf52-a0114278af8a
4351094b-1af8-4824-a80d-eaabbc04eef2	ad434e3f-b929-4ff4-a80d-11feac16b136	73f4aef0-f656-4768-9818-07129ee45791	A	MXN	3861.31	t	\N	\N	\N	2026-03-30 22:21:34.464	2026-03-30 22:21:37.824	d2b40e91-b109-4082-ac23-072fb43cd14d
597db7a1-172e-4712-a539-84c03cfe94a4	ad434e3f-b929-4ff4-a80d-11feac16b136	73f4aef0-f656-4768-9818-07129ee45791	C	MXN	4257.06	t	\N	\N	\N	2026-03-30 22:21:34.478	2026-03-30 22:21:37.843	d2b40e91-b109-4082-ac23-072fb43cd14d
67fa76f7-6417-4ac1-b9df-3fbb52721722	ad434e3f-b929-4ff4-a80d-11feac16b136	73f4aef0-f656-4768-9818-07129ee45791	D	MXN	4469.90	t	\N	\N	\N	2026-03-30 22:21:34.485	2026-03-30 22:21:37.852	d2b40e91-b109-4082-ac23-072fb43cd14d
c44dcdb9-8198-4f4c-a307-d31e1c385531	ad434e3f-b929-4ff4-a80d-11feac16b136	73f4aef0-f656-4768-9818-07129ee45791	A	MXN	3991.48	t	\N	\N	\N	2026-03-30 22:21:34.499	2026-03-30 22:21:37.87	3ea51136-a661-44e3-9a75-acfe6ce6d4ca
2ed6b58e-6921-4d09-b169-e830c2337199	ad434e3f-b929-4ff4-a80d-11feac16b136	73f4aef0-f656-4768-9818-07129ee45791	B	MXN	4191.03	t	\N	\N	\N	2026-03-30 22:21:34.506	2026-03-30 22:21:37.879	3ea51136-a661-44e3-9a75-acfe6ce6d4ca
39453af8-97b5-4f28-a91b-a37d2ed7a12c	ad434e3f-b929-4ff4-a80d-11feac16b136	73f4aef0-f656-4768-9818-07129ee45791	C	MXN	4400.56	t	\N	\N	\N	2026-03-30 22:21:34.514	2026-03-30 22:21:37.889	3ea51136-a661-44e3-9a75-acfe6ce6d4ca
26dec7b5-71eb-4ed3-9b44-a1adb31c57c8	ad434e3f-b929-4ff4-a80d-11feac16b136	73f4aef0-f656-4768-9818-07129ee45791	D	MXN	4620.57	t	\N	\N	\N	2026-03-30 22:21:34.522	2026-03-30 22:21:37.899	3ea51136-a661-44e3-9a75-acfe6ce6d4ca
745e4aee-f12f-41c4-b2b9-358cbad8e7bd	ad434e3f-b929-4ff4-a80d-11feac16b136	73f4aef0-f656-4768-9818-07129ee45791	A	MXN	4070.95	t	\N	\N	\N	2026-03-30 22:21:34.538	2026-03-30 22:21:37.926	f0c01c30-d31d-420f-a434-a1354beb7d90
a86d087b-0413-4edf-a31e-169e39f61962	ad434e3f-b929-4ff4-a80d-11feac16b136	73f4aef0-f656-4768-9818-07129ee45791	C	MXN	4488.18	t	\N	\N	\N	2026-03-30 22:21:34.559	2026-03-30 22:21:37.953	f0c01c30-d31d-420f-a434-a1354beb7d90
132e6d38-84ae-47d1-8783-e05c9c96073e	ad434e3f-b929-4ff4-a80d-11feac16b136	73f4aef0-f656-4768-9818-07129ee45791	D	MXN	4712.58	t	\N	\N	\N	2026-03-30 22:21:34.566	2026-03-30 22:21:37.963	f0c01c30-d31d-420f-a434-a1354beb7d90
e73c8b13-a91a-4033-bd1f-95cd239cdfdf	ad434e3f-b929-4ff4-a80d-11feac16b136	8f63d311-722f-4b90-b890-fe271b51a9b4	A	MXN	3812.36	t	\N	\N	\N	2026-03-30 22:21:34.581	2026-03-30 22:21:37.982	56b96533-0368-4378-aa13-5fc86a70b6d1
13c68aab-2c01-4f97-b093-e92620e4188b	ad434e3f-b929-4ff4-a80d-11feac16b136	8f63d311-722f-4b90-b890-fe271b51a9b4	B	MXN	4002.96	t	\N	\N	\N	2026-03-30 22:21:34.588	2026-03-30 22:21:37.99	56b96533-0368-4378-aa13-5fc86a70b6d1
8d102465-0837-420c-8e2a-a399a25a38d9	ad434e3f-b929-4ff4-a80d-11feac16b136	8f63d311-722f-4b90-b890-fe271b51a9b4	C	MXN	4203.08	t	\N	\N	\N	2026-03-30 22:21:34.595	2026-03-30 22:21:37.999	56b96533-0368-4378-aa13-5fc86a70b6d1
dd3a28cd-5d4a-4c05-85c3-834223291c5a	ad434e3f-b929-4ff4-a80d-11feac16b136	8f63d311-722f-4b90-b890-fe271b51a9b4	D	MXN	4413.21	t	\N	\N	\N	2026-03-30 22:21:34.604	2026-03-30 22:21:38.011	56b96533-0368-4378-aa13-5fc86a70b6d1
bba02220-c465-4cfd-b39a-d9b86b3f1614	ad434e3f-b929-4ff4-a80d-11feac16b136	8f63d311-722f-4b90-b890-fe271b51a9b4	A	MXN	3947.50	t	\N	\N	\N	2026-03-30 22:21:34.62	2026-03-30 22:21:38.033	bee0e330-6637-4839-82fc-cbac1f24ddb4
942504fb-ae65-4113-8e9e-dbf97e7adf0f	ad434e3f-b929-4ff4-a80d-11feac16b136	8f63d311-722f-4b90-b890-fe271b51a9b4	B	MXN	4144.85	t	\N	\N	\N	2026-03-30 22:21:34.627	2026-03-30 22:21:38.041	bee0e330-6637-4839-82fc-cbac1f24ddb4
e1c052b0-1762-4823-919f-7c7f0fb6040b	ad434e3f-b929-4ff4-a80d-11feac16b136	8f63d311-722f-4b90-b890-fe271b51a9b4	C	MXN	4352.06	t	\N	\N	\N	2026-03-30 22:21:34.634	2026-03-30 22:21:38.051	bee0e330-6637-4839-82fc-cbac1f24ddb4
437f985f-d38c-48ed-a9c6-e890ebe4873c	ad434e3f-b929-4ff4-a80d-11feac16b136	8f63d311-722f-4b90-b890-fe271b51a9b4	D	MXN	4569.63	t	\N	\N	\N	2026-03-30 22:21:34.642	2026-03-30 22:21:38.065	bee0e330-6637-4839-82fc-cbac1f24ddb4
e2b83066-7e0a-43c7-a1d1-6142d20e2049	ad434e3f-b929-4ff4-a80d-11feac16b136	8f63d311-722f-4b90-b890-fe271b51a9b4	A	MXN	3817.33	t	\N	\N	\N	2026-03-30 22:21:34.657	2026-03-30 22:21:38.082	307b4617-c66e-4d65-b2a3-46fdd974d9d8
2df7d419-d84a-4cd2-acac-b9029765e3bc	ad434e3f-b929-4ff4-a80d-11feac16b136	8f63d311-722f-4b90-b890-fe271b51a9b4	B	MXN	4008.18	t	\N	\N	\N	2026-03-30 22:21:34.664	2026-03-30 22:21:38.09	307b4617-c66e-4d65-b2a3-46fdd974d9d8
667e2795-6af4-4539-9a1e-037e4f2818d4	ad434e3f-b929-4ff4-a80d-11feac16b136	8f63d311-722f-4b90-b890-fe271b51a9b4	C	MXN	4208.56	t	\N	\N	\N	2026-03-30 22:21:34.67	2026-03-30 22:21:38.098	307b4617-c66e-4d65-b2a3-46fdd974d9d8
3a89e254-1b4f-48f6-906e-4fddef1b5662	ad434e3f-b929-4ff4-a80d-11feac16b136	8f63d311-722f-4b90-b890-fe271b51a9b4	D	MXN	4418.96	t	\N	\N	\N	2026-03-30 22:21:34.678	2026-03-30 22:21:38.108	307b4617-c66e-4d65-b2a3-46fdd974d9d8
85c7cc02-f30a-4b6b-9772-0001af1b5a66	ad434e3f-b929-4ff4-a80d-11feac16b136	8f63d311-722f-4b90-b890-fe271b51a9b4	A	MXN	4026.97	t	\N	\N	\N	2026-03-30 22:21:34.692	2026-03-30 22:21:38.133	ee631f5b-c4b0-4c11-93b5-db9b593d8698
da13d352-4e8d-4818-b406-a767716af8a8	ad434e3f-b929-4ff4-a80d-11feac16b136	8f63d311-722f-4b90-b890-fe271b51a9b4	B	MXN	4228.30	t	\N	\N	\N	2026-03-30 22:21:34.698	2026-03-30 22:21:38.147	ee631f5b-c4b0-4c11-93b5-db9b593d8698
b4f164d7-5451-4989-9c10-799f556a7593	ad434e3f-b929-4ff4-a80d-11feac16b136	8f63d311-722f-4b90-b890-fe271b51a9b4	C	MXN	4439.68	t	\N	\N	\N	2026-03-30 22:21:34.705	2026-03-30 22:21:38.157	ee631f5b-c4b0-4c11-93b5-db9b593d8698
1b4a1d8d-fd19-4115-9fae-be72f0e0ace9	ad434e3f-b929-4ff4-a80d-11feac16b136	8f63d311-722f-4b90-b890-fe271b51a9b4	D	MXN	4661.64	t	\N	\N	\N	2026-03-30 22:21:34.711	2026-03-30 22:21:38.167	ee631f5b-c4b0-4c11-93b5-db9b593d8698
f5b0ea01-0eee-4180-b46e-1c52eb41e11f	ad434e3f-b929-4ff4-a80d-11feac16b136	1b778817-d9ab-428b-bdf1-9ebe3ed039ae	A	MXN	3171.25	t	\N	\N	\N	2026-03-30 22:21:34.726	2026-03-30 22:21:38.184	6f69186b-d301-48ee-b45a-f9ea4bcc6e49
163ed823-8afb-4f0d-92b1-cf971832f732	ad434e3f-b929-4ff4-a80d-11feac16b136	1b778817-d9ab-428b-bdf1-9ebe3ed039ae	B	MXN	3329.79	t	\N	\N	\N	2026-03-30 22:21:34.735	2026-03-30 22:21:38.195	6f69186b-d301-48ee-b45a-f9ea4bcc6e49
87d3de46-ee3c-4087-bd03-9ae21dc7eead	ad434e3f-b929-4ff4-a80d-11feac16b136	1b778817-d9ab-428b-bdf1-9ebe3ed039ae	C	MXN	3496.26	t	\N	\N	\N	2026-03-30 22:21:34.744	2026-03-30 22:21:38.209	6f69186b-d301-48ee-b45a-f9ea4bcc6e49
8da62934-caa7-43a5-92b4-b0ad4dc144c2	ad434e3f-b929-4ff4-a80d-11feac16b136	1b778817-d9ab-428b-bdf1-9ebe3ed039ae	D	MXN	3671.06	t	\N	\N	\N	2026-03-30 22:21:34.75	2026-03-30 22:21:38.217	6f69186b-d301-48ee-b45a-f9ea4bcc6e49
a230399a-27c1-4e9c-92a6-22fa4cef8205	ad434e3f-b929-4ff4-a80d-11feac16b136	1b778817-d9ab-428b-bdf1-9ebe3ed039ae	A	MXN	3176.22	t	\N	\N	\N	2026-03-30 22:21:34.765	2026-03-30 22:21:38.253	cbb89089-b313-46d9-80d1-db836d510c7c
f774ddee-8f65-4e45-a2e7-ed03761bdf68	ad434e3f-b929-4ff4-a80d-11feac16b136	1b778817-d9ab-428b-bdf1-9ebe3ed039ae	B	MXN	3335.01	t	\N	\N	\N	2026-03-30 22:21:34.772	2026-03-30 22:21:38.263	cbb89089-b313-46d9-80d1-db836d510c7c
7a26844d-6e53-4e1d-a3af-816fdceeab23	ad434e3f-b929-4ff4-a80d-11feac16b136	1b778817-d9ab-428b-bdf1-9ebe3ed039ae	C	MXN	3501.74	t	\N	\N	\N	2026-03-30 22:21:34.779	2026-03-30 22:21:38.271	cbb89089-b313-46d9-80d1-db836d510c7c
509e4259-ae49-4f4f-8383-cd48b0464021	ad434e3f-b929-4ff4-a80d-11feac16b136	1b778817-d9ab-428b-bdf1-9ebe3ed039ae	D	MXN	3676.81	t	\N	\N	\N	2026-03-30 22:21:34.786	2026-03-30 22:21:38.279	cbb89089-b313-46d9-80d1-db836d510c7c
4741f3a4-e5fb-4701-82ba-fbd3b56486b5	ad434e3f-b929-4ff4-a80d-11feac16b136	1b778817-d9ab-428b-bdf1-9ebe3ed039ae	A	MXN	3306.39	t	\N	\N	\N	2026-03-30 22:21:34.802	2026-03-30 22:21:38.296	006f2288-6372-4c73-8186-879d6b4de577
e85514ed-9289-4b73-a85b-25858f84995e	ad434e3f-b929-4ff4-a80d-11feac16b136	1b778817-d9ab-428b-bdf1-9ebe3ed039ae	B	MXN	3471.68	t	\N	\N	\N	2026-03-30 22:21:34.808	2026-03-30 22:21:38.309	006f2288-6372-4c73-8186-879d6b4de577
3283d0a3-d5d4-41c8-aa70-2bfb975c3a34	ad434e3f-b929-4ff4-a80d-11feac16b136	1b778817-d9ab-428b-bdf1-9ebe3ed039ae	D	MXN	3827.48	t	\N	\N	\N	2026-03-30 22:21:34.824	2026-03-30 22:21:38.327	006f2288-6372-4c73-8186-879d6b4de577
b4ae3b18-2fa8-4d68-a6ec-6c94b3c903f6	ad434e3f-b929-4ff4-a80d-11feac16b136	1b778817-d9ab-428b-bdf1-9ebe3ed039ae	A	MXN	3385.86	t	\N	\N	\N	2026-03-30 22:21:34.839	2026-03-30 22:21:38.343	6b60fe9b-b002-4591-bcb4-d1696cc55b10
5666738d-0307-4240-8c3c-b90939defcbc	ad434e3f-b929-4ff4-a80d-11feac16b136	1b778817-d9ab-428b-bdf1-9ebe3ed039ae	B	MXN	3555.13	t	\N	\N	\N	2026-03-30 22:21:34.846	2026-03-30 22:21:38.351	6b60fe9b-b002-4591-bcb4-d1696cc55b10
276ffb4f-62f4-4018-bfd8-9cc6e9ad69e0	ad434e3f-b929-4ff4-a80d-11feac16b136	1b778817-d9ab-428b-bdf1-9ebe3ed039ae	C	MXN	3732.86	t	\N	\N	\N	2026-03-30 22:21:34.853	2026-03-30 22:21:38.36	6b60fe9b-b002-4591-bcb4-d1696cc55b10
cf14629d-6c2c-4339-9437-255fb41c72bd	ad434e3f-b929-4ff4-a80d-11feac16b136	1b778817-d9ab-428b-bdf1-9ebe3ed039ae	D	MXN	3919.49	t	\N	\N	\N	2026-03-30 22:21:34.861	2026-03-30 22:21:38.368	6b60fe9b-b002-4591-bcb4-d1696cc55b10
caea462e-769f-4cb3-915d-1fbe66d42703	ad434e3f-b929-4ff4-a80d-11feac16b136	e6e416d8-32ee-409e-9816-17c5e6f8b420	A	MXN	3327.77	t	\N	\N	\N	2026-03-30 22:21:34.876	2026-03-30 22:21:38.388	04e79f99-bdf3-46f5-aed9-6e4d79cfbc98
82b547b2-7d53-49d5-918b-14b8a4d5c296	ad434e3f-b929-4ff4-a80d-11feac16b136	e6e416d8-32ee-409e-9816-17c5e6f8b420	B	MXN	3494.14	t	\N	\N	\N	2026-03-30 22:21:34.884	2026-03-30 22:21:38.398	04e79f99-bdf3-46f5-aed9-6e4d79cfbc98
05c5a55e-f195-4c69-892f-98abfc6cae9b	ad434e3f-b929-4ff4-a80d-11feac16b136	e6e416d8-32ee-409e-9816-17c5e6f8b420	D	MXN	3852.26	t	\N	\N	\N	2026-03-30 22:21:34.899	2026-03-30 22:21:38.414	04e79f99-bdf3-46f5-aed9-6e4d79cfbc98
69d07add-43f7-4e89-bb3e-d3e358ef4618	ad434e3f-b929-4ff4-a80d-11feac16b136	e6e416d8-32ee-409e-9816-17c5e6f8b420	A	MXN	3332.74	t	\N	\N	\N	2026-03-30 22:21:34.916	2026-03-30 22:21:38.445	cf29c524-b552-4f10-86b6-ee64bdc29346
789530cb-a89c-497a-ad6b-54ff96bb4bb0	ad434e3f-b929-4ff4-a80d-11feac16b136	e6e416d8-32ee-409e-9816-17c5e6f8b420	B	MXN	3499.36	t	\N	\N	\N	2026-03-30 22:21:34.923	2026-03-30 22:21:38.455	cf29c524-b552-4f10-86b6-ee64bdc29346
905e5bcc-2a3d-44de-9777-1e7ea3560be4	ad434e3f-b929-4ff4-a80d-11feac16b136	e6e416d8-32ee-409e-9816-17c5e6f8b420	C	MXN	3674.31	t	\N	\N	\N	2026-03-30 22:21:34.931	2026-03-30 22:21:38.464	cf29c524-b552-4f10-86b6-ee64bdc29346
391e4ff1-1117-4d67-a12d-470ebb7308fb	ad434e3f-b929-4ff4-a80d-11feac16b136	e6e416d8-32ee-409e-9816-17c5e6f8b420	D	MXN	3858.01	t	\N	\N	\N	2026-03-30 22:21:34.938	2026-03-30 22:21:38.472	cf29c524-b552-4f10-86b6-ee64bdc29346
cf8d5ba0-ab28-4d0f-b864-d96c0a1467d4	ad434e3f-b929-4ff4-a80d-11feac16b136	e6e416d8-32ee-409e-9816-17c5e6f8b420	A	MXN	3462.91	t	\N	\N	\N	2026-03-30 22:21:34.952	2026-03-30 22:21:38.49	cf00674c-6ea7-4487-9985-229866e05d2f
44b92008-b0c6-454d-865f-35afcddb0890	ad434e3f-b929-4ff4-a80d-11feac16b136	e6e416d8-32ee-409e-9816-17c5e6f8b420	B	MXN	3636.03	t	\N	\N	\N	2026-03-30 22:21:34.959	2026-03-30 22:21:38.499	cf00674c-6ea7-4487-9985-229866e05d2f
06cd8e9d-0424-4f98-b30a-12f9a418c391	ad434e3f-b929-4ff4-a80d-11feac16b136	e6e416d8-32ee-409e-9816-17c5e6f8b420	C	MXN	3817.81	t	\N	\N	\N	2026-03-30 22:21:34.972	2026-03-30 22:21:38.509	cf00674c-6ea7-4487-9985-229866e05d2f
344a777d-869d-40a6-ac89-531d29a345cb	ad434e3f-b929-4ff4-a80d-11feac16b136	e6e416d8-32ee-409e-9816-17c5e6f8b420	D	MXN	4008.68	t	\N	\N	\N	2026-03-30 22:21:34.997	2026-03-30 22:21:38.52	cf00674c-6ea7-4487-9985-229866e05d2f
e6508760-b2c1-4fb6-a18a-8630e419fdb1	ad434e3f-b929-4ff4-a80d-11feac16b136	e6e416d8-32ee-409e-9816-17c5e6f8b420	A	MXN	3542.38	t	\N	\N	\N	2026-03-30 22:21:35.022	2026-03-30 22:21:38.54	6d1f5331-abfc-4524-a4a9-c90d389cc232
c1f9461c-89bb-4cde-ace9-fd8fbafcce27	ad434e3f-b929-4ff4-a80d-11feac16b136	e6e416d8-32ee-409e-9816-17c5e6f8b420	B	MXN	3719.48	t	\N	\N	\N	2026-03-30 22:21:35.035	2026-03-30 22:21:38.547	6d1f5331-abfc-4524-a4a9-c90d389cc232
0eb5219b-a08f-464c-9859-43fff1c873a1	ad434e3f-b929-4ff4-a80d-11feac16b136	e6e416d8-32ee-409e-9816-17c5e6f8b420	C	MXN	3905.43	t	\N	\N	\N	2026-03-30 22:21:35.044	2026-03-30 22:21:38.554	6d1f5331-abfc-4524-a4a9-c90d389cc232
bae969c2-1d9f-4c2b-9ca8-d94e9212aa38	ad434e3f-b929-4ff4-a80d-11feac16b136	e6e416d8-32ee-409e-9816-17c5e6f8b420	D	MXN	4100.69	t	\N	\N	\N	2026-03-30 22:21:35.05	2026-03-30 22:21:38.565	6d1f5331-abfc-4524-a4a9-c90d389cc232
21bc3b75-3542-4a96-b9d4-033834c5f882	ad434e3f-b929-4ff4-a80d-11feac16b136	fc47eeb3-86e6-4a97-8964-821b5861a39d	A	MXN	3189.93	t	\N	\N	\N	2026-03-30 22:21:35.065	2026-03-30 22:21:38.585	7d04757d-dd79-4815-be30-938e034b618c
16dd82f7-c03a-4819-8780-d4f2bed0e687	ad434e3f-b929-4ff4-a80d-11feac16b136	fc47eeb3-86e6-4a97-8964-821b5861a39d	B	MXN	3349.41	t	\N	\N	\N	2026-03-30 22:21:35.074	2026-03-30 22:21:38.593	7d04757d-dd79-4815-be30-938e034b618c
46835543-987c-4b67-ade0-c0739a88e035	ad434e3f-b929-4ff4-a80d-11feac16b136	fc47eeb3-86e6-4a97-8964-821b5861a39d	C	MXN	3516.86	t	\N	\N	\N	2026-03-30 22:21:35.084	2026-03-30 22:21:38.601	7d04757d-dd79-4815-be30-938e034b618c
ea5e2cd5-71d9-47a7-bc4d-98c74d0b780c	ad434e3f-b929-4ff4-a80d-11feac16b136	fc47eeb3-86e6-4a97-8964-821b5861a39d	D	MXN	3692.69	t	\N	\N	\N	2026-03-30 22:21:35.102	2026-03-30 22:21:38.609	7d04757d-dd79-4815-be30-938e034b618c
88f66d26-e8cb-4869-bba8-d297f6864393	ad434e3f-b929-4ff4-a80d-11feac16b136	fc47eeb3-86e6-4a97-8964-821b5861a39d	A	MXN	3194.90	t	\N	\N	\N	2026-03-30 22:21:35.127	2026-03-30 22:21:38.627	82f6062e-6f86-4c55-b1ba-f9b87fbfc14c
309134ef-915f-4b1d-92dc-6b07bda5830e	ad434e3f-b929-4ff4-a80d-11feac16b136	fc47eeb3-86e6-4a97-8964-821b5861a39d	B	MXN	3354.63	t	\N	\N	\N	2026-03-30 22:21:35.137	2026-03-30 22:21:38.635	82f6062e-6f86-4c55-b1ba-f9b87fbfc14c
fcc041b3-d190-4710-9e39-b321dca4f797	ad434e3f-b929-4ff4-a80d-11feac16b136	fc47eeb3-86e6-4a97-8964-821b5861a39d	C	MXN	3522.34	t	\N	\N	\N	2026-03-30 22:21:35.145	2026-03-30 22:21:38.646	82f6062e-6f86-4c55-b1ba-f9b87fbfc14c
92141e8f-342d-4396-80c8-62d9076540cd	ad434e3f-b929-4ff4-a80d-11feac16b136	fc47eeb3-86e6-4a97-8964-821b5861a39d	D	MXN	3698.44	t	\N	\N	\N	2026-03-30 22:21:35.153	2026-03-30 22:21:38.655	82f6062e-6f86-4c55-b1ba-f9b87fbfc14c
34f805ae-0eee-4817-825b-361749829cc7	ad434e3f-b929-4ff4-a80d-11feac16b136	fc47eeb3-86e6-4a97-8964-821b5861a39d	A	MXN	3325.07	t	\N	\N	\N	2026-03-30 22:21:35.168	2026-03-30 22:21:38.674	6b269ae3-e3af-44ce-ad9e-63a8ea979d56
dbd5d5d1-e5e6-468d-acf7-943c76107f08	ad434e3f-b929-4ff4-a80d-11feac16b136	fc47eeb3-86e6-4a97-8964-821b5861a39d	B	MXN	3491.30	t	\N	\N	\N	2026-03-30 22:21:35.175	2026-03-30 22:21:38.682	6b269ae3-e3af-44ce-ad9e-63a8ea979d56
6b57f61d-e7f7-468c-93cb-633d64e82b13	ad434e3f-b929-4ff4-a80d-11feac16b136	fc47eeb3-86e6-4a97-8964-821b5861a39d	C	MXN	3665.84	t	\N	\N	\N	2026-03-30 22:21:35.183	2026-03-30 22:21:38.69	6b269ae3-e3af-44ce-ad9e-63a8ea979d56
cebdfecc-09b9-4cd8-96a8-9d22ef82c10b	ad434e3f-b929-4ff4-a80d-11feac16b136	fc47eeb3-86e6-4a97-8964-821b5861a39d	D	MXN	3849.11	t	\N	\N	\N	2026-03-30 22:21:35.191	2026-03-30 22:21:38.701	6b269ae3-e3af-44ce-ad9e-63a8ea979d56
2aaf2ceb-9564-49a3-838a-2930a426ade2	ad434e3f-b929-4ff4-a80d-11feac16b136	fc47eeb3-86e6-4a97-8964-821b5861a39d	A	MXN	3404.54	t	\N	\N	\N	2026-03-30 22:21:35.223	2026-03-30 22:21:38.72	2b5fcf25-3601-479a-b829-c76e07c88da5
6d188bfa-8d98-44b1-9af4-cb2bbf90999c	ad434e3f-b929-4ff4-a80d-11feac16b136	fc47eeb3-86e6-4a97-8964-821b5861a39d	B	MXN	3574.75	t	\N	\N	\N	2026-03-30 22:21:35.231	2026-03-30 22:21:38.738	2b5fcf25-3601-479a-b829-c76e07c88da5
f8d01a4f-00d7-4036-8444-08929a73ceec	ad434e3f-b929-4ff4-a80d-11feac16b136	fc47eeb3-86e6-4a97-8964-821b5861a39d	C	MXN	3753.46	t	\N	\N	\N	2026-03-30 22:21:35.241	2026-03-30 22:21:38.748	2b5fcf25-3601-479a-b829-c76e07c88da5
c4e6e905-04b7-4e8b-a518-2d6ce2d82587	ad434e3f-b929-4ff4-a80d-11feac16b136	4cb2e968-181c-4d39-be42-ef153c26cc63	A	MXN	3162.58	t	\N	\N	\N	2026-03-30 22:21:35.263	2026-03-30 22:21:38.786	dae7c93b-f6ec-459d-9792-bc22e2bf38e1
0036b247-8707-4767-8c41-b984684f5743	ad434e3f-b929-4ff4-a80d-11feac16b136	4cb2e968-181c-4d39-be42-ef153c26cc63	B	MXN	3320.69	t	\N	\N	\N	2026-03-30 22:21:35.272	2026-03-30 22:21:38.794	dae7c93b-f6ec-459d-9792-bc22e2bf38e1
df81f4ab-7f34-45ad-b8a4-9fdddc043275	ad434e3f-b929-4ff4-a80d-11feac16b136	4cb2e968-181c-4d39-be42-ef153c26cc63	C	MXN	3486.71	t	\N	\N	\N	2026-03-30 22:21:35.279	2026-03-30 22:21:38.807	dae7c93b-f6ec-459d-9792-bc22e2bf38e1
42e3a2a8-fdbb-4cfc-8bd4-c3b44528da82	ad434e3f-b929-4ff4-a80d-11feac16b136	4cb2e968-181c-4d39-be42-ef153c26cc63	D	MXN	3661.03	t	\N	\N	\N	2026-03-30 22:21:35.287	2026-03-30 22:21:38.818	dae7c93b-f6ec-459d-9792-bc22e2bf38e1
cd6c273e-0648-4619-9d20-3b2198abe0f7	ad434e3f-b929-4ff4-a80d-11feac16b136	4cb2e968-181c-4d39-be42-ef153c26cc63	A	MXN	3167.55	t	\N	\N	\N	2026-03-30 22:21:35.302	2026-03-30 22:21:38.873	c74ba569-cd40-4ea7-ab94-dda33e35a403
6b846e61-7303-4871-8cb8-57bc6091a8ad	ad434e3f-b929-4ff4-a80d-11feac16b136	4cb2e968-181c-4d39-be42-ef153c26cc63	B	MXN	3325.91	t	\N	\N	\N	2026-03-30 22:21:35.309	2026-03-30 22:21:38.883	c74ba569-cd40-4ea7-ab94-dda33e35a403
ca6af7b8-7605-48de-81ea-2c0e7af08d33	ad434e3f-b929-4ff4-a80d-11feac16b136	4cb2e968-181c-4d39-be42-ef153c26cc63	C	MXN	3492.19	t	\N	\N	\N	2026-03-30 22:21:35.316	2026-03-30 22:21:38.894	c74ba569-cd40-4ea7-ab94-dda33e35a403
77d3ac60-2596-4514-bd37-ee0adb363f98	ad434e3f-b929-4ff4-a80d-11feac16b136	4cb2e968-181c-4d39-be42-ef153c26cc63	A	MXN	3297.72	t	\N	\N	\N	2026-03-30 22:21:35.345	2026-03-30 22:21:38.927	99313dc2-8241-4f36-9b4b-e2eaddb1fad3
b864c4b1-aa77-48b6-9f2b-71be3067bd6f	ad434e3f-b929-4ff4-a80d-11feac16b136	4cb2e968-181c-4d39-be42-ef153c26cc63	B	MXN	3462.58	t	\N	\N	\N	2026-03-30 22:21:35.353	2026-03-30 22:21:38.936	99313dc2-8241-4f36-9b4b-e2eaddb1fad3
38115381-7a99-451b-9a19-bc31b76ff2dd	ad434e3f-b929-4ff4-a80d-11feac16b136	4cb2e968-181c-4d39-be42-ef153c26cc63	C	MXN	3635.69	t	\N	\N	\N	2026-03-30 22:21:35.359	2026-03-30 22:21:38.949	99313dc2-8241-4f36-9b4b-e2eaddb1fad3
3b7f0693-0940-456b-afbe-0ffc28e8858d	ad434e3f-b929-4ff4-a80d-11feac16b136	4cb2e968-181c-4d39-be42-ef153c26cc63	D	MXN	3817.45	t	\N	\N	\N	2026-03-30 22:21:35.366	2026-03-30 22:21:38.961	99313dc2-8241-4f36-9b4b-e2eaddb1fad3
a9437096-80cb-44c0-93d0-c902c0c91e43	ad434e3f-b929-4ff4-a80d-11feac16b136	4cb2e968-181c-4d39-be42-ef153c26cc63	A	MXN	3377.19	t	\N	\N	\N	2026-03-30 22:21:35.38	2026-03-30 22:21:38.981	1a2f628a-4a98-4052-a31a-9bb32c52b36b
c459b0f2-0884-489b-ba1e-2492bc5b895d	ad434e3f-b929-4ff4-a80d-11feac16b136	4cb2e968-181c-4d39-be42-ef153c26cc63	B	MXN	3546.03	t	\N	\N	\N	2026-03-30 22:21:35.389	2026-03-30 22:21:38.99	1a2f628a-4a98-4052-a31a-9bb32c52b36b
a2ceeb80-0f99-4325-a45a-c027db0bc743	ad434e3f-b929-4ff4-a80d-11feac16b136	4cb2e968-181c-4d39-be42-ef153c26cc63	C	MXN	3723.31	t	\N	\N	\N	2026-03-30 22:21:35.398	2026-03-30 22:21:39	1a2f628a-4a98-4052-a31a-9bb32c52b36b
3bcbcf69-4697-4411-a13b-d66082df3f08	ad434e3f-b929-4ff4-a80d-11feac16b136	4cb2e968-181c-4d39-be42-ef153c26cc63	D	MXN	3909.46	t	\N	\N	\N	2026-03-30 22:21:35.406	2026-03-30 22:21:39.023	1a2f628a-4a98-4052-a31a-9bb32c52b36b
bbd5ce61-1765-4476-abc7-f3d2ade05e59	ad434e3f-b929-4ff4-a80d-11feac16b136	d9bc9698-afef-47a5-b7a9-226ed87f142a	A	MXN	2665.79	t	\N	\N	\N	2026-03-30 22:21:35.43	2026-03-30 22:21:39.052	31d43601-712a-483a-8126-0cfb00c30c4d
15d5c8af-83d2-4010-a8b7-d9ed1ada278c	ad434e3f-b929-4ff4-a80d-11feac16b136	d9bc9698-afef-47a5-b7a9-226ed87f142a	B	MXN	2799.05	t	\N	\N	\N	2026-03-30 22:21:35.438	2026-03-30 22:21:39.06	31d43601-712a-483a-8126-0cfb00c30c4d
af5e7bf9-26e3-40fa-8128-d551659d58d8	ad434e3f-b929-4ff4-a80d-11feac16b136	d9bc9698-afef-47a5-b7a9-226ed87f142a	C	MXN	2938.99	t	\N	\N	\N	2026-03-30 22:21:35.447	2026-03-30 22:21:39.071	31d43601-712a-483a-8126-0cfb00c30c4d
ca5a9165-2493-4547-ae71-841468a91598	ad434e3f-b929-4ff4-a80d-11feac16b136	d9bc9698-afef-47a5-b7a9-226ed87f142a	D	MXN	3085.91	t	\N	\N	\N	2026-03-30 22:21:35.458	2026-03-30 22:21:39.081	31d43601-712a-483a-8126-0cfb00c30c4d
cecebc1e-50d3-4664-9194-c0756642f6d2	ad434e3f-b929-4ff4-a80d-11feac16b136	61ccce64-d1d1-4e44-b290-287fcddf40cc	A	MXN	2831.39	t	\N	\N	\N	2026-03-30 22:21:35.473	2026-03-30 22:21:39.099	0bcb406a-760f-4cdd-9bef-22515b5627e0
2c218111-6401-44f4-b91d-60132b9de9cd	ad434e3f-b929-4ff4-a80d-11feac16b136	61ccce64-d1d1-4e44-b290-287fcddf40cc	B	MXN	2972.93	t	\N	\N	\N	2026-03-30 22:21:35.484	2026-03-30 22:21:39.106	0bcb406a-760f-4cdd-9bef-22515b5627e0
6895548a-96ba-44e6-ad51-7d569d5e2786	ad434e3f-b929-4ff4-a80d-11feac16b136	61ccce64-d1d1-4e44-b290-287fcddf40cc	C	MXN	3121.56	t	\N	\N	\N	2026-03-30 22:21:35.491	2026-03-30 22:21:39.117	0bcb406a-760f-4cdd-9bef-22515b5627e0
93b599e0-890f-487f-88a9-0f45485546ea	ad434e3f-b929-4ff4-a80d-11feac16b136	61ccce64-d1d1-4e44-b290-287fcddf40cc	D	MXN	3277.61	t	\N	\N	\N	2026-03-30 22:21:35.499	2026-03-30 22:21:39.129	0bcb406a-760f-4cdd-9bef-22515b5627e0
1589cf57-3313-48a2-9b21-ebdeaa0ca0be	ad434e3f-b929-4ff4-a80d-11feac16b136	5d3decde-b899-4682-9dc6-d4cb91338e7a	A	MXN	2674.06	t	\N	\N	\N	2026-03-30 22:21:35.513	2026-03-30 22:21:39.145	c5582213-a38f-4d45-b15c-8f6d310b2944
6f7a5349-a0fa-4b47-b0da-95c05bb9ab7e	ad434e3f-b929-4ff4-a80d-11feac16b136	5d3decde-b899-4682-9dc6-d4cb91338e7a	B	MXN	2807.74	t	\N	\N	\N	2026-03-30 22:21:35.52	2026-03-30 22:21:39.152	c5582213-a38f-4d45-b15c-8f6d310b2944
f4238395-8f8c-484d-885f-3c7fbcb22711	ad434e3f-b929-4ff4-a80d-11feac16b136	5d3decde-b899-4682-9dc6-d4cb91338e7a	C	MXN	2948.11	t	\N	\N	\N	2026-03-30 22:21:35.528	2026-03-30 22:21:39.16	c5582213-a38f-4d45-b15c-8f6d310b2944
443093e8-83fc-4952-859a-692c727b5ec3	ad434e3f-b929-4ff4-a80d-11feac16b136	5d3decde-b899-4682-9dc6-d4cb91338e7a	D	MXN	3095.48	t	\N	\N	\N	2026-03-30 22:21:35.535	2026-03-30 22:21:39.172	c5582213-a38f-4d45-b15c-8f6d310b2944
c5a9d245-0989-421e-9654-7e052fcb9670	ad434e3f-b929-4ff4-a80d-11feac16b136	7595d52a-b509-4c49-9d77-87b8a8c0e0d5	A	MXN	2659.26	t	\N	\N	\N	2026-03-30 22:21:35.549	2026-03-30 22:21:39.189	050617d4-45fa-4394-b144-a361b9958c0b
0d3b4ace-15eb-4e07-b363-ceb72abbe7e7	ad434e3f-b929-4ff4-a80d-11feac16b136	7595d52a-b509-4c49-9d77-87b8a8c0e0d5	B	MXN	2792.20	t	\N	\N	\N	2026-03-30 22:21:35.557	2026-03-30 22:21:39.196	050617d4-45fa-4394-b144-a361b9958c0b
311c6fcc-c9fc-4003-8ad6-b0e9ff29f3cd	ad434e3f-b929-4ff4-a80d-11feac16b136	7595d52a-b509-4c49-9d77-87b8a8c0e0d5	C	MXN	2931.80	t	\N	\N	\N	2026-03-30 22:21:35.565	2026-03-30 22:21:39.204	050617d4-45fa-4394-b144-a361b9958c0b
6944825b-1729-4142-9ba2-47f843e4a6b7	ad434e3f-b929-4ff4-a80d-11feac16b136	7595d52a-b509-4c49-9d77-87b8a8c0e0d5	D	MXN	3078.36	t	\N	\N	\N	2026-03-30 22:21:35.574	2026-03-30 22:21:39.212	050617d4-45fa-4394-b144-a361b9958c0b
5a7ad018-36b8-4802-abd7-2dd9a45dbb3e	ad434e3f-b929-4ff4-a80d-11feac16b136	37ae24e2-6337-4eaf-916b-9f1a9f8252c9	A	MXN	2857.96	t	\N	\N	\N	2026-03-30 22:21:35.589	2026-03-30 22:21:39.235	f7c2bf16-6563-4291-a21f-3d31fa58afb6
34a2a446-cf0f-463a-ae90-6ee96226cfa5	ad434e3f-b929-4ff4-a80d-11feac16b136	37ae24e2-6337-4eaf-916b-9f1a9f8252c9	B	MXN	3000.83	t	\N	\N	\N	2026-03-30 22:21:35.597	2026-03-30 22:21:39.243	f7c2bf16-6563-4291-a21f-3d31fa58afb6
88e4f988-3e03-4e5b-8163-d873a0af70d1	ad434e3f-b929-4ff4-a80d-11feac16b136	37ae24e2-6337-4eaf-916b-9f1a9f8252c9	C	MXN	3150.86	t	\N	\N	\N	2026-03-30 22:21:35.608	2026-03-30 22:21:39.254	f7c2bf16-6563-4291-a21f-3d31fa58afb6
fd0afdf9-9e1f-4540-b926-f882f28f6ddc	ad434e3f-b929-4ff4-a80d-11feac16b136	37ae24e2-6337-4eaf-916b-9f1a9f8252c9	D	MXN	3308.37	t	\N	\N	\N	2026-03-30 22:21:35.617	2026-03-30 22:21:39.264	f7c2bf16-6563-4291-a21f-3d31fa58afb6
b2d501f8-b9ff-4526-9cda-45d0b370062e	ad434e3f-b929-4ff4-a80d-11feac16b136	4d35c1d2-e088-4393-b2fb-ed2e7b7b511d	B	MXN	3199.93	t	\N	\N	\N	2026-03-30 22:21:35.641	2026-03-30 22:21:39.289	029a73b5-1508-42b8-8409-cf6d31991cbe
62d56ffd-817c-445e-8541-ac71ef9107af	ad434e3f-b929-4ff4-a80d-11feac16b136	4d35c1d2-e088-4393-b2fb-ed2e7b7b511d	C	MXN	3359.91	t	\N	\N	\N	2026-03-30 22:21:35.647	2026-03-30 22:21:39.297	029a73b5-1508-42b8-8409-cf6d31991cbe
addbcd02-f045-40ab-9755-eb77fa0fd0e5	ad434e3f-b929-4ff4-a80d-11feac16b136	4d35c1d2-e088-4393-b2fb-ed2e7b7b511d	D	MXN	3527.88	t	\N	\N	\N	2026-03-30 22:21:35.652	2026-03-30 22:21:39.306	029a73b5-1508-42b8-8409-cf6d31991cbe
0f163a4c-0b81-4a74-b700-02c11ff58f55	ad434e3f-b929-4ff4-a80d-11feac16b136	ab6dd978-ac6b-4d6c-b43e-393cfc8f1f38	A	MXN	2876.65	t	\N	\N	\N	2026-03-30 22:21:35.666	2026-03-30 22:21:39.321	baa18bf5-bfda-43f8-af81-a24068303eaf
1e5c86c7-4df1-4422-90a8-6e5343effa58	ad434e3f-b929-4ff4-a80d-11feac16b136	ab6dd978-ac6b-4d6c-b43e-393cfc8f1f38	B	MXN	3020.46	t	\N	\N	\N	2026-03-30 22:21:35.673	2026-03-30 22:21:39.329	baa18bf5-bfda-43f8-af81-a24068303eaf
0cbd05a8-9f79-466a-959a-2ac3f31a7c6e	ad434e3f-b929-4ff4-a80d-11feac16b136	ab6dd978-ac6b-4d6c-b43e-393cfc8f1f38	C	MXN	3171.47	t	\N	\N	\N	2026-03-30 22:21:35.679	2026-03-30 22:21:39.339	baa18bf5-bfda-43f8-af81-a24068303eaf
5571ea4a-a73f-44ef-b9b8-fb98a8ba59c0	ad434e3f-b929-4ff4-a80d-11feac16b136	ab6dd978-ac6b-4d6c-b43e-393cfc8f1f38	D	MXN	3330.02	t	\N	\N	\N	2026-03-30 22:21:35.688	2026-03-30 22:21:39.347	baa18bf5-bfda-43f8-af81-a24068303eaf
aa0bd284-8678-41c2-984d-4d05e14b2e86	ad434e3f-b929-4ff4-a80d-11feac16b136	e8b0d497-0784-48dc-9622-fa1c0ff0afc6	B	MXN	2997.37	t	\N	\N	\N	2026-03-30 22:21:35.711	2026-03-30 22:21:39.373	9aaf4531-2747-47d4-aec4-3b3e3d7470e5
38c22aef-ef0e-43b3-a77f-8e3c6cdeaa24	ad434e3f-b929-4ff4-a80d-11feac16b136	e8b0d497-0784-48dc-9622-fa1c0ff0afc6	C	MXN	3147.22	t	\N	\N	\N	2026-03-30 22:21:35.717	2026-03-30 22:21:39.382	9aaf4531-2747-47d4-aec4-3b3e3d7470e5
e9e416f6-53e7-4718-a7a9-a449f86223ae	ad434e3f-b929-4ff4-a80d-11feac16b136	e8b0d497-0784-48dc-9622-fa1c0ff0afc6	D	MXN	3304.55	t	\N	\N	\N	2026-03-30 22:21:35.724	2026-03-30 22:21:39.391	9aaf4531-2747-47d4-aec4-3b3e3d7470e5
731618e4-3c07-4805-874f-71f7291465f6	ad434e3f-b929-4ff4-a80d-11feac16b136	e4bc3270-0a38-461e-a321-211a7ebd94b3	A	MXN	5826.00	t	\N	\N	\N	2026-03-30 22:21:35.739	2026-03-30 22:21:39.412	8d0a57ce-c21e-4988-a81e-f962791c3253
d8f6542f-6eb9-46f8-9c1d-877919ec54e3	ad434e3f-b929-4ff4-a80d-11feac16b136	e4bc3270-0a38-461e-a321-211a7ebd94b3	B	MXN	6117.26	t	\N	\N	\N	2026-03-30 22:21:35.745	2026-03-30 22:21:39.426	8d0a57ce-c21e-4988-a81e-f962791c3253
7a23cea9-1f71-4e2f-8bf7-8d01d76cacca	ad434e3f-b929-4ff4-a80d-11feac16b136	e4bc3270-0a38-461e-a321-211a7ebd94b3	C	MXN	6423.08	t	\N	\N	\N	2026-03-30 22:21:35.752	2026-03-30 22:21:39.435	8d0a57ce-c21e-4988-a81e-f962791c3253
471dfe42-e616-437e-a7fd-324388a733c1	ad434e3f-b929-4ff4-a80d-11feac16b136	e4bc3270-0a38-461e-a321-211a7ebd94b3	D	MXN	6744.20	t	\N	\N	\N	2026-03-30 22:21:35.759	2026-03-30 22:21:39.443	8d0a57ce-c21e-4988-a81e-f962791c3253
b3ce4b4e-7f37-44c2-909d-63aa4953f77b	ad434e3f-b929-4ff4-a80d-11feac16b136	e4bc3270-0a38-461e-a321-211a7ebd94b3	A	MXN	5840.32	t	\N	\N	\N	2026-03-30 22:21:35.776	2026-03-30 22:21:39.461	d2f8817b-edb9-43c2-95ff-2542fd70f60b
8ceb9aad-1d0c-426b-963d-d4b4e25999cb	ad434e3f-b929-4ff4-a80d-11feac16b136	e4bc3270-0a38-461e-a321-211a7ebd94b3	B	MXN	6132.28	t	\N	\N	\N	2026-03-30 22:21:35.784	2026-03-30 22:21:39.468	d2f8817b-edb9-43c2-95ff-2542fd70f60b
99c27559-266a-4dcc-8972-cb44b26b131d	ad434e3f-b929-4ff4-a80d-11feac16b136	e4bc3270-0a38-461e-a321-211a7ebd94b3	C	MXN	6438.86	t	\N	\N	\N	2026-03-30 22:21:35.791	2026-03-30 22:21:39.477	d2f8817b-edb9-43c2-95ff-2542fd70f60b
144baeb5-f035-40bb-9e36-f3aee4a9c718	ad434e3f-b929-4ff4-a80d-11feac16b136	e4bc3270-0a38-461e-a321-211a7ebd94b3	D	MXN	6760.78	t	\N	\N	\N	2026-03-30 22:21:35.798	2026-03-30 22:21:39.484	d2f8817b-edb9-43c2-95ff-2542fd70f60b
81f4bb37-163d-49d4-abf1-d27cfeb0296f	ad434e3f-b929-4ff4-a80d-11feac16b136	e4bc3270-0a38-461e-a321-211a7ebd94b3	A	MXN	6101.26	t	\N	\N	\N	2026-03-30 22:21:35.814	2026-03-30 22:21:39.501	472a6f96-284f-4cf9-9df9-f159e48309a1
5eb12edf-c56a-4ca5-a945-cdf00a295f57	ad434e3f-b929-4ff4-a80d-11feac16b136	e4bc3270-0a38-461e-a321-211a7ebd94b3	B	MXN	6406.26	t	\N	\N	\N	2026-03-30 22:21:35.822	2026-03-30 22:21:39.509	472a6f96-284f-4cf9-9df9-f159e48309a1
7d5a56f1-cb1a-4723-989b-e27b6ef5007d	ad434e3f-b929-4ff4-a80d-11feac16b136	e4bc3270-0a38-461e-a321-211a7ebd94b3	C	MXN	6726.54	t	\N	\N	\N	2026-03-30 22:21:35.83	2026-03-30 22:21:39.518	472a6f96-284f-4cf9-9df9-f159e48309a1
02db4609-2659-4c0d-8637-8a48b574bfe7	ad434e3f-b929-4ff4-a80d-11feac16b136	e4bc3270-0a38-461e-a321-211a7ebd94b3	D	MXN	7062.82	t	\N	\N	\N	2026-03-30 22:21:35.84	2026-03-30 22:21:39.531	472a6f96-284f-4cf9-9df9-f159e48309a1
4de38873-b63d-4af1-b4e9-202d9c8303db	ad434e3f-b929-4ff4-a80d-11feac16b136	e4bc3270-0a38-461e-a321-211a7ebd94b3	A	MXN	6264.56	t	\N	\N	\N	2026-03-30 22:21:35.856	2026-03-30 22:21:39.554	7f921d4d-e657-4228-bd91-fb5a3709636c
1377a948-af91-4101-9220-e322b2c4ba81	ad434e3f-b929-4ff4-a80d-11feac16b136	e4bc3270-0a38-461e-a321-211a7ebd94b3	B	MXN	6577.74	t	\N	\N	\N	2026-03-30 22:21:35.863	2026-03-30 22:21:39.563	7f921d4d-e657-4228-bd91-fb5a3709636c
f272c948-be18-4b51-8415-8a0a1a4d49bd	ad434e3f-b929-4ff4-a80d-11feac16b136	e4bc3270-0a38-461e-a321-211a7ebd94b3	C	MXN	6906.58	t	\N	\N	\N	2026-03-30 22:21:35.871	2026-03-30 22:21:39.574	7f921d4d-e657-4228-bd91-fb5a3709636c
4a1fccd7-5242-4a85-8c8f-78ce195d2cc0	ad434e3f-b929-4ff4-a80d-11feac16b136	e4bc3270-0a38-461e-a321-211a7ebd94b3	D	MXN	7251.88	t	\N	\N	\N	2026-03-30 22:21:35.878	2026-03-30 22:21:39.585	7f921d4d-e657-4228-bd91-fb5a3709636c
e4638acb-d38d-420e-9e19-ccb2e248cb9f	ad434e3f-b929-4ff4-a80d-11feac16b136	d6d4bb71-ab21-43b4-9187-41dc7eb19dc1	A	MXN	6277.48	t	\N	\N	\N	2026-03-30 22:21:35.893	2026-03-30 22:21:39.605	7305a3e8-416b-4e7d-8b94-ec97f10707fb
2181e8d6-ff82-40e0-96aa-51834bc9e679	ad434e3f-b929-4ff4-a80d-11feac16b136	d6d4bb71-ab21-43b4-9187-41dc7eb19dc1	B	MXN	6591.32	t	\N	\N	\N	2026-03-30 22:21:35.901	2026-03-30 22:21:39.616	7305a3e8-416b-4e7d-8b94-ec97f10707fb
944a6d79-d2eb-4712-a054-9cd5be2c085c	ad434e3f-b929-4ff4-a80d-11feac16b136	d6d4bb71-ab21-43b4-9187-41dc7eb19dc1	C	MXN	6920.84	t	\N	\N	\N	2026-03-30 22:21:35.909	2026-03-30 22:21:39.624	7305a3e8-416b-4e7d-8b94-ec97f10707fb
41f3ce65-ecfb-43d1-9a3c-552fdf6639b0	ad434e3f-b929-4ff4-a80d-11feac16b136	d6d4bb71-ab21-43b4-9187-41dc7eb19dc1	D	MXN	7266.84	t	\N	\N	\N	2026-03-30 22:21:35.921	2026-03-30 22:21:39.634	7305a3e8-416b-4e7d-8b94-ec97f10707fb
53a89e1b-ce05-4a89-befe-649189632729	ad434e3f-b929-4ff4-a80d-11feac16b136	d6d4bb71-ab21-43b4-9187-41dc7eb19dc1	A	MXN	6291.80	t	\N	\N	\N	2026-03-30 22:21:35.937	2026-03-30 22:21:39.651	1b09736f-0666-4b0b-a203-b0433f8c0407
ecfe6088-a97e-447f-bf13-ccb5d7d01e1c	ad434e3f-b929-4ff4-a80d-11feac16b136	d6d4bb71-ab21-43b4-9187-41dc7eb19dc1	B	MXN	6606.34	t	\N	\N	\N	2026-03-30 22:21:35.946	2026-03-30 22:21:39.658	1b09736f-0666-4b0b-a203-b0433f8c0407
ba582b53-fb71-4e97-900e-fe5e747faaba	ad434e3f-b929-4ff4-a80d-11feac16b136	d6d4bb71-ab21-43b4-9187-41dc7eb19dc1	C	MXN	6936.62	t	\N	\N	\N	2026-03-30 22:21:35.955	2026-03-30 22:21:39.666	1b09736f-0666-4b0b-a203-b0433f8c0407
cbdffccd-5e74-4fba-8200-120322a358bc	ad434e3f-b929-4ff4-a80d-11feac16b136	d6d4bb71-ab21-43b4-9187-41dc7eb19dc1	D	MXN	7283.42	t	\N	\N	\N	2026-03-30 22:21:35.964	2026-03-30 22:21:39.675	1b09736f-0666-4b0b-a203-b0433f8c0407
08afe767-be3f-4758-bde3-89fd6af700d7	ad434e3f-b929-4ff4-a80d-11feac16b136	d6d4bb71-ab21-43b4-9187-41dc7eb19dc1	A	MXN	6552.74	t	\N	\N	\N	2026-03-30 22:21:35.982	2026-03-30 22:21:39.691	7616453f-08d1-4fe2-9463-d22d04401c88
21a80adb-5c15-420a-a035-d68f4df74823	ad434e3f-b929-4ff4-a80d-11feac16b136	d6d4bb71-ab21-43b4-9187-41dc7eb19dc1	C	MXN	7224.30	t	\N	\N	\N	2026-03-30 22:21:36	2026-03-30 22:21:39.707	7616453f-08d1-4fe2-9463-d22d04401c88
57becf16-8dc0-4844-b653-33234c8c0377	ad434e3f-b929-4ff4-a80d-11feac16b136	d6d4bb71-ab21-43b4-9187-41dc7eb19dc1	D	MXN	7585.46	t	\N	\N	\N	2026-03-30 22:21:36.008	2026-03-30 22:21:39.714	7616453f-08d1-4fe2-9463-d22d04401c88
bd36552f-cdd2-4a58-aa15-560e7f9a823d	ad434e3f-b929-4ff4-a80d-11feac16b136	d6d4bb71-ab21-43b4-9187-41dc7eb19dc1	A	MXN	6716.04	t	\N	\N	\N	2026-03-30 22:21:36.024	2026-03-30 22:21:39.733	28f9e816-a6c8-4ab3-9f74-62380c1fbbc4
ef357f6d-12cc-47e7-acec-dff275b5ef7a	ad434e3f-b929-4ff4-a80d-11feac16b136	d6d4bb71-ab21-43b4-9187-41dc7eb19dc1	B	MXN	7051.80	t	\N	\N	\N	2026-03-30 22:21:36.031	2026-03-30 22:21:39.74	28f9e816-a6c8-4ab3-9f74-62380c1fbbc4
c869522c-ad03-4d5b-8110-9b6caa27c42b	ad434e3f-b929-4ff4-a80d-11feac16b136	d6d4bb71-ab21-43b4-9187-41dc7eb19dc1	C	MXN	7404.34	t	\N	\N	\N	2026-03-30 22:21:36.039	2026-03-30 22:21:39.748	28f9e816-a6c8-4ab3-9f74-62380c1fbbc4
eb8e944e-10d0-47b0-a620-ac96afb32c82	ad434e3f-b929-4ff4-a80d-11feac16b136	d6d4bb71-ab21-43b4-9187-41dc7eb19dc1	D	MXN	7774.52	t	\N	\N	\N	2026-03-30 22:21:36.048	2026-03-30 22:21:39.76	28f9e816-a6c8-4ab3-9f74-62380c1fbbc4
4a4a31c4-e6a3-4a96-9ee4-95065a03f0b4	ad434e3f-b929-4ff4-a80d-11feac16b136	26d54ae1-6589-404b-b97e-5844a49a4126	A	MXN	5909.38	t	\N	\N	\N	2026-03-30 22:21:36.065	2026-03-30 22:21:39.776	762ef71e-b6c3-4311-81e9-b7ef591e442c
76f0f9d1-0de1-4793-ae60-718c568a7893	ad434e3f-b929-4ff4-a80d-11feac16b136	26d54ae1-6589-404b-b97e-5844a49a4126	C	MXN	6515.02	t	\N	\N	\N	2026-03-30 22:21:36.084	2026-03-30 22:21:39.794	762ef71e-b6c3-4311-81e9-b7ef591e442c
900c5544-b698-4538-bc29-3880b5f26a5e	ad434e3f-b929-4ff4-a80d-11feac16b136	26d54ae1-6589-404b-b97e-5844a49a4126	D	MXN	6840.74	t	\N	\N	\N	2026-03-30 22:21:36.091	2026-03-30 22:21:39.802	762ef71e-b6c3-4311-81e9-b7ef591e442c
2952f72c-6158-4217-b7f8-53fe1bd34346	ad434e3f-b929-4ff4-a80d-11feac16b136	26d54ae1-6589-404b-b97e-5844a49a4126	A	MXN	5923.70	t	\N	\N	\N	2026-03-30 22:21:36.108	2026-03-30 22:21:39.817	26662e5f-b0c4-406f-83c5-255fab6e60cc
8e913d32-3828-4b43-a34e-2bb2b9abc9f8	ad434e3f-b929-4ff4-a80d-11feac16b136	26d54ae1-6589-404b-b97e-5844a49a4126	B	MXN	6219.84	t	\N	\N	\N	2026-03-30 22:21:36.116	2026-03-30 22:21:39.826	26662e5f-b0c4-406f-83c5-255fab6e60cc
69e335e8-92ee-4b43-947e-921501dac9eb	ad434e3f-b929-4ff4-a80d-11feac16b136	26d54ae1-6589-404b-b97e-5844a49a4126	C	MXN	6530.80	t	\N	\N	\N	2026-03-30 22:21:36.125	2026-03-30 22:21:39.837	26662e5f-b0c4-406f-83c5-255fab6e60cc
ff600909-3e5c-4328-a856-64c041ed85a3	ad434e3f-b929-4ff4-a80d-11feac16b136	26d54ae1-6589-404b-b97e-5844a49a4126	D	MXN	6857.32	t	\N	\N	\N	2026-03-30 22:21:36.134	2026-03-30 22:21:39.845	26662e5f-b0c4-406f-83c5-255fab6e60cc
4ffd7848-cfe7-4311-a0e3-f2ed4e0f2e32	ad434e3f-b929-4ff4-a80d-11feac16b136	26d54ae1-6589-404b-b97e-5844a49a4126	A	MXN	6184.64	t	\N	\N	\N	2026-03-30 22:21:36.151	2026-03-30 22:21:39.865	c795860a-439d-4859-995a-134094570cc9
54a0d9a1-d9f6-450d-a695-4e36182c4645	ad434e3f-b929-4ff4-a80d-11feac16b136	26d54ae1-6589-404b-b97e-5844a49a4126	B	MXN	6493.82	t	\N	\N	\N	2026-03-30 22:21:36.157	2026-03-30 22:21:39.874	c795860a-439d-4859-995a-134094570cc9
a91e49aa-d9be-423c-981c-123702b49e06	ad434e3f-b929-4ff4-a80d-11feac16b136	26d54ae1-6589-404b-b97e-5844a49a4126	C	MXN	6818.48	t	\N	\N	\N	2026-03-30 22:21:36.165	2026-03-30 22:21:39.886	c795860a-439d-4859-995a-134094570cc9
71b843ed-0c7f-4beb-89f1-e80a4728f7fe	ad434e3f-b929-4ff4-a80d-11feac16b136	26d54ae1-6589-404b-b97e-5844a49a4126	D	MXN	7159.36	t	\N	\N	\N	2026-03-30 22:21:36.174	2026-03-30 22:21:39.894	c795860a-439d-4859-995a-134094570cc9
5f84f148-9930-43d8-b772-b090350ac013	ad434e3f-b929-4ff4-a80d-11feac16b136	26d54ae1-6589-404b-b97e-5844a49a4126	A	MXN	6347.94	t	\N	\N	\N	2026-03-30 22:21:36.192	2026-03-30 22:21:39.912	047fa171-7415-40a0-ad94-b3f35fc55803
8a49b0be-26c4-43b6-91d1-645c9c1c4e26	ad434e3f-b929-4ff4-a80d-11feac16b136	26d54ae1-6589-404b-b97e-5844a49a4126	B	MXN	6665.30	t	\N	\N	\N	2026-03-30 22:21:36.202	2026-03-30 22:21:39.921	047fa171-7415-40a0-ad94-b3f35fc55803
f1bcf19a-0c6e-4d52-8090-e23490c9ccbf	ad434e3f-b929-4ff4-a80d-11feac16b136	26d54ae1-6589-404b-b97e-5844a49a4126	C	MXN	6998.52	t	\N	\N	\N	2026-03-30 22:21:36.212	2026-03-30 22:21:39.929	047fa171-7415-40a0-ad94-b3f35fc55803
3e9e49fc-24b8-499f-883a-9b09cd8e57a1	ad434e3f-b929-4ff4-a80d-11feac16b136	26d54ae1-6589-404b-b97e-5844a49a4126	D	MXN	7348.42	t	\N	\N	\N	2026-03-30 22:21:36.223	2026-03-30 22:21:39.941	047fa171-7415-40a0-ad94-b3f35fc55803
a6fe0ea5-4e5a-48c3-937a-3cb93eaa8844	ad434e3f-b929-4ff4-a80d-11feac16b136	bcd1b43e-9c32-4fb2-a63a-791fd575e91c	A	MXN	5106.89	t	\N	\N	\N	2026-03-30 22:21:36.241	2026-03-30 22:21:39.96	d3fdc076-90a7-4152-b71d-8a207e9f395b
67b3c9d0-cb7f-46f9-a892-dbb0266fd9a7	ad434e3f-b929-4ff4-a80d-11feac16b136	bcd1b43e-9c32-4fb2-a63a-791fd575e91c	B	MXN	5362.21	t	\N	\N	\N	2026-03-30 22:21:36.254	2026-03-30 22:21:39.968	d3fdc076-90a7-4152-b71d-8a207e9f395b
2e0abfd3-52b5-49fb-b52f-2233fbb61b09	ad434e3f-b929-4ff4-a80d-11feac16b136	bcd1b43e-9c32-4fb2-a63a-791fd575e91c	C	MXN	5630.28	t	\N	\N	\N	2026-03-30 22:21:36.274	2026-03-30 22:21:39.975	d3fdc076-90a7-4152-b71d-8a207e9f395b
696949ac-51ef-4e1e-96d8-323c2dfb6bb3	ad434e3f-b929-4ff4-a80d-11feac16b136	bcd1b43e-9c32-4fb2-a63a-791fd575e91c	D	MXN	5911.76	t	\N	\N	\N	2026-03-30 22:21:36.29	2026-03-30 22:21:39.982	d3fdc076-90a7-4152-b71d-8a207e9f395b
0e2abfad-ecc7-46b2-a4d3-6d5c5f73245c	ad434e3f-b929-4ff4-a80d-11feac16b136	bcd1b43e-9c32-4fb2-a63a-791fd575e91c	A	MXN	5121.21	t	\N	\N	\N	2026-03-30 22:21:36.306	2026-03-30 22:21:40.005	42e6d5e9-8d7c-4ff6-b728-91346af7fad9
cb525786-b8cb-4475-bed9-2775d7dcef29	ad434e3f-b929-4ff4-a80d-11feac16b136	bcd1b43e-9c32-4fb2-a63a-791fd575e91c	B	MXN	5377.23	t	\N	\N	\N	2026-03-30 22:21:36.316	2026-03-30 22:21:40.015	42e6d5e9-8d7c-4ff6-b728-91346af7fad9
daf14373-537b-48be-bc21-c77767abf6d7	ad434e3f-b929-4ff4-a80d-11feac16b136	bcd1b43e-9c32-4fb2-a63a-791fd575e91c	C	MXN	5646.06	t	\N	\N	\N	2026-03-30 22:21:36.323	2026-03-30 22:21:40.025	42e6d5e9-8d7c-4ff6-b728-91346af7fad9
fc657a9f-8e59-41c8-9d0e-6b15fb899f2d	ad434e3f-b929-4ff4-a80d-11feac16b136	bcd1b43e-9c32-4fb2-a63a-791fd575e91c	D	MXN	5928.34	t	\N	\N	\N	2026-03-30 22:21:36.332	2026-03-30 22:21:40.033	42e6d5e9-8d7c-4ff6-b728-91346af7fad9
1ebd253c-8cf2-46b2-a00f-76da5bd60ae4	ad434e3f-b929-4ff4-a80d-11feac16b136	bcd1b43e-9c32-4fb2-a63a-791fd575e91c	A	MXN	5382.15	t	\N	\N	\N	2026-03-30 22:21:36.349	2026-03-30 22:21:40.05	9d6f498e-3656-4d04-9ffc-2297e760013d
3beae690-9d34-4860-b8a2-4f03470a9b57	ad434e3f-b929-4ff4-a80d-11feac16b136	bcd1b43e-9c32-4fb2-a63a-791fd575e91c	B	MXN	5651.21	t	\N	\N	\N	2026-03-30 22:21:36.362	2026-03-30 22:21:40.058	9d6f498e-3656-4d04-9ffc-2297e760013d
9a26601d-b4d4-4646-ac3b-18a72d0ef15b	ad434e3f-b929-4ff4-a80d-11feac16b136	bcd1b43e-9c32-4fb2-a63a-791fd575e91c	C	MXN	5933.74	t	\N	\N	\N	2026-03-30 22:21:36.37	2026-03-30 22:21:40.065	9d6f498e-3656-4d04-9ffc-2297e760013d
e2e79fef-4940-4cd3-8f78-306e8668230f	ad434e3f-b929-4ff4-a80d-11feac16b136	bcd1b43e-9c32-4fb2-a63a-791fd575e91c	D	MXN	6230.38	t	\N	\N	\N	2026-03-30 22:21:36.378	2026-03-30 22:21:40.072	9d6f498e-3656-4d04-9ffc-2297e760013d
eb1dd0e8-58c6-4a16-831c-a03684cd39dc	ad434e3f-b929-4ff4-a80d-11feac16b136	bcd1b43e-9c32-4fb2-a63a-791fd575e91c	A	MXN	5545.45	t	\N	\N	\N	2026-03-30 22:21:36.398	2026-03-30 22:21:40.087	9d0373fb-cc23-451a-9b90-cf01c2f65e74
992fd23b-cdac-4a99-897c-b5ec1f1ad526	ad434e3f-b929-4ff4-a80d-11feac16b136	bcd1b43e-9c32-4fb2-a63a-791fd575e91c	B	MXN	5822.69	t	\N	\N	\N	2026-03-30 22:21:36.41	2026-03-30 22:21:40.095	9d0373fb-cc23-451a-9b90-cf01c2f65e74
155ae24d-c6ba-4d7a-a602-1a1715f03385	ad434e3f-b929-4ff4-a80d-11feac16b136	bcd1b43e-9c32-4fb2-a63a-791fd575e91c	D	MXN	6419.44	t	\N	\N	\N	2026-03-30 22:21:36.428	2026-03-30 22:21:40.113	9d0373fb-cc23-451a-9b90-cf01c2f65e74
a1432d0f-6ce0-4ec6-bc08-a0f26deff4bc	ad434e3f-b929-4ff4-a80d-11feac16b136	008b256d-38f7-4781-83cf-04b1f624051e	A	MXN	5329.36	t	\N	\N	\N	2026-03-30 22:21:36.447	2026-03-30 22:21:40.13	3e5a0d7d-1be8-44bd-82c5-45ae67aa2978
053a837a-6e2f-4de3-8bc8-0f33f5409831	ad434e3f-b929-4ff4-a80d-11feac16b136	008b256d-38f7-4781-83cf-04b1f624051e	B	MXN	5595.80	t	\N	\N	\N	2026-03-30 22:21:36.457	2026-03-30 22:21:40.139	3e5a0d7d-1be8-44bd-82c5-45ae67aa2978
f3c89ade-ef41-4e8c-a52b-460edb88360d	ad434e3f-b929-4ff4-a80d-11feac16b136	008b256d-38f7-4781-83cf-04b1f624051e	C	MXN	5875.55	t	\N	\N	\N	2026-03-30 22:21:36.465	2026-03-30 22:21:40.146	3e5a0d7d-1be8-44bd-82c5-45ae67aa2978
7edd0394-16b3-4802-9966-60b3050c05f4	ad434e3f-b929-4ff4-a80d-11feac16b136	008b256d-38f7-4781-83cf-04b1f624051e	D	MXN	6169.30	t	\N	\N	\N	2026-03-30 22:21:36.472	2026-03-30 22:21:40.154	3e5a0d7d-1be8-44bd-82c5-45ae67aa2978
1effe735-53cf-45b2-b844-2d4caa37d067	ad434e3f-b929-4ff4-a80d-11feac16b136	008b256d-38f7-4781-83cf-04b1f624051e	A	MXN	5343.68	t	\N	\N	\N	2026-03-30 22:21:36.488	2026-03-30 22:21:40.173	2c571442-156d-4258-b1d1-4a369f742bd4
f5291e94-dd2a-4713-a812-9b17c873de71	ad434e3f-b929-4ff4-a80d-11feac16b136	008b256d-38f7-4781-83cf-04b1f624051e	B	MXN	5610.82	t	\N	\N	\N	2026-03-30 22:21:36.497	2026-03-30 22:21:40.182	2c571442-156d-4258-b1d1-4a369f742bd4
f0d55e86-1a2b-467d-bb48-b8123e92d94a	ad434e3f-b929-4ff4-a80d-11feac16b136	008b256d-38f7-4781-83cf-04b1f624051e	D	MXN	6185.88	t	\N	\N	\N	2026-03-30 22:21:36.514	2026-03-30 22:21:40.2	2c571442-156d-4258-b1d1-4a369f742bd4
fe15cb9e-48ba-4c72-a6b0-309fc5b9f83d	ad434e3f-b929-4ff4-a80d-11feac16b136	008b256d-38f7-4781-83cf-04b1f624051e	A	MXN	5604.62	t	\N	\N	\N	2026-03-30 22:21:36.531	2026-03-30 22:21:40.215	1b5799bf-a6e5-4a3b-9db6-f596e5bb4555
50d95d73-c07e-4a32-bd62-ce21963f5aef	ad434e3f-b929-4ff4-a80d-11feac16b136	008b256d-38f7-4781-83cf-04b1f624051e	B	MXN	5884.80	t	\N	\N	\N	2026-03-30 22:21:36.538	2026-03-30 22:21:40.223	1b5799bf-a6e5-4a3b-9db6-f596e5bb4555
96644e88-9f05-42c5-baca-18af03e824fc	ad434e3f-b929-4ff4-a80d-11feac16b136	008b256d-38f7-4781-83cf-04b1f624051e	C	MXN	6179.01	t	\N	\N	\N	2026-03-30 22:21:36.544	2026-03-30 22:21:40.232	1b5799bf-a6e5-4a3b-9db6-f596e5bb4555
8c1e05f1-c996-464a-a8be-192ea19e9b46	ad434e3f-b929-4ff4-a80d-11feac16b136	008b256d-38f7-4781-83cf-04b1f624051e	D	MXN	6487.92	t	\N	\N	\N	2026-03-30 22:21:36.552	2026-03-30 22:21:40.24	1b5799bf-a6e5-4a3b-9db6-f596e5bb4555
4cbab1f7-bef9-44c8-89aa-29b420c9f77d	ad434e3f-b929-4ff4-a80d-11feac16b136	008b256d-38f7-4781-83cf-04b1f624051e	A	MXN	5767.92	t	\N	\N	\N	2026-03-30 22:21:36.569	2026-03-30 22:21:40.258	1d5fb1fe-3c6c-4af4-999d-e38397b05468
43ff527b-aabf-44cc-bb44-3f53aa2f4df7	ad434e3f-b929-4ff4-a80d-11feac16b136	008b256d-38f7-4781-83cf-04b1f624051e	B	MXN	6056.28	t	\N	\N	\N	2026-03-30 22:21:36.578	2026-03-30 22:21:40.266	1d5fb1fe-3c6c-4af4-999d-e38397b05468
2ba740de-d843-413b-9b41-d3d4206602de	ad434e3f-b929-4ff4-a80d-11feac16b136	008b256d-38f7-4781-83cf-04b1f624051e	C	MXN	6359.05	t	\N	\N	\N	2026-03-30 22:21:36.586	2026-03-30 22:21:40.276	1d5fb1fe-3c6c-4af4-999d-e38397b05468
ddc7cf9f-3bc6-41d0-951e-c270d5b5dee7	ad434e3f-b929-4ff4-a80d-11feac16b136	008b256d-38f7-4781-83cf-04b1f624051e	D	MXN	6676.98	t	\N	\N	\N	2026-03-30 22:21:36.595	2026-03-30 22:21:40.284	1d5fb1fe-3c6c-4af4-999d-e38397b05468
c46b2e89-677f-41dc-925c-33b3d115058e	ad434e3f-b929-4ff4-a80d-11feac16b136	9cca5e76-de22-447c-a1bd-e5d16142d93e	A	MXN	5148.58	t	\N	\N	\N	2026-03-30 22:21:36.612	2026-03-30 22:21:40.301	0e199f32-c3af-4ac0-b5d4-e629da9e2187
0dde17c3-9ad2-4f25-8c5a-cde815e5fd11	ad434e3f-b929-4ff4-a80d-11feac16b136	9cca5e76-de22-447c-a1bd-e5d16142d93e	B	MXN	5405.98	t	\N	\N	\N	2026-03-30 22:21:36.621	2026-03-30 22:21:40.309	0e199f32-c3af-4ac0-b5d4-e629da9e2187
2fa43a66-7f01-4a42-9749-b7fd402fe438	ad434e3f-b929-4ff4-a80d-11feac16b136	9cca5e76-de22-447c-a1bd-e5d16142d93e	C	MXN	5676.24	t	\N	\N	\N	2026-03-30 22:21:36.63	2026-03-30 22:21:40.318	0e199f32-c3af-4ac0-b5d4-e629da9e2187
667b8576-b29b-48b5-9018-c9aa7f20f8fc	ad434e3f-b929-4ff4-a80d-11feac16b136	9cca5e76-de22-447c-a1bd-e5d16142d93e	D	MXN	5960.02	t	\N	\N	\N	2026-03-30 22:21:36.637	2026-03-30 22:21:40.329	0e199f32-c3af-4ac0-b5d4-e629da9e2187
d4e6509c-77b3-4c9e-846a-d9c97edda31e	ad434e3f-b929-4ff4-a80d-11feac16b136	9cca5e76-de22-447c-a1bd-e5d16142d93e	A	MXN	5162.90	t	\N	\N	\N	2026-03-30 22:21:36.652	2026-03-30 22:21:40.345	083939fd-ddcb-4ce4-bffa-815de313defe
6c16139e-3865-4f02-8492-bead79dfdc79	ad434e3f-b929-4ff4-a80d-11feac16b136	9cca5e76-de22-447c-a1bd-e5d16142d93e	B	MXN	5421.00	t	\N	\N	\N	2026-03-30 22:21:36.66	2026-03-30 22:21:40.353	083939fd-ddcb-4ce4-bffa-815de313defe
1cc81c5e-d24e-4cb2-a07b-f7e1c39172c7	ad434e3f-b929-4ff4-a80d-11feac16b136	9cca5e76-de22-447c-a1bd-e5d16142d93e	C	MXN	5692.02	t	\N	\N	\N	2026-03-30 22:21:36.667	2026-03-30 22:21:40.362	083939fd-ddcb-4ce4-bffa-815de313defe
26d6d7d2-aaba-4f52-a746-099af07ab367	ad434e3f-b929-4ff4-a80d-11feac16b136	9cca5e76-de22-447c-a1bd-e5d16142d93e	D	MXN	5976.60	t	\N	\N	\N	2026-03-30 22:21:36.674	2026-03-30 22:21:40.37	083939fd-ddcb-4ce4-bffa-815de313defe
4496d7a8-a724-46f1-9617-9e3bd2079e65	ad434e3f-b929-4ff4-a80d-11feac16b136	9cca5e76-de22-447c-a1bd-e5d16142d93e	A	MXN	5423.84	t	\N	\N	\N	2026-03-30 22:21:36.689	2026-03-30 22:21:40.385	13f71920-4a3d-4077-a201-1bd773ff22a4
fd789cb8-9026-4663-a123-cad15619271f	ad434e3f-b929-4ff4-a80d-11feac16b136	9cca5e76-de22-447c-a1bd-e5d16142d93e	B	MXN	5694.98	t	\N	\N	\N	2026-03-30 22:21:36.695	2026-03-30 22:21:40.391	13f71920-4a3d-4077-a201-1bd773ff22a4
7c7d5853-8066-45a7-bfa7-1bce0574fd3b	ad434e3f-b929-4ff4-a80d-11feac16b136	9cca5e76-de22-447c-a1bd-e5d16142d93e	C	MXN	5979.70	t	\N	\N	\N	2026-03-30 22:21:36.703	2026-03-30 22:21:40.398	13f71920-4a3d-4077-a201-1bd773ff22a4
64e338e7-0455-4f6c-af05-a054c541bf01	ad434e3f-b929-4ff4-a80d-11feac16b136	9cca5e76-de22-447c-a1bd-e5d16142d93e	D	MXN	6278.64	t	\N	\N	\N	2026-03-30 22:21:36.71	2026-03-30 22:21:40.404	13f71920-4a3d-4077-a201-1bd773ff22a4
e7877c69-ba28-4175-bc94-e233b84e968f	ad434e3f-b929-4ff4-a80d-11feac16b136	9cca5e76-de22-447c-a1bd-e5d16142d93e	A	MXN	5587.14	t	\N	\N	\N	2026-03-30 22:21:36.725	2026-03-30 22:21:40.418	8f8e58a8-fb67-4735-9d7b-12d0fd332123
71b783e7-5820-4718-8793-b6c08204f81c	ad434e3f-b929-4ff4-a80d-11feac16b136	9cca5e76-de22-447c-a1bd-e5d16142d93e	B	MXN	5866.46	t	\N	\N	\N	2026-03-30 22:21:36.733	2026-03-30 22:21:40.426	8f8e58a8-fb67-4735-9d7b-12d0fd332123
4bf6cf4f-918e-4faf-b9ed-0f29c49e6729	ad434e3f-b929-4ff4-a80d-11feac16b136	9cca5e76-de22-447c-a1bd-e5d16142d93e	C	MXN	6159.74	t	\N	\N	\N	2026-03-30 22:21:36.74	2026-03-30 22:21:40.433	8f8e58a8-fb67-4735-9d7b-12d0fd332123
206e316c-b536-4b7c-9d59-e97e5a2cd59e	ad434e3f-b929-4ff4-a80d-11feac16b136	9cca5e76-de22-447c-a1bd-e5d16142d93e	D	MXN	6467.70	t	\N	\N	\N	2026-03-30 22:21:36.746	2026-03-30 22:21:40.44	8f8e58a8-fb67-4735-9d7b-12d0fd332123
45274986-07b2-4973-87ed-a9d19d695ee7	ad434e3f-b929-4ff4-a80d-11feac16b136	bd2b7acf-9367-419f-a8b1-7e4053fd4ff9	A	MXN	5190.07	t	\N	\N	\N	2026-03-30 22:21:36.758	2026-03-30 22:21:40.454	d6beb8d9-dbf3-46cf-a9a7-ac7f8f01665c
509364b9-933d-4e75-81aa-387f31011e8c	ad434e3f-b929-4ff4-a80d-11feac16b136	bd2b7acf-9367-419f-a8b1-7e4053fd4ff9	B	MXN	5449.55	t	\N	\N	\N	2026-03-30 22:21:36.764	2026-03-30 22:21:40.46	d6beb8d9-dbf3-46cf-a9a7-ac7f8f01665c
6d2a9b91-f006-407a-a6b1-dafd575bb852	ad434e3f-b929-4ff4-a80d-11feac16b136	bd2b7acf-9367-419f-a8b1-7e4053fd4ff9	C	MXN	5721.98	t	\N	\N	\N	2026-03-30 22:21:36.77	2026-03-30 22:21:40.466	d6beb8d9-dbf3-46cf-a9a7-ac7f8f01665c
df86ecb6-1e7d-4d84-8022-d124335f3558	ad434e3f-b929-4ff4-a80d-11feac16b136	bd2b7acf-9367-419f-a8b1-7e4053fd4ff9	A	MXN	5204.39	t	\N	\N	\N	2026-03-30 22:21:36.793	2026-03-30 22:21:40.485	44508644-1678-4cf1-bd93-704cc110e85c
c1636a00-8ec2-497e-b318-7478c0cb3d8f	ad434e3f-b929-4ff4-a80d-11feac16b136	bd2b7acf-9367-419f-a8b1-7e4053fd4ff9	B	MXN	5464.57	t	\N	\N	\N	2026-03-30 22:21:36.801	2026-03-30 22:21:40.492	44508644-1678-4cf1-bd93-704cc110e85c
2a58ffd8-3329-4d9b-93d3-6120dfbea71b	ad434e3f-b929-4ff4-a80d-11feac16b136	bd2b7acf-9367-419f-a8b1-7e4053fd4ff9	C	MXN	5737.76	t	\N	\N	\N	2026-03-30 22:21:36.808	2026-03-30 22:21:40.499	44508644-1678-4cf1-bd93-704cc110e85c
c2a7e369-b3af-49fd-9fd3-ed6efed4cffb	ad434e3f-b929-4ff4-a80d-11feac16b136	bd2b7acf-9367-419f-a8b1-7e4053fd4ff9	D	MXN	6024.63	t	\N	\N	\N	2026-03-30 22:21:36.814	2026-03-30 22:21:40.506	44508644-1678-4cf1-bd93-704cc110e85c
a8fd1985-9194-413b-9f2c-0407dc9d01a0	ad434e3f-b929-4ff4-a80d-11feac16b136	bd2b7acf-9367-419f-a8b1-7e4053fd4ff9	A	MXN	5465.33	t	\N	\N	\N	2026-03-30 22:21:36.828	2026-03-30 22:21:40.521	a441d2fb-8dc3-42f8-a4bb-4eeb0a42fbf1
3bb76690-b9fb-49bf-b6e0-f585a24f23d5	ad434e3f-b929-4ff4-a80d-11feac16b136	bd2b7acf-9367-419f-a8b1-7e4053fd4ff9	B	MXN	5738.55	t	\N	\N	\N	2026-03-30 22:21:36.835	2026-03-30 22:21:40.53	a441d2fb-8dc3-42f8-a4bb-4eeb0a42fbf1
d83c4e43-a1bc-4df5-9f0f-767340741f2e	ad434e3f-b929-4ff4-a80d-11feac16b136	bd2b7acf-9367-419f-a8b1-7e4053fd4ff9	C	MXN	6025.44	t	\N	\N	\N	2026-03-30 22:21:36.841	2026-03-30 22:21:40.536	a441d2fb-8dc3-42f8-a4bb-4eeb0a42fbf1
a43ea6d0-aacf-4728-934b-a60285d42635	ad434e3f-b929-4ff4-a80d-11feac16b136	bd2b7acf-9367-419f-a8b1-7e4053fd4ff9	A	MXN	5628.63	t	\N	\N	\N	2026-03-30 22:21:36.865	2026-03-30 22:21:40.56	fb3beb95-e9a0-4439-bcf5-9f6d8e0d1364
9e3bc258-0e06-4989-8c20-44445849d07b	ad434e3f-b929-4ff4-a80d-11feac16b136	bd2b7acf-9367-419f-a8b1-7e4053fd4ff9	B	MXN	5910.03	t	\N	\N	\N	2026-03-30 22:21:36.874	2026-03-30 22:21:40.567	fb3beb95-e9a0-4439-bcf5-9f6d8e0d1364
c5ee92f8-2784-4fb6-ad5f-3dd2afbd51d5	ad434e3f-b929-4ff4-a80d-11feac16b136	bd2b7acf-9367-419f-a8b1-7e4053fd4ff9	C	MXN	6205.48	t	\N	\N	\N	2026-03-30 22:21:36.882	2026-03-30 22:21:40.574	fb3beb95-e9a0-4439-bcf5-9f6d8e0d1364
9812f6c2-f665-48f3-8673-e83927fe640d	ad434e3f-b929-4ff4-a80d-11feac16b136	bd2b7acf-9367-419f-a8b1-7e4053fd4ff9	D	MXN	6515.73	t	\N	\N	\N	2026-03-30 22:21:36.889	2026-03-30 22:21:40.581	fb3beb95-e9a0-4439-bcf5-9f6d8e0d1364
8d345113-7eee-4997-913f-0ab765c2d4a5	ad434e3f-b929-4ff4-a80d-11feac16b136	86e0de54-1f22-4556-9437-1b640d3d08cf	A	MXN	5357.13	t	\N	\N	\N	2026-03-30 22:21:36.905	2026-03-30 22:21:40.597	7cdec777-94f0-422f-8197-b31535358f92
9881a3f3-7fa7-42a0-9590-56e0839c0831	ad434e3f-b929-4ff4-a80d-11feac16b136	86e0de54-1f22-4556-9437-1b640d3d08cf	B	MXN	5624.96	t	\N	\N	\N	2026-03-30 22:21:36.913	2026-03-30 22:21:40.603	7cdec777-94f0-422f-8197-b31535358f92
8cf5c220-3f59-4053-8723-80dd08892778	ad434e3f-b929-4ff4-a80d-11feac16b136	86e0de54-1f22-4556-9437-1b640d3d08cf	C	MXN	5906.17	t	\N	\N	\N	2026-03-30 22:21:36.92	2026-03-30 22:21:40.612	7cdec777-94f0-422f-8197-b31535358f92
9b84c0b0-7623-4346-a287-1ea7270a3d8b	ad434e3f-b929-4ff4-a80d-11feac16b136	86e0de54-1f22-4556-9437-1b640d3d08cf	D	MXN	6201.45	t	\N	\N	\N	2026-03-30 22:21:36.927	2026-03-30 22:21:40.619	7cdec777-94f0-422f-8197-b31535358f92
71811402-4409-4008-8088-2d8e0e8d2a70	ad434e3f-b929-4ff4-a80d-11feac16b136	86e0de54-1f22-4556-9437-1b640d3d08cf	A	MXN	5371.45	t	\N	\N	\N	2026-03-30 22:21:36.942	2026-03-30 22:21:40.631	a3d5eff6-2603-4d20-bdce-9694d023245c
bbbcfed8-4139-41e0-999c-f99dd4a7dc48	ad434e3f-b929-4ff4-a80d-11feac16b136	86e0de54-1f22-4556-9437-1b640d3d08cf	B	MXN	5639.98	t	\N	\N	\N	2026-03-30 22:21:36.952	2026-03-30 22:21:40.637	a3d5eff6-2603-4d20-bdce-9694d023245c
a6fa7440-5199-45ab-80a6-6c6199becb1f	ad434e3f-b929-4ff4-a80d-11feac16b136	86e0de54-1f22-4556-9437-1b640d3d08cf	C	MXN	5921.95	t	\N	\N	\N	2026-03-30 22:21:36.959	2026-03-30 22:21:40.644	a3d5eff6-2603-4d20-bdce-9694d023245c
e286a683-6f84-4e0c-be18-48fbebdbcb93	ad434e3f-b929-4ff4-a80d-11feac16b136	86e0de54-1f22-4556-9437-1b640d3d08cf	D	MXN	6218.03	t	\N	\N	\N	2026-03-30 22:21:36.967	2026-03-30 22:21:40.65	a3d5eff6-2603-4d20-bdce-9694d023245c
e181d76a-422b-4bc8-a681-e04722f1a486	ad434e3f-b929-4ff4-a80d-11feac16b136	86e0de54-1f22-4556-9437-1b640d3d08cf	A	MXN	5632.39	t	\N	\N	\N	2026-03-30 22:21:36.982	2026-03-30 22:21:40.666	6eafd61d-f568-423e-8e6d-38c6e550b9c8
8f681275-001d-4e8b-a0a1-de8c3282c45f	ad434e3f-b929-4ff4-a80d-11feac16b136	86e0de54-1f22-4556-9437-1b640d3d08cf	B	MXN	5913.96	t	\N	\N	\N	2026-03-30 22:21:36.989	2026-03-30 22:21:40.674	6eafd61d-f568-423e-8e6d-38c6e550b9c8
c458424b-158b-4d47-9cd7-00eedb2551a1	ad434e3f-b929-4ff4-a80d-11feac16b136	86e0de54-1f22-4556-9437-1b640d3d08cf	C	MXN	6209.63	t	\N	\N	\N	2026-03-30 22:21:36.995	2026-03-30 22:21:40.681	6eafd61d-f568-423e-8e6d-38c6e550b9c8
f92e42c4-5a27-4f59-880a-62ca03652c42	ad434e3f-b929-4ff4-a80d-11feac16b136	86e0de54-1f22-4556-9437-1b640d3d08cf	D	MXN	6520.07	t	\N	\N	\N	2026-03-30 22:21:37.005	2026-03-30 22:21:40.688	6eafd61d-f568-423e-8e6d-38c6e550b9c8
a6a8139b-3454-46ee-b5a6-b87906541a72	ad434e3f-b929-4ff4-a80d-11feac16b136	86e0de54-1f22-4556-9437-1b640d3d08cf	A	MXN	5795.69	t	\N	\N	\N	2026-03-30 22:21:37.02	2026-03-30 22:21:40.702	dc9366fc-6f94-4668-bfe5-a4cad7fb9f68
2b2eea49-1ba0-4135-b5db-849661879220	ad434e3f-b929-4ff4-a80d-11feac16b136	86e0de54-1f22-4556-9437-1b640d3d08cf	B	MXN	6085.44	t	\N	\N	\N	2026-03-30 22:21:37.028	2026-03-30 22:21:40.71	dc9366fc-6f94-4668-bfe5-a4cad7fb9f68
e741914f-c04a-458b-b2c9-51f3ad5d5cc9	ad434e3f-b929-4ff4-a80d-11feac16b136	86e0de54-1f22-4556-9437-1b640d3d08cf	C	MXN	6389.67	t	\N	\N	\N	2026-03-30 22:21:37.038	2026-03-30 22:21:40.719	dc9366fc-6f94-4668-bfe5-a4cad7fb9f68
537ded3b-5a91-429f-ad64-a70594859b21	ad434e3f-b929-4ff4-a80d-11feac16b136	86e0de54-1f22-4556-9437-1b640d3d08cf	D	MXN	6709.13	t	\N	\N	\N	2026-03-30 22:21:37.048	2026-03-30 22:21:40.726	dc9366fc-6f94-4668-bfe5-a4cad7fb9f68
006cb6f8-a0a7-4359-825f-3f5556c17135	ad434e3f-b929-4ff4-a80d-11feac16b136	a3539472-03d3-4625-831f-246f355c82aa	A	MXN	5119.54	t	\N	\N	\N	2026-03-30 22:21:37.066	2026-03-30 22:21:40.743	7de45c2b-c1df-42b9-8d41-25c3d47d2da5
6959bdb4-f728-4349-9d41-102981edbe34	ad434e3f-b929-4ff4-a80d-11feac16b136	a3539472-03d3-4625-831f-246f355c82aa	B	MXN	5375.49	t	\N	\N	\N	2026-03-30 22:21:37.078	2026-03-30 22:21:40.753	7de45c2b-c1df-42b9-8d41-25c3d47d2da5
f997aa5a-70b0-4933-863b-a78ccf4ef1cf	ad434e3f-b929-4ff4-a80d-11feac16b136	a3539472-03d3-4625-831f-246f355c82aa	C	MXN	5644.22	t	\N	\N	\N	2026-03-30 22:21:37.086	2026-03-30 22:21:40.763	7de45c2b-c1df-42b9-8d41-25c3d47d2da5
05ad5936-a84f-45dc-a8be-0cf1c9827188	ad434e3f-b929-4ff4-a80d-11feac16b136	a3539472-03d3-4625-831f-246f355c82aa	D	MXN	5926.40	t	\N	\N	\N	2026-03-30 22:21:37.095	2026-03-30 22:21:40.77	7de45c2b-c1df-42b9-8d41-25c3d47d2da5
5b348fd4-a99c-43de-8bb0-3eb89d3d22cd	ad434e3f-b929-4ff4-a80d-11feac16b136	6d125e00-87ce-487a-9ab2-cc15e442d3af	A	MXN	5345.28	t	\N	\N	\N	2026-03-30 22:21:37.11	2026-03-30 22:21:40.789	f0b35e5c-2d30-4f9a-9f50-37432d807181
6d800e28-cf84-4a5c-b359-5740206b1e4d	ad434e3f-b929-4ff4-a80d-11feac16b136	6d125e00-87ce-487a-9ab2-cc15e442d3af	B	MXN	5612.52	t	\N	\N	\N	2026-03-30 22:21:37.118	2026-03-30 22:21:40.798	f0b35e5c-2d30-4f9a-9f50-37432d807181
95493816-d987-4ac6-bcf7-a7fc08ea8859	ad434e3f-b929-4ff4-a80d-11feac16b136	6d125e00-87ce-487a-9ab2-cc15e442d3af	C	MXN	5893.10	t	\N	\N	\N	2026-03-30 22:21:37.125	2026-03-30 22:21:40.806	f0b35e5c-2d30-4f9a-9f50-37432d807181
78f99621-587c-4688-a502-d05fc885d39f	ad434e3f-b929-4ff4-a80d-11feac16b136	6d125e00-87ce-487a-9ab2-cc15e442d3af	D	MXN	6187.72	t	\N	\N	\N	2026-03-30 22:21:37.133	2026-03-30 22:21:40.813	f0b35e5c-2d30-4f9a-9f50-37432d807181
b443c310-e0ca-4a63-aa53-ec4ca209a79f	ad434e3f-b929-4ff4-a80d-11feac16b136	421a93a9-10a5-418f-bb61-8c29065e7a8b	B	MXN	5419.27	t	\N	\N	\N	2026-03-30 22:21:37.157	2026-03-30 22:21:40.836	d6df0e90-98cf-416e-90dc-9c18f2b3a32b
27b0d4c3-6384-4b17-85aa-ea61a042e241	ad434e3f-b929-4ff4-a80d-11feac16b136	421a93a9-10a5-418f-bb61-8c29065e7a8b	C	MXN	5690.19	t	\N	\N	\N	2026-03-30 22:21:37.165	2026-03-30 22:21:40.844	d6df0e90-98cf-416e-90dc-9c18f2b3a32b
5f8957a4-1c7f-4e5f-9e45-583406816b04	ad434e3f-b929-4ff4-a80d-11feac16b136	421a93a9-10a5-418f-bb61-8c29065e7a8b	D	MXN	5974.67	t	\N	\N	\N	2026-03-30 22:21:37.173	2026-03-30 22:21:40.851	d6df0e90-98cf-416e-90dc-9c18f2b3a32b
cbac9bac-1c38-42e7-9226-c0c742913153	ad434e3f-b929-4ff4-a80d-11feac16b136	083a6238-60db-4b53-8617-f63f09870c1f	A	MXN	5183.19	t	\N	\N	\N	2026-03-30 22:21:37.187	2026-03-30 22:21:40.866	4e6ea854-51d6-4bec-a400-573d956b687c
3ef787c4-5151-4996-b453-725e70602a92	ad434e3f-b929-4ff4-a80d-11feac16b136	083a6238-60db-4b53-8617-f63f09870c1f	B	MXN	5442.33	t	\N	\N	\N	2026-03-30 22:21:37.195	2026-03-30 22:21:40.873	4e6ea854-51d6-4bec-a400-573d956b687c
3ccd6daf-7416-4f65-ac17-777d56054599	ad434e3f-b929-4ff4-a80d-11feac16b136	083a6238-60db-4b53-8617-f63f09870c1f	C	MXN	5714.40	t	\N	\N	\N	2026-03-30 22:21:37.204	2026-03-30 22:21:40.88	4e6ea854-51d6-4bec-a400-573d956b687c
d66a6875-2037-47d9-959a-68d6062fde4b	ad434e3f-b929-4ff4-a80d-11feac16b136	083a6238-60db-4b53-8617-f63f09870c1f	D	MXN	6000.09	t	\N	\N	\N	2026-03-30 22:21:37.211	2026-03-30 22:21:40.885	4e6ea854-51d6-4bec-a400-573d956b687c
a13e61d4-c374-4f05-8681-c0d36130b62e	ad434e3f-b929-4ff4-a80d-11feac16b136	cf163728-3824-4dae-a07c-4396b0da3382	B	MXN	5757.88	t	\N	\N	\N	2026-03-30 22:21:37.236	2026-03-30 22:21:40.904	e6de4041-2cd2-4c7a-bfc7-1124707d13da
1eea6014-d165-4572-aabe-aa002ecc4264	ad434e3f-b929-4ff4-a80d-11feac16b136	cf163728-3824-4dae-a07c-4396b0da3382	C	MXN	6045.73	t	\N	\N	\N	2026-03-30 22:21:37.244	2026-03-30 22:21:40.912	e6de4041-2cd2-4c7a-bfc7-1124707d13da
66d30193-fd9e-4cf4-8352-446724b71488	ad434e3f-b929-4ff4-a80d-11feac16b136	cf163728-3824-4dae-a07c-4396b0da3382	D	MXN	6347.98	t	\N	\N	\N	2026-03-30 22:21:37.254	2026-03-30 22:21:40.919	e6de4041-2cd2-4c7a-bfc7-1124707d13da
60a2952f-40d0-43c4-8f91-06f26063d326	ad434e3f-b929-4ff4-a80d-11feac16b136	9adabc28-d0a0-4175-b24b-0ee84e43d89b	A	MXN	5221.65	t	\N	\N	\N	2026-03-30 22:21:37.277	2026-03-30 22:21:40.934	54e3078c-d24a-47e1-a74d-dd52997c0062
12926e79-e4c0-4344-8628-e1b531ce7099	ad434e3f-b929-4ff4-a80d-11feac16b136	9adabc28-d0a0-4175-b24b-0ee84e43d89b	B	MXN	5482.71	t	\N	\N	\N	2026-03-30 22:21:37.293	2026-03-30 22:21:40.942	54e3078c-d24a-47e1-a74d-dd52997c0062
2b5076e4-86e8-49e7-a4e8-30fe7a131b6a	ad434e3f-b929-4ff4-a80d-11feac16b136	9adabc28-d0a0-4175-b24b-0ee84e43d89b	C	MXN	5756.80	t	\N	\N	\N	2026-03-30 22:21:37.3	2026-03-30 22:21:40.95	54e3078c-d24a-47e1-a74d-dd52997c0062
0349437b-5ede-4e51-b15b-45a976c7e7f2	ad434e3f-b929-4ff4-a80d-11feac16b136	9adabc28-d0a0-4175-b24b-0ee84e43d89b	D	MXN	6044.61	t	\N	\N	\N	2026-03-30 22:21:37.31	2026-03-30 22:21:40.958	54e3078c-d24a-47e1-a74d-dd52997c0062
933202ac-7f44-4580-9384-259b5caaf24f	ad434e3f-b929-4ff4-a80d-11feac16b136	5aab8c35-7477-495e-aa07-b6e4f6dbe457	A	MXN	6602.22	t	\N	\N	\N	2026-03-30 22:21:37.333	2026-03-30 22:21:40.976	f6bd8fc1-eabc-4724-be4e-7e1991d419af
c7236bae-a747-4288-bcbe-93003e7ca016	ad434e3f-b929-4ff4-a80d-11feac16b136	5aab8c35-7477-495e-aa07-b6e4f6dbe457	B	MXN	6932.30	t	\N	\N	\N	2026-03-30 22:21:37.34	2026-03-30 22:21:40.983	f6bd8fc1-eabc-4724-be4e-7e1991d419af
88098170-f256-4f1f-bff1-3faf6e53c69f	ad434e3f-b929-4ff4-a80d-11feac16b136	5aab8c35-7477-495e-aa07-b6e4f6dbe457	C	MXN	7278.88	t	\N	\N	\N	2026-03-30 22:21:37.349	2026-03-30 22:21:40.987	f6bd8fc1-eabc-4724-be4e-7e1991d419af
e161233f-4518-499c-b539-51533f74cbd6	ad434e3f-b929-4ff4-a80d-11feac16b136	5aab8c35-7477-495e-aa07-b6e4f6dbe457	D	MXN	7642.80	t	\N	\N	\N	2026-03-30 22:21:37.37	2026-03-30 22:21:40.993	f6bd8fc1-eabc-4724-be4e-7e1991d419af
49fb709d-692d-4b4c-ab53-5156de51755d	ad434e3f-b929-4ff4-a80d-11feac16b136	5aab8c35-7477-495e-aa07-b6e4f6dbe457	A	MXN	6612.16	t	\N	\N	\N	2026-03-30 22:21:37.389	2026-03-30 22:21:41.006	6271d55d-06bb-4ba4-8424-77ca16722d5c
ffb57d1f-846e-4a2b-a357-9a09e8a66dbc	ad434e3f-b929-4ff4-a80d-11feac16b136	5aab8c35-7477-495e-aa07-b6e4f6dbe457	B	MXN	6942.74	t	\N	\N	\N	2026-03-30 22:21:37.398	2026-03-30 22:21:41.014	6271d55d-06bb-4ba4-8424-77ca16722d5c
74980f20-ff01-48b4-ab67-2013d1d4efb1	ad434e3f-b929-4ff4-a80d-11feac16b136	5aab8c35-7477-495e-aa07-b6e4f6dbe457	C	MXN	7289.84	t	\N	\N	\N	2026-03-30 22:21:37.406	2026-03-30 22:21:41.021	6271d55d-06bb-4ba4-8424-77ca16722d5c
08532cb2-41ef-4580-b5af-591d352d4793	ad434e3f-b929-4ff4-a80d-11feac16b136	5aab8c35-7477-495e-aa07-b6e4f6dbe457	D	MXN	7654.30	t	\N	\N	\N	2026-03-30 22:21:37.415	2026-03-30 22:21:41.027	6271d55d-06bb-4ba4-8424-77ca16722d5c
d915fdf8-48d9-4242-971b-22ebcaafbb30	ad434e3f-b929-4ff4-a80d-11feac16b136	5aab8c35-7477-495e-aa07-b6e4f6dbe457	A	MXN	6872.50	t	\N	\N	\N	2026-03-30 22:21:37.434	2026-03-30 22:21:41.039	a505c639-1608-4ff5-9dbb-b48df37d5185
cf07b3f3-7f59-4574-aa02-5ddb0a6f56c7	ad434e3f-b929-4ff4-a80d-11feac16b136	5aab8c35-7477-495e-aa07-b6e4f6dbe457	B	MXN	7216.08	t	\N	\N	\N	2026-03-30 22:21:37.441	2026-03-30 22:21:41.046	a505c639-1608-4ff5-9dbb-b48df37d5185
c4c6361c-f2f0-42a4-9e45-5f7d13807cdf	ad434e3f-b929-4ff4-a80d-11feac16b136	5aab8c35-7477-495e-aa07-b6e4f6dbe457	C	MXN	7576.84	t	\N	\N	\N	2026-03-30 22:21:37.448	2026-03-30 22:21:41.052	a505c639-1608-4ff5-9dbb-b48df37d5185
3c7e6160-132d-4abd-9a99-b049b2b73bc8	ad434e3f-b929-4ff4-a80d-11feac16b136	5aab8c35-7477-495e-aa07-b6e4f6dbe457	D	MXN	7955.64	t	\N	\N	\N	2026-03-30 22:21:37.46	2026-03-30 22:21:41.06	a505c639-1608-4ff5-9dbb-b48df37d5185
09a30069-7f2c-4849-8aec-10df08c9976d	ad434e3f-b929-4ff4-a80d-11feac16b136	5aab8c35-7477-495e-aa07-b6e4f6dbe457	A	MXN	7031.44	t	\N	\N	\N	2026-03-30 22:21:37.491	2026-03-30 22:21:41.076	1c5c8279-58b5-432e-b922-f639a7ca10cd
f7589c87-6fab-48ec-a42b-a128c3ad8f91	ad434e3f-b929-4ff4-a80d-11feac16b136	5aab8c35-7477-495e-aa07-b6e4f6dbe457	B	MXN	7382.98	t	\N	\N	\N	2026-03-30 22:21:37.509	2026-03-30 22:21:41.084	1c5c8279-58b5-432e-b922-f639a7ca10cd
616c65cd-2e05-44c9-ab38-b929e06df1f8	ad434e3f-b929-4ff4-a80d-11feac16b136	5aab8c35-7477-495e-aa07-b6e4f6dbe457	C	MXN	7752.08	t	\N	\N	\N	2026-03-30 22:21:37.518	2026-03-30 22:21:41.091	1c5c8279-58b5-432e-b922-f639a7ca10cd
8634fde2-f570-48bb-8cbf-28da770fb971	ad434e3f-b929-4ff4-a80d-11feac16b136	5aab8c35-7477-495e-aa07-b6e4f6dbe457	D	MXN	8139.66	t	\N	\N	\N	2026-03-30 22:21:37.534	2026-03-30 22:21:41.098	1c5c8279-58b5-432e-b922-f639a7ca10cd
2a4cc1c4-b7d7-49fe-8f32-9df3e289dcec	ad434e3f-b929-4ff4-a80d-11feac16b136	a2cec753-8d86-42f4-9f45-16aaf894e4b2	A	MXN	7203.28	t	\N	\N	\N	2026-03-30 22:21:37.567	2026-03-30 22:21:41.112	8fa089b4-e69a-4488-bd5b-62d69909bee4
48d772cb-92d5-4abd-9cca-95693c3a3a33	ad434e3f-b929-4ff4-a80d-11feac16b136	a2cec753-8d86-42f4-9f45-16aaf894e4b2	B	MXN	7563.40	t	\N	\N	\N	2026-03-30 22:21:37.618	2026-03-30 22:21:41.12	8fa089b4-e69a-4488-bd5b-62d69909bee4
7dcd6346-4ab1-47a7-80c1-f2666725ea8f	ad434e3f-b929-4ff4-a80d-11feac16b136	a2cec753-8d86-42f4-9f45-16aaf894e4b2	C	MXN	7941.54	t	\N	\N	\N	2026-03-30 22:21:37.634	2026-03-30 22:21:41.129	8fa089b4-e69a-4488-bd5b-62d69909bee4
74052f8d-f0ea-444f-a00d-233f966e0d0b	ad434e3f-b929-4ff4-a80d-11feac16b136	a2cec753-8d86-42f4-9f45-16aaf894e4b2	D	MXN	8338.58	t	\N	\N	\N	2026-03-30 22:21:37.645	2026-03-30 22:21:41.137	8fa089b4-e69a-4488-bd5b-62d69909bee4
86f31407-a74c-4f01-af63-113b2ad7f6c3	ad434e3f-b929-4ff4-a80d-11feac16b136	a2cec753-8d86-42f4-9f45-16aaf894e4b2	A	MXN	7213.22	t	\N	\N	\N	2026-03-30 22:21:37.674	2026-03-30 22:21:41.152	7fb776aa-f13b-44b2-9091-d89f40ded4fd
6085541d-8a1d-46b7-8eb7-5f1d9f771383	ad434e3f-b929-4ff4-a80d-11feac16b136	a2cec753-8d86-42f4-9f45-16aaf894e4b2	C	MXN	7952.50	t	\N	\N	\N	2026-03-30 22:21:37.699	2026-03-30 22:21:41.168	7fb776aa-f13b-44b2-9091-d89f40ded4fd
3fc953b3-8426-4503-9f60-e0b08e717c63	ad434e3f-b929-4ff4-a80d-11feac16b136	a2cec753-8d86-42f4-9f45-16aaf894e4b2	D	MXN	8350.08	t	\N	\N	\N	2026-03-30 22:21:37.711	2026-03-30 22:21:41.179	7fb776aa-f13b-44b2-9091-d89f40ded4fd
72475feb-6648-4fd9-a3ec-7e95fd469b04	ad434e3f-b929-4ff4-a80d-11feac16b136	a2cec753-8d86-42f4-9f45-16aaf894e4b2	A	MXN	7473.56	t	\N	\N	\N	2026-03-30 22:21:37.734	2026-03-30 22:21:41.198	9c1e8d12-8bda-4837-9ad6-4a2d4a95b7ba
c99669f4-dfe8-46fd-8613-e366a5101684	ad434e3f-b929-4ff4-a80d-11feac16b136	a2cec753-8d86-42f4-9f45-16aaf894e4b2	B	MXN	7847.18	t	\N	\N	\N	2026-03-30 22:21:37.746	2026-03-30 22:21:41.205	9c1e8d12-8bda-4837-9ad6-4a2d4a95b7ba
e4497705-a795-4c5c-98c9-1953003f00df	ad434e3f-b929-4ff4-a80d-11feac16b136	a2cec753-8d86-42f4-9f45-16aaf894e4b2	C	MXN	8239.50	t	\N	\N	\N	2026-03-30 22:21:37.755	2026-03-30 22:21:41.215	9c1e8d12-8bda-4837-9ad6-4a2d4a95b7ba
36086297-f48d-4814-9ea3-b11dd40e5814	ad434e3f-b929-4ff4-a80d-11feac16b136	a2cec753-8d86-42f4-9f45-16aaf894e4b2	D	MXN	8651.42	t	\N	\N	\N	2026-03-30 22:21:37.764	2026-03-30 22:21:41.225	9c1e8d12-8bda-4837-9ad6-4a2d4a95b7ba
6e3a478b-9611-4f81-8121-b0d9221d118b	ad434e3f-b929-4ff4-a80d-11feac16b136	a2cec753-8d86-42f4-9f45-16aaf894e4b2	A	MXN	7632.50	t	\N	\N	\N	2026-03-30 22:21:37.78	2026-03-30 22:21:41.242	a54cbdf6-0d40-4541-898d-397dcb8bd715
80d14776-4384-460b-b8a8-8082a36e64bc	ad434e3f-b929-4ff4-a80d-11feac16b136	a2cec753-8d86-42f4-9f45-16aaf894e4b2	C	MXN	8414.74	t	\N	\N	\N	2026-03-30 22:21:37.793	2026-03-30 22:21:41.261	a54cbdf6-0d40-4541-898d-397dcb8bd715
430dd35c-1c27-4b2c-972f-693e9ac60ecf	ad434e3f-b929-4ff4-a80d-11feac16b136	a2cec753-8d86-42f4-9f45-16aaf894e4b2	D	MXN	8835.44	t	\N	\N	\N	2026-03-30 22:21:37.801	2026-03-30 22:21:41.269	a54cbdf6-0d40-4541-898d-397dcb8bd715
b9221eeb-7895-4d0f-b580-a2f2eea0b43e	ad434e3f-b929-4ff4-a80d-11feac16b136	4bbf5039-4c8e-4d07-80b1-b36bec5151d0	A	MXN	6679.14	t	\N	\N	\N	2026-03-30 22:21:37.819	2026-03-30 22:21:41.286	79417077-0a99-490b-9d06-1f6a7c5cdb44
d90a4116-67a6-499c-a8c5-c6bba18b5c81	ad434e3f-b929-4ff4-a80d-11feac16b136	4bbf5039-4c8e-4d07-80b1-b36bec5151d0	B	MXN	7013.06	t	\N	\N	\N	2026-03-30 22:21:37.826	2026-03-30 22:21:41.294	79417077-0a99-490b-9d06-1f6a7c5cdb44
4b5e3a3d-83e9-47ed-afeb-b6bc842f9481	ad434e3f-b929-4ff4-a80d-11feac16b136	4bbf5039-4c8e-4d07-80b1-b36bec5151d0	C	MXN	7363.68	t	\N	\N	\N	2026-03-30 22:21:37.833	2026-03-30 22:21:41.302	79417077-0a99-490b-9d06-1f6a7c5cdb44
673c58b5-7fbc-4bd3-a59b-0f709811bd4b	ad434e3f-b929-4ff4-a80d-11feac16b136	4bbf5039-4c8e-4d07-80b1-b36bec5151d0	D	MXN	7731.84	t	\N	\N	\N	2026-03-30 22:21:37.841	2026-03-30 22:21:41.309	79417077-0a99-490b-9d06-1f6a7c5cdb44
dacc6cb8-3b2b-4ab9-919b-3456226deabf	ad434e3f-b929-4ff4-a80d-11feac16b136	4bbf5039-4c8e-4d07-80b1-b36bec5151d0	A	MXN	6689.08	t	\N	\N	\N	2026-03-30 22:21:37.857	2026-03-30 22:21:41.325	8e546c86-d6c0-4a50-be99-1bf7bc643ee5
d90a90c9-4897-4d1e-914c-83c8190a310c	ad434e3f-b929-4ff4-a80d-11feac16b136	4bbf5039-4c8e-4d07-80b1-b36bec5151d0	B	MXN	7023.50	t	\N	\N	\N	2026-03-30 22:21:37.866	2026-03-30 22:21:41.335	8e546c86-d6c0-4a50-be99-1bf7bc643ee5
565b03be-147a-4f0f-95c7-e34eb88abe82	ad434e3f-b929-4ff4-a80d-11feac16b136	4bbf5039-4c8e-4d07-80b1-b36bec5151d0	C	MXN	7374.64	t	\N	\N	\N	2026-03-30 22:21:37.873	2026-03-30 22:21:41.344	8e546c86-d6c0-4a50-be99-1bf7bc643ee5
30bd92dd-acb5-470c-9de9-68dee74d409f	ad434e3f-b929-4ff4-a80d-11feac16b136	4bbf5039-4c8e-4d07-80b1-b36bec5151d0	D	MXN	7743.34	t	\N	\N	\N	2026-03-30 22:21:37.881	2026-03-30 22:21:41.352	8e546c86-d6c0-4a50-be99-1bf7bc643ee5
d98b93dd-69e2-4b2e-a026-81884d87d493	ad434e3f-b929-4ff4-a80d-11feac16b136	4bbf5039-4c8e-4d07-80b1-b36bec5151d0	A	MXN	6949.42	t	\N	\N	\N	2026-03-30 22:21:37.897	2026-03-30 22:21:41.368	be5e6238-669c-4446-bab9-c1f54569b240
9ef4773e-306c-45fe-871b-49d8ae9c729a	ad434e3f-b929-4ff4-a80d-11feac16b136	4bbf5039-4c8e-4d07-80b1-b36bec5151d0	B	MXN	7296.84	t	\N	\N	\N	2026-03-30 22:21:37.909	2026-03-30 22:21:41.377	be5e6238-669c-4446-bab9-c1f54569b240
85db9886-9094-4242-97c8-0fa4fa5fa0e0	ad434e3f-b929-4ff4-a80d-11feac16b136	4bbf5039-4c8e-4d07-80b1-b36bec5151d0	C	MXN	7661.64	t	\N	\N	\N	2026-03-30 22:21:37.918	2026-03-30 22:21:41.385	be5e6238-669c-4446-bab9-c1f54569b240
205d0cea-b1cb-48cd-8c39-254993a1ccda	ad434e3f-b929-4ff4-a80d-11feac16b136	4bbf5039-4c8e-4d07-80b1-b36bec5151d0	D	MXN	8044.68	t	\N	\N	\N	2026-03-30 22:21:37.927	2026-03-30 22:21:41.392	be5e6238-669c-4446-bab9-c1f54569b240
60569e1e-5229-42c8-be39-1037001e5ae8	ad434e3f-b929-4ff4-a80d-11feac16b136	4bbf5039-4c8e-4d07-80b1-b36bec5151d0	A	MXN	7108.36	t	\N	\N	\N	2026-03-30 22:21:37.947	2026-03-30 22:21:41.41	a50361eb-17fb-43b1-ace0-6626ab3beed2
4c4dfa3b-1081-49c9-bcd2-32a007d2dd0e	ad434e3f-b929-4ff4-a80d-11feac16b136	4bbf5039-4c8e-4d07-80b1-b36bec5151d0	B	MXN	7463.74	t	\N	\N	\N	2026-03-30 22:21:37.956	2026-03-30 22:21:41.422	a50361eb-17fb-43b1-ace0-6626ab3beed2
56a27b46-538e-46e1-a1cf-18a7daf362a8	ad434e3f-b929-4ff4-a80d-11feac16b136	4bbf5039-4c8e-4d07-80b1-b36bec5151d0	C	MXN	7836.88	t	\N	\N	\N	2026-03-30 22:21:37.967	2026-03-30 22:21:41.431	a50361eb-17fb-43b1-ace0-6626ab3beed2
1795663e-4fc1-43c7-acd2-9085f4d21f7b	ad434e3f-b929-4ff4-a80d-11feac16b136	4bbf5039-4c8e-4d07-80b1-b36bec5151d0	D	MXN	8228.70	t	\N	\N	\N	2026-03-30 22:21:37.974	2026-03-30 22:21:41.441	a50361eb-17fb-43b1-ace0-6626ab3beed2
80aea08e-3a45-46cd-8d0d-1b9d0797bf1a	ad434e3f-b929-4ff4-a80d-11feac16b136	bcd1b43e-9c32-4fb2-a63a-791fd575e91c	A	MXN	4761.56	t	\N	\N	\N	2026-03-30 22:21:37.991	2026-03-30 22:21:41.455	76921fe7-8ee6-447b-b7e1-a06539bf0973
f6032b83-e763-44ac-95cc-4b5b82362c09	ad434e3f-b929-4ff4-a80d-11feac16b136	bcd1b43e-9c32-4fb2-a63a-791fd575e91c	B	MXN	4999.63	t	\N	\N	\N	2026-03-30 22:21:37.999	2026-03-30 22:21:41.464	76921fe7-8ee6-447b-b7e1-a06539bf0973
511f8e69-16ff-4e48-8c74-c4bd0ec1f3d4	ad434e3f-b929-4ff4-a80d-11feac16b136	bcd1b43e-9c32-4fb2-a63a-791fd575e91c	C	MXN	5249.60	t	\N	\N	\N	2026-03-30 22:21:38.008	2026-03-30 22:21:41.471	76921fe7-8ee6-447b-b7e1-a06539bf0973
5bc83b14-9b01-4d94-b4ab-eb432d3e1266	ad434e3f-b929-4ff4-a80d-11feac16b136	bcd1b43e-9c32-4fb2-a63a-791fd575e91c	D	MXN	5512.04	t	\N	\N	\N	2026-03-30 22:21:38.015	2026-03-30 22:21:41.479	76921fe7-8ee6-447b-b7e1-a06539bf0973
edd91f8a-6373-4efe-8147-413607007e07	ad434e3f-b929-4ff4-a80d-11feac16b136	bcd1b43e-9c32-4fb2-a63a-791fd575e91c	A	MXN	5807.66	t	\N	\N	\N	2026-03-30 22:21:38.036	2026-03-30 22:21:41.493	286781b1-a426-4c66-8d01-f81606b36da1
3ca1d129-f162-42dd-9d86-052edf78e2da	ad434e3f-b929-4ff4-a80d-11feac16b136	bcd1b43e-9c32-4fb2-a63a-791fd575e91c	B	MXN	6098.01	t	\N	\N	\N	2026-03-30 22:21:38.045	2026-03-30 22:21:41.502	286781b1-a426-4c66-8d01-f81606b36da1
cc84769b-f6c7-400e-a32f-0a94987b713f	ad434e3f-b929-4ff4-a80d-11feac16b136	bcd1b43e-9c32-4fb2-a63a-791fd575e91c	C	MXN	6402.88	t	\N	\N	\N	2026-03-30 22:21:38.056	2026-03-30 22:21:41.511	286781b1-a426-4c66-8d01-f81606b36da1
03361899-a728-4051-8262-912fac283d0e	ad434e3f-b929-4ff4-a80d-11feac16b136	bcd1b43e-9c32-4fb2-a63a-791fd575e91c	D	MXN	6723.00	t	\N	\N	\N	2026-03-30 22:21:38.065	2026-03-30 22:21:41.519	286781b1-a426-4c66-8d01-f81606b36da1
922e876a-f70c-4546-b6e7-eeb03e594a6b	ad434e3f-b929-4ff4-a80d-11feac16b136	bcd1b43e-9c32-4fb2-a63a-791fd575e91c	A	MXN	5817.60	t	\N	\N	\N	2026-03-30 22:21:38.082	2026-03-30 22:21:41.537	6e58c7a8-0cb7-4791-927a-118eb4567d6a
ee8bf8ea-1dde-489a-a0bd-16f65142dfb4	ad434e3f-b929-4ff4-a80d-11feac16b136	bcd1b43e-9c32-4fb2-a63a-791fd575e91c	B	MXN	6108.45	t	\N	\N	\N	2026-03-30 22:21:38.091	2026-03-30 22:21:41.544	6e58c7a8-0cb7-4791-927a-118eb4567d6a
3c5a608c-a8b3-4829-a168-3bb470c92826	ad434e3f-b929-4ff4-a80d-11feac16b136	bcd1b43e-9c32-4fb2-a63a-791fd575e91c	D	MXN	6734.50	t	\N	\N	\N	2026-03-30 22:21:38.108	2026-03-30 22:21:41.562	6e58c7a8-0cb7-4791-927a-118eb4567d6a
b344f3ca-32f3-46f8-aba9-6a30284ad437	ad434e3f-b929-4ff4-a80d-11feac16b136	bcd1b43e-9c32-4fb2-a63a-791fd575e91c	A	MXN	6077.94	t	\N	\N	\N	2026-03-30 22:21:38.137	2026-03-30 22:21:41.579	43c9ed85-c152-4c04-8518-0342d967fc82
4e41a2b9-cb12-4cbd-9bfb-2d59cba508ca	ad434e3f-b929-4ff4-a80d-11feac16b136	bcd1b43e-9c32-4fb2-a63a-791fd575e91c	B	MXN	6381.79	t	\N	\N	\N	2026-03-30 22:21:38.148	2026-03-30 22:21:41.588	43c9ed85-c152-4c04-8518-0342d967fc82
1252db4d-0218-4312-8e9f-9a60ff1c6eb2	ad434e3f-b929-4ff4-a80d-11feac16b136	bcd1b43e-9c32-4fb2-a63a-791fd575e91c	C	MXN	6700.84	t	\N	\N	\N	2026-03-30 22:21:38.155	2026-03-30 22:21:41.595	43c9ed85-c152-4c04-8518-0342d967fc82
7fd632cc-ccf9-4f10-b729-12592a5e61f1	ad434e3f-b929-4ff4-a80d-11feac16b136	bcd1b43e-9c32-4fb2-a63a-791fd575e91c	D	MXN	7035.84	t	\N	\N	\N	2026-03-30 22:21:38.174	2026-03-30 22:21:41.603	43c9ed85-c152-4c04-8518-0342d967fc82
9b011768-fa1f-4546-9b62-bd267efffaaf	ad434e3f-b929-4ff4-a80d-11feac16b136	bcd1b43e-9c32-4fb2-a63a-791fd575e91c	A	MXN	6236.88	t	\N	\N	\N	2026-03-30 22:21:38.194	2026-03-30 22:21:41.621	16cec520-0a73-4f35-8727-86680849935c
afef9ba7-a921-4bab-988d-b756e36326fa	ad434e3f-b929-4ff4-a80d-11feac16b136	bcd1b43e-9c32-4fb2-a63a-791fd575e91c	B	MXN	6548.69	t	\N	\N	\N	2026-03-30 22:21:38.208	2026-03-30 22:21:41.63	16cec520-0a73-4f35-8727-86680849935c
0eaab186-f0ea-4544-9974-713f8f446750	ad434e3f-b929-4ff4-a80d-11feac16b136	bcd1b43e-9c32-4fb2-a63a-791fd575e91c	D	MXN	7219.86	t	\N	\N	\N	2026-03-30 22:21:38.235	2026-03-30 22:21:41.648	16cec520-0a73-4f35-8727-86680849935c
2c26f221-a7e9-44a3-88ef-9b74379b4679	ad434e3f-b929-4ff4-a80d-11feac16b136	008b256d-38f7-4781-83cf-04b1f624051e	A	MXN	6120.00	t	\N	\N	\N	2026-03-30 22:21:38.261	2026-03-30 22:21:41.669	d528b7cb-cb8a-4ec2-adf4-8cd1c287bc5a
3f93abf9-244b-42b9-9be4-0b8d49e54825	ad434e3f-b929-4ff4-a80d-11feac16b136	008b256d-38f7-4781-83cf-04b1f624051e	B	MXN	6425.97	t	\N	\N	\N	2026-03-30 22:21:38.27	2026-03-30 22:21:41.678	d528b7cb-cb8a-4ec2-adf4-8cd1c287bc5a
60108f54-b4c9-442b-9c96-df0a59b78c2c	ad434e3f-b929-4ff4-a80d-11feac16b136	008b256d-38f7-4781-83cf-04b1f624051e	C	MXN	6747.24	t	\N	\N	\N	2026-03-30 22:21:38.283	2026-03-30 22:21:41.693	d528b7cb-cb8a-4ec2-adf4-8cd1c287bc5a
b4ee8ee1-bbf7-4bea-ab2e-c3efcf242934	ad434e3f-b929-4ff4-a80d-11feac16b136	008b256d-38f7-4781-83cf-04b1f624051e	D	MXN	7084.58	t	\N	\N	\N	2026-03-30 22:21:38.291	2026-03-30 22:21:41.706	d528b7cb-cb8a-4ec2-adf4-8cd1c287bc5a
22756984-19d2-4e9f-9119-6573b8e103e6	ad434e3f-b929-4ff4-a80d-11feac16b136	008b256d-38f7-4781-83cf-04b1f624051e	A	MXN	5073.90	t	\N	\N	\N	2026-03-30 22:21:38.309	2026-03-30 22:21:41.724	bc73c5fb-04f1-4be4-ab2b-2fe58d9e4174
489a5a32-03f6-4cb5-af07-1d441a1c5205	ad434e3f-b929-4ff4-a80d-11feac16b136	008b256d-38f7-4781-83cf-04b1f624051e	B	MXN	5327.59	t	\N	\N	\N	2026-03-30 22:21:38.316	2026-03-30 22:21:41.734	bc73c5fb-04f1-4be4-ab2b-2fe58d9e4174
8e839fb0-62a3-4b33-8892-994f91b49595	ad434e3f-b929-4ff4-a80d-11feac16b136	008b256d-38f7-4781-83cf-04b1f624051e	C	MXN	5593.96	t	\N	\N	\N	2026-03-30 22:21:38.323	2026-03-30 22:21:41.746	bc73c5fb-04f1-4be4-ab2b-2fe58d9e4174
2ba50d35-a5d4-4ca2-8e39-5653b49fde0d	ad434e3f-b929-4ff4-a80d-11feac16b136	008b256d-38f7-4781-83cf-04b1f624051e	D	MXN	5873.62	t	\N	\N	\N	2026-03-30 22:21:38.331	2026-03-30 22:21:41.755	bc73c5fb-04f1-4be4-ab2b-2fe58d9e4174
a366af14-0cdf-408a-8c52-d7bb7f214752	ad434e3f-b929-4ff4-a80d-11feac16b136	008b256d-38f7-4781-83cf-04b1f624051e	A	MXN	6129.94	t	\N	\N	\N	2026-03-30 22:21:38.345	2026-03-30 22:21:41.772	89b87c76-288b-4f9f-ba97-a713c003efb2
9ea19a19-40b3-41c3-a8ab-a2397fc133fd	ad434e3f-b929-4ff4-a80d-11feac16b136	008b256d-38f7-4781-83cf-04b1f624051e	B	MXN	6436.41	t	\N	\N	\N	2026-03-30 22:21:38.354	2026-03-30 22:21:41.785	89b87c76-288b-4f9f-ba97-a713c003efb2
8a114c2a-dfb0-434b-a44b-5e1c1e65c50c	ad434e3f-b929-4ff4-a80d-11feac16b136	008b256d-38f7-4781-83cf-04b1f624051e	C	MXN	6758.20	t	\N	\N	\N	2026-03-30 22:21:38.363	2026-03-30 22:21:41.795	89b87c76-288b-4f9f-ba97-a713c003efb2
bfa1b264-1d31-4db9-88f5-41b58f086df9	ad434e3f-b929-4ff4-a80d-11feac16b136	008b256d-38f7-4781-83cf-04b1f624051e	D	MXN	7096.08	t	\N	\N	\N	2026-03-30 22:21:38.371	2026-03-30 22:21:41.805	89b87c76-288b-4f9f-ba97-a713c003efb2
cd188291-4f7d-42e6-b47e-1623d952d3b7	ad434e3f-b929-4ff4-a80d-11feac16b136	008b256d-38f7-4781-83cf-04b1f624051e	A	MXN	6390.28	t	\N	\N	\N	2026-03-30 22:21:38.395	2026-03-30 22:21:41.828	3a8531fa-2411-48ab-8af5-e9c047116236
ba99e6f5-245f-4295-a565-ce586f34e8a1	ad434e3f-b929-4ff4-a80d-11feac16b136	008b256d-38f7-4781-83cf-04b1f624051e	B	MXN	6709.75	t	\N	\N	\N	2026-03-30 22:21:38.404	2026-03-30 22:21:41.84	3a8531fa-2411-48ab-8af5-e9c047116236
48d68250-7dcd-4d0e-b4cc-c632e6189201	ad434e3f-b929-4ff4-a80d-11feac16b136	008b256d-38f7-4781-83cf-04b1f624051e	C	MXN	7045.20	t	\N	\N	\N	2026-03-30 22:21:38.412	2026-03-30 22:21:41.85	3a8531fa-2411-48ab-8af5-e9c047116236
598cfe8f-df19-492d-ba73-d3cba8893902	ad434e3f-b929-4ff4-a80d-11feac16b136	008b256d-38f7-4781-83cf-04b1f624051e	D	MXN	7397.42	t	\N	\N	\N	2026-03-30 22:21:38.419	2026-03-30 22:21:41.866	3a8531fa-2411-48ab-8af5-e9c047116236
c1830ff5-5a65-4788-a845-6dcf4f10babb	ad434e3f-b929-4ff4-a80d-11feac16b136	008b256d-38f7-4781-83cf-04b1f624051e	A	MXN	6549.22	t	\N	\N	\N	2026-03-30 22:21:38.447	2026-03-30 22:21:41.89	8614fd78-de35-4fca-86fb-eb7060d49587
d42657d5-d808-490c-81d4-5e364b5ad460	ad434e3f-b929-4ff4-a80d-11feac16b136	008b256d-38f7-4781-83cf-04b1f624051e	B	MXN	6876.65	t	\N	\N	\N	2026-03-30 22:21:38.454	2026-03-30 22:21:41.898	8614fd78-de35-4fca-86fb-eb7060d49587
e7565fa3-9256-47d0-9ef8-b36e4db646d6	ad434e3f-b929-4ff4-a80d-11feac16b136	008b256d-38f7-4781-83cf-04b1f624051e	C	MXN	7220.44	t	\N	\N	\N	2026-03-30 22:21:38.462	2026-03-30 22:21:41.905	8614fd78-de35-4fca-86fb-eb7060d49587
207d88bd-f3fc-4d51-a65c-ced81dd7143a	ad434e3f-b929-4ff4-a80d-11feac16b136	008b256d-38f7-4781-83cf-04b1f624051e	D	MXN	7581.44	t	\N	\N	\N	2026-03-30 22:21:38.471	2026-03-30 22:21:41.915	8614fd78-de35-4fca-86fb-eb7060d49587
a8857a75-d76e-42d9-bb68-e73dccae62fd	ad434e3f-b929-4ff4-a80d-11feac16b136	9cca5e76-de22-447c-a1bd-e5d16142d93e	A	MXN	4811.82	t	\N	\N	\N	2026-03-30 22:21:38.489	2026-03-30 22:21:41.938	c0b7dc51-d9c3-4ea8-8842-855598afe12d
5439cde5-ed64-4d38-98ba-7621d5640594	ad434e3f-b929-4ff4-a80d-11feac16b136	9cca5e76-de22-447c-a1bd-e5d16142d93e	B	MXN	5052.40	t	\N	\N	\N	2026-03-30 22:21:38.497	2026-03-30 22:21:41.964	c0b7dc51-d9c3-4ea8-8842-855598afe12d
e53082c1-0946-414e-88c4-c1b0817062ed	ad434e3f-b929-4ff4-a80d-11feac16b136	9cca5e76-de22-447c-a1bd-e5d16142d93e	C	MXN	5305.01	t	\N	\N	\N	2026-03-30 22:21:38.504	2026-03-30 22:21:41.977	c0b7dc51-d9c3-4ea8-8842-855598afe12d
bb2ae818-1872-46ff-8208-a76b6f5ade11	ad434e3f-b929-4ff4-a80d-11feac16b136	9cca5e76-de22-447c-a1bd-e5d16142d93e	D	MXN	5570.22	t	\N	\N	\N	2026-03-30 22:21:38.513	2026-03-30 22:21:41.989	c0b7dc51-d9c3-4ea8-8842-855598afe12d
e119e73a-8212-4b2a-86c8-2dbc13e2e00f	ad434e3f-b929-4ff4-a80d-11feac16b136	9cca5e76-de22-447c-a1bd-e5d16142d93e	A	MXN	5857.92	t	\N	\N	\N	2026-03-30 22:21:38.529	2026-03-30 22:21:42.022	c1ab5a74-ce67-4985-9c90-b75b3924854f
68c9ea43-c6bb-41c7-b4dd-0de936659475	ad434e3f-b929-4ff4-a80d-11feac16b136	9cca5e76-de22-447c-a1bd-e5d16142d93e	B	MXN	6150.78	t	\N	\N	\N	2026-03-30 22:21:38.537	2026-03-30 22:21:42.032	c1ab5a74-ce67-4985-9c90-b75b3924854f
50025531-eb3b-45c5-8ce8-f545fb3feb3d	ad434e3f-b929-4ff4-a80d-11feac16b136	9cca5e76-de22-447c-a1bd-e5d16142d93e	C	MXN	6458.29	t	\N	\N	\N	2026-03-30 22:21:38.543	2026-03-30 22:21:42.042	c1ab5a74-ce67-4985-9c90-b75b3924854f
02c094ac-6234-476b-8398-9286fb9ec6ae	ad434e3f-b929-4ff4-a80d-11feac16b136	9cca5e76-de22-447c-a1bd-e5d16142d93e	A	MXN	5867.86	t	\N	\N	\N	2026-03-30 22:21:38.567	2026-03-30 22:21:42.07	74a002cd-c785-4d33-8014-057415583672
3dee42a6-ade1-4d4a-ac71-573a2f810913	ad434e3f-b929-4ff4-a80d-11feac16b136	9cca5e76-de22-447c-a1bd-e5d16142d93e	B	MXN	6161.22	t	\N	\N	\N	2026-03-30 22:21:38.574	2026-03-30 22:21:42.08	74a002cd-c785-4d33-8014-057415583672
679aa262-168c-4027-a6c2-b6ce69fb8b1e	ad434e3f-b929-4ff4-a80d-11feac16b136	9cca5e76-de22-447c-a1bd-e5d16142d93e	C	MXN	6469.25	t	\N	\N	\N	2026-03-30 22:21:38.582	2026-03-30 22:21:42.089	74a002cd-c785-4d33-8014-057415583672
3472215a-6dc6-4173-be41-091b8dc1a952	ad434e3f-b929-4ff4-a80d-11feac16b136	9cca5e76-de22-447c-a1bd-e5d16142d93e	D	MXN	6792.68	t	\N	\N	\N	2026-03-30 22:21:38.589	2026-03-30 22:21:42.102	74a002cd-c785-4d33-8014-057415583672
3e9ef973-d777-4777-b245-238d4cf9a8e8	ad434e3f-b929-4ff4-a80d-11feac16b136	9cca5e76-de22-447c-a1bd-e5d16142d93e	A	MXN	6128.20	t	\N	\N	\N	2026-03-30 22:21:38.604	2026-03-30 22:21:42.122	e5e317bf-c840-4729-b412-5ec62682673a
46768fed-dffc-4b5e-ad16-bead9d58cd3b	ad434e3f-b929-4ff4-a80d-11feac16b136	9cca5e76-de22-447c-a1bd-e5d16142d93e	B	MXN	6434.56	t	\N	\N	\N	2026-03-30 22:21:38.612	2026-03-30 22:21:42.136	e5e317bf-c840-4729-b412-5ec62682673a
69e2a57d-a487-4d0a-816b-fb646dcbd148	ad434e3f-b929-4ff4-a80d-11feac16b136	9cca5e76-de22-447c-a1bd-e5d16142d93e	C	MXN	6756.25	t	\N	\N	\N	2026-03-30 22:21:38.619	2026-03-30 22:21:42.146	e5e317bf-c840-4729-b412-5ec62682673a
9745791a-fd0e-4873-a1e7-60575693d2cc	ad434e3f-b929-4ff4-a80d-11feac16b136	9cca5e76-de22-447c-a1bd-e5d16142d93e	A	MXN	6287.14	t	\N	\N	\N	2026-03-30 22:21:38.646	2026-03-30 22:21:42.255	8161596a-5ed3-47ef-b853-576feacb890f
84f916a6-6d37-4116-80e5-c89c2d6024f7	ad434e3f-b929-4ff4-a80d-11feac16b136	9cca5e76-de22-447c-a1bd-e5d16142d93e	B	MXN	6601.46	t	\N	\N	\N	2026-03-30 22:21:38.654	2026-03-30 22:21:42.272	8161596a-5ed3-47ef-b853-576feacb890f
77083ed4-077b-4822-857b-e0c49a1ad5ef	ad434e3f-b929-4ff4-a80d-11feac16b136	9cca5e76-de22-447c-a1bd-e5d16142d93e	C	MXN	6931.49	t	\N	\N	\N	2026-03-30 22:21:38.663	2026-03-30 22:21:42.283	8161596a-5ed3-47ef-b853-576feacb890f
275d7b0a-3073-4bb2-8268-6d9314eaaef5	ad434e3f-b929-4ff4-a80d-11feac16b136	9cca5e76-de22-447c-a1bd-e5d16142d93e	D	MXN	7278.04	t	\N	\N	\N	2026-03-30 22:21:38.67	2026-03-30 22:21:42.291	8161596a-5ed3-47ef-b853-576feacb890f
d982b369-b6b2-4128-8148-c8344a561349	ad434e3f-b929-4ff4-a80d-11feac16b136	bd2b7acf-9367-419f-a8b1-7e4053fd4ff9	A	MXN	4856.54	t	\N	\N	\N	2026-03-30 22:21:38.69	2026-03-30 22:21:42.311	d2ad100f-2a4a-4a57-a84f-61ea058e972b
1a1db5a3-439c-49c4-89dd-02af9e825a54	ad434e3f-b929-4ff4-a80d-11feac16b136	bd2b7acf-9367-419f-a8b1-7e4053fd4ff9	B	MXN	5099.36	t	\N	\N	\N	2026-03-30 22:21:38.698	2026-03-30 22:21:42.319	d2ad100f-2a4a-4a57-a84f-61ea058e972b
c3c3cd4f-b79f-4569-b953-4958a8e0f414	ad434e3f-b929-4ff4-a80d-11feac16b136	bd2b7acf-9367-419f-a8b1-7e4053fd4ff9	C	MXN	5354.32	t	\N	\N	\N	2026-03-30 22:21:38.707	2026-03-30 22:21:42.325	d2ad100f-2a4a-4a57-a84f-61ea058e972b
92721c26-51b2-4f01-8e8d-0008bb29cf74	ad434e3f-b929-4ff4-a80d-11feac16b136	bd2b7acf-9367-419f-a8b1-7e4053fd4ff9	D	MXN	5622.00	t	\N	\N	\N	2026-03-30 22:21:38.714	2026-03-30 22:21:42.34	d2ad100f-2a4a-4a57-a84f-61ea058e972b
5758c156-8681-4af5-b880-065631928c53	ad434e3f-b929-4ff4-a80d-11feac16b136	bd2b7acf-9367-419f-a8b1-7e4053fd4ff9	A	MXN	5902.64	t	\N	\N	\N	2026-03-30 22:21:38.738	2026-03-30 22:21:42.359	7239d3c0-c937-43c1-b35a-1a817c5aae98
ef146d35-c963-4f8a-b1d1-d5db399f7b56	ad434e3f-b929-4ff4-a80d-11feac16b136	bd2b7acf-9367-419f-a8b1-7e4053fd4ff9	B	MXN	6197.74	t	\N	\N	\N	2026-03-30 22:21:38.752	2026-03-30 22:21:42.372	7239d3c0-c937-43c1-b35a-1a817c5aae98
ecce9189-d106-4892-b409-a46767347499	ad434e3f-b929-4ff4-a80d-11feac16b136	bd2b7acf-9367-419f-a8b1-7e4053fd4ff9	C	MXN	6507.60	t	\N	\N	\N	2026-03-30 22:21:38.769	2026-03-30 22:21:42.38	7239d3c0-c937-43c1-b35a-1a817c5aae98
ff4173ea-f8f4-4e25-8d1c-a6410e26e4af	ad434e3f-b929-4ff4-a80d-11feac16b136	bd2b7acf-9367-419f-a8b1-7e4053fd4ff9	D	MXN	6832.96	t	\N	\N	\N	2026-03-30 22:21:38.786	2026-03-30 22:21:42.391	7239d3c0-c937-43c1-b35a-1a817c5aae98
3999e014-8260-4bef-a60d-446429115cb9	ad434e3f-b929-4ff4-a80d-11feac16b136	bd2b7acf-9367-419f-a8b1-7e4053fd4ff9	A	MXN	5912.58	t	\N	\N	\N	2026-03-30 22:21:38.804	2026-03-30 22:21:42.416	a38b2900-aaf5-4cea-b595-905a44b0596b
3d9441c2-81e5-4494-b99e-391e3dee2914	ad434e3f-b929-4ff4-a80d-11feac16b136	bd2b7acf-9367-419f-a8b1-7e4053fd4ff9	B	MXN	6208.18	t	\N	\N	\N	2026-03-30 22:21:38.818	2026-03-30 22:21:42.428	a38b2900-aaf5-4cea-b595-905a44b0596b
4e07163f-74ab-4db2-9f9e-79084bda8f74	ad434e3f-b929-4ff4-a80d-11feac16b136	bd2b7acf-9367-419f-a8b1-7e4053fd4ff9	C	MXN	6518.56	t	\N	\N	\N	2026-03-30 22:21:38.834	2026-03-30 22:21:42.437	a38b2900-aaf5-4cea-b595-905a44b0596b
cfec82c7-76ae-4b96-9f3c-9e097c63d996	ad434e3f-b929-4ff4-a80d-11feac16b136	bd2b7acf-9367-419f-a8b1-7e4053fd4ff9	D	MXN	6844.46	t	\N	\N	\N	2026-03-30 22:21:38.866	2026-03-30 22:21:42.444	a38b2900-aaf5-4cea-b595-905a44b0596b
eb566b0e-f4a2-46a8-a136-f5e6c7dfb052	ad434e3f-b929-4ff4-a80d-11feac16b136	bd2b7acf-9367-419f-a8b1-7e4053fd4ff9	A	MXN	6172.92	t	\N	\N	\N	2026-03-30 22:21:38.882	2026-03-30 22:21:42.461	fd2b6c36-88c3-488d-bbbb-24a4267a88d1
af4886d1-8541-4d2f-85b0-81e5489a1727	ad434e3f-b929-4ff4-a80d-11feac16b136	bd2b7acf-9367-419f-a8b1-7e4053fd4ff9	B	MXN	6481.52	t	\N	\N	\N	2026-03-30 22:21:38.891	2026-03-30 22:21:42.469	fd2b6c36-88c3-488d-bbbb-24a4267a88d1
aa423e91-0b88-45c7-bdc2-3d87cf4784ae	ad434e3f-b929-4ff4-a80d-11feac16b136	bd2b7acf-9367-419f-a8b1-7e4053fd4ff9	C	MXN	6805.56	t	\N	\N	\N	2026-03-30 22:21:38.904	2026-03-30 22:21:42.478	fd2b6c36-88c3-488d-bbbb-24a4267a88d1
1489f851-3764-4415-bb34-59111e1b21a0	ad434e3f-b929-4ff4-a80d-11feac16b136	bd2b7acf-9367-419f-a8b1-7e4053fd4ff9	D	MXN	7145.80	t	\N	\N	\N	2026-03-30 22:21:38.912	2026-03-30 22:21:42.491	fd2b6c36-88c3-488d-bbbb-24a4267a88d1
5d92c0a3-f5ce-410e-a250-e148e1959beb	ad434e3f-b929-4ff4-a80d-11feac16b136	bd2b7acf-9367-419f-a8b1-7e4053fd4ff9	A	MXN	6331.86	t	\N	\N	\N	2026-03-30 22:21:38.928	2026-03-30 22:21:42.514	96ef0c69-815b-420c-9ca9-8eded8d31c2c
42e0a6a0-894c-494a-8090-a4ee3b45057b	ad434e3f-b929-4ff4-a80d-11feac16b136	bd2b7acf-9367-419f-a8b1-7e4053fd4ff9	B	MXN	6648.42	t	\N	\N	\N	2026-03-30 22:21:38.935	2026-03-30 22:21:42.524	96ef0c69-815b-420c-9ca9-8eded8d31c2c
6979791a-a9b4-447d-93cc-fb44ed0f7566	ad434e3f-b929-4ff4-a80d-11feac16b136	bd2b7acf-9367-419f-a8b1-7e4053fd4ff9	C	MXN	6980.80	t	\N	\N	\N	2026-03-30 22:21:38.949	2026-03-30 22:21:42.541	96ef0c69-815b-420c-9ca9-8eded8d31c2c
549a134d-c836-4543-b69b-f12e90999fc2	ad434e3f-b929-4ff4-a80d-11feac16b136	bd2b7acf-9367-419f-a8b1-7e4053fd4ff9	D	MXN	7329.82	t	\N	\N	\N	2026-03-30 22:21:38.963	2026-03-30 22:21:42.548	96ef0c69-815b-420c-9ca9-8eded8d31c2c
dd1e776c-3bc3-4522-a57f-fefa0125b668	ad434e3f-b929-4ff4-a80d-11feac16b136	86e0de54-1f22-4556-9437-1b640d3d08cf	A	MXN	5082.32	t	\N	\N	\N	2026-03-30 22:21:38.989	2026-03-30 22:21:42.567	78242f94-87f4-4c34-8577-1e2518fe71f3
55bb30bb-d727-4875-88a7-07cdbec6d81e	ad434e3f-b929-4ff4-a80d-11feac16b136	86e0de54-1f22-4556-9437-1b640d3d08cf	B	MXN	5336.43	t	\N	\N	\N	2026-03-30 22:21:39.002	2026-03-30 22:21:42.574	78242f94-87f4-4c34-8577-1e2518fe71f3
0d177988-615f-4015-9493-3dc4d94c4f60	ad434e3f-b929-4ff4-a80d-11feac16b136	86e0de54-1f22-4556-9437-1b640d3d08cf	C	MXN	5603.24	t	\N	\N	\N	2026-03-30 22:21:39.015	2026-03-30 22:21:42.583	78242f94-87f4-4c34-8577-1e2518fe71f3
dffbb23c-6e39-4ed0-b93c-62c02ee2110f	ad434e3f-b929-4ff4-a80d-11feac16b136	86e0de54-1f22-4556-9437-1b640d3d08cf	D	MXN	5883.36	t	\N	\N	\N	2026-03-30 22:21:39.028	2026-03-30 22:21:42.593	78242f94-87f4-4c34-8577-1e2518fe71f3
c36f01f5-7285-4152-a4fa-0ddb8a4997bf	ad434e3f-b929-4ff4-a80d-11feac16b136	86e0de54-1f22-4556-9437-1b640d3d08cf	A	MXN	6128.42	t	\N	\N	\N	2026-03-30 22:21:39.049	2026-03-30 22:21:42.617	a121e5c8-f3b8-4263-b3bd-c71214e26515
507f7512-9dd4-4a86-ba33-05cdf7990b95	ad434e3f-b929-4ff4-a80d-11feac16b136	86e0de54-1f22-4556-9437-1b640d3d08cf	B	MXN	6434.81	t	\N	\N	\N	2026-03-30 22:21:39.056	2026-03-30 22:21:42.631	a121e5c8-f3b8-4263-b3bd-c71214e26515
75046021-041f-4748-a487-d747ab9f2b59	ad434e3f-b929-4ff4-a80d-11feac16b136	86e0de54-1f22-4556-9437-1b640d3d08cf	C	MXN	6756.52	t	\N	\N	\N	2026-03-30 22:21:39.062	2026-03-30 22:21:42.64	a121e5c8-f3b8-4263-b3bd-c71214e26515
96d5c5ef-f534-4043-9d41-fd0d9c167bdb	ad434e3f-b929-4ff4-a80d-11feac16b136	86e0de54-1f22-4556-9437-1b640d3d08cf	D	MXN	7094.32	t	\N	\N	\N	2026-03-30 22:21:39.07	2026-03-30 22:21:42.657	a121e5c8-f3b8-4263-b3bd-c71214e26515
6f96b3e2-72d8-400e-9650-75c587f55726	ad434e3f-b929-4ff4-a80d-11feac16b136	86e0de54-1f22-4556-9437-1b640d3d08cf	A	MXN	6138.36	t	\N	\N	\N	2026-03-30 22:21:39.091	2026-03-30 22:21:42.694	a016707d-3639-4517-afaf-afd5c803e25b
5fde805c-6bc5-47a4-bfc7-660a75b49e42	ad434e3f-b929-4ff4-a80d-11feac16b136	86e0de54-1f22-4556-9437-1b640d3d08cf	B	MXN	6445.25	t	\N	\N	\N	2026-03-30 22:21:39.099	2026-03-30 22:21:42.717	a016707d-3639-4517-afaf-afd5c803e25b
3c3d79e1-00f9-44f5-802a-3e54683d9457	ad434e3f-b929-4ff4-a80d-11feac16b136	86e0de54-1f22-4556-9437-1b640d3d08cf	C	MXN	6767.48	t	\N	\N	\N	2026-03-30 22:21:39.105	2026-03-30 22:21:42.734	a016707d-3639-4517-afaf-afd5c803e25b
cf3ee035-990a-4357-8d44-4049141ad53e	ad434e3f-b929-4ff4-a80d-11feac16b136	86e0de54-1f22-4556-9437-1b640d3d08cf	D	MXN	7105.82	t	\N	\N	\N	2026-03-30 22:21:39.115	2026-03-30 22:21:42.749	a016707d-3639-4517-afaf-afd5c803e25b
8d3596a6-cce3-451a-939e-ab69909e98ad	ad434e3f-b929-4ff4-a80d-11feac16b136	86e0de54-1f22-4556-9437-1b640d3d08cf	B	MXN	6718.59	t	\N	\N	\N	2026-03-30 22:21:39.141	2026-03-30 22:21:42.792	01ee0c67-a12f-44a6-ac95-ccc2dfa7537d
dc215f0d-af95-4679-939c-e38ca7e3c3f7	ad434e3f-b929-4ff4-a80d-11feac16b136	86e0de54-1f22-4556-9437-1b640d3d08cf	C	MXN	7054.48	t	\N	\N	\N	2026-03-30 22:21:39.15	2026-03-30 22:21:42.806	01ee0c67-a12f-44a6-ac95-ccc2dfa7537d
017b88b2-9f10-4741-9f5f-306e106f0245	ad434e3f-b929-4ff4-a80d-11feac16b136	86e0de54-1f22-4556-9437-1b640d3d08cf	D	MXN	7407.16	t	\N	\N	\N	2026-03-30 22:21:39.157	2026-03-30 22:21:42.814	01ee0c67-a12f-44a6-ac95-ccc2dfa7537d
ea72f9aa-e7c9-4fdb-9c01-4de306e5f6f9	ad434e3f-b929-4ff4-a80d-11feac16b136	a0244668-d009-42cf-a2e3-16e02a19e6aa	A	MXN	5030.26	t	\N	\N	\N	2026-03-30 22:21:39.177	2026-03-30 22:21:42.831	25fa5bf4-e914-430b-ae4a-4e8402c3bddf
df11ebe3-a270-4277-9651-6e9a923328df	ad434e3f-b929-4ff4-a80d-11feac16b136	a0244668-d009-42cf-a2e3-16e02a19e6aa	B	MXN	5281.71	t	\N	\N	\N	2026-03-30 22:21:39.185	2026-03-30 22:21:42.838	25fa5bf4-e914-430b-ae4a-4e8402c3bddf
3ee67b3e-3d5f-4dd0-bc1c-43898e78bb32	ad434e3f-b929-4ff4-a80d-11feac16b136	a0244668-d009-42cf-a2e3-16e02a19e6aa	C	MXN	5545.76	t	\N	\N	\N	2026-03-30 22:21:39.193	2026-03-30 22:21:42.849	25fa5bf4-e914-430b-ae4a-4e8402c3bddf
70b2a175-9eaa-40c5-b864-7f9652b24f8d	ad434e3f-b929-4ff4-a80d-11feac16b136	a0244668-d009-42cf-a2e3-16e02a19e6aa	D	MXN	5822.98	t	\N	\N	\N	2026-03-30 22:21:39.199	2026-03-30 22:21:42.862	25fa5bf4-e914-430b-ae4a-4e8402c3bddf
4e3a7f5c-782d-4564-8d13-bce0a2aa5d23	ad434e3f-b929-4ff4-a80d-11feac16b136	c369fbbb-e024-4b2c-915f-8034bc0c3d97	A	MXN	5256.00	t	\N	\N	\N	2026-03-30 22:21:39.217	2026-03-30 22:21:42.878	bd1814c9-46a6-44cd-ab92-81bcc6f78ee3
8dc4ed6a-f7c1-44c8-8978-3293d155ad29	ad434e3f-b929-4ff4-a80d-11feac16b136	c369fbbb-e024-4b2c-915f-8034bc0c3d97	B	MXN	5518.74	t	\N	\N	\N	2026-03-30 22:21:39.229	2026-03-30 22:21:42.887	bd1814c9-46a6-44cd-ab92-81bcc6f78ee3
d45698da-186a-4f1e-8947-756341b4c3b3	ad434e3f-b929-4ff4-a80d-11feac16b136	c369fbbb-e024-4b2c-915f-8034bc0c3d97	C	MXN	5794.64	t	\N	\N	\N	2026-03-30 22:21:39.235	2026-03-30 22:21:42.895	bd1814c9-46a6-44cd-ab92-81bcc6f78ee3
9a2c75ee-9eb6-4eb6-a34b-d52f2944f168	ad434e3f-b929-4ff4-a80d-11feac16b136	c369fbbb-e024-4b2c-915f-8034bc0c3d97	D	MXN	6084.30	t	\N	\N	\N	2026-03-30 22:21:39.245	2026-03-30 22:21:42.903	bd1814c9-46a6-44cd-ab92-81bcc6f78ee3
d4f56537-e83b-45af-b09a-81108a15f86d	ad434e3f-b929-4ff4-a80d-11feac16b136	5c0d7eb9-23c1-4bed-a617-859d68cc53a1	A	MXN	5071.95	t	\N	\N	\N	2026-03-30 22:21:39.261	2026-03-30 22:21:42.921	a5cd3768-7eb5-4d3e-adbb-c75f56a0bc4e
21afd74c-7dfb-4297-b5aa-4291a8655e95	ad434e3f-b929-4ff4-a80d-11feac16b136	5c0d7eb9-23c1-4bed-a617-859d68cc53a1	B	MXN	5325.49	t	\N	\N	\N	2026-03-30 22:21:39.268	2026-03-30 22:21:42.933	a5cd3768-7eb5-4d3e-adbb-c75f56a0bc4e
f7ffc58a-5302-477a-8e7f-ba39c6f029b5	ad434e3f-b929-4ff4-a80d-11feac16b136	5c0d7eb9-23c1-4bed-a617-859d68cc53a1	C	MXN	5591.73	t	\N	\N	\N	2026-03-30 22:21:39.276	2026-03-30 22:21:42.943	a5cd3768-7eb5-4d3e-adbb-c75f56a0bc4e
88b19318-a6ce-4da8-9b76-aa8a73458508	ad434e3f-b929-4ff4-a80d-11feac16b136	5c0d7eb9-23c1-4bed-a617-859d68cc53a1	D	MXN	5871.25	t	\N	\N	\N	2026-03-30 22:21:39.283	2026-03-30 22:21:42.954	a5cd3768-7eb5-4d3e-adbb-c75f56a0bc4e
70c20f92-32f7-46a1-a9a1-b82fe49533a9	ad434e3f-b929-4ff4-a80d-11feac16b136	7a074413-4859-4c63-b201-f5202c6b320d	A	MXN	5093.91	t	\N	\N	\N	2026-03-30 22:21:39.298	2026-03-30 22:21:42.973	7df38ea7-c5cd-45f3-979b-6b84c24ff500
af7ac206-f58f-4ea8-b002-9cf7aca7ddb1	ad434e3f-b929-4ff4-a80d-11feac16b136	7a074413-4859-4c63-b201-f5202c6b320d	B	MXN	5348.55	t	\N	\N	\N	2026-03-30 22:21:39.305	2026-03-30 22:21:42.982	7df38ea7-c5cd-45f3-979b-6b84c24ff500
3452a7fc-67c0-4780-95ec-6b9a5202b76c	ad434e3f-b929-4ff4-a80d-11feac16b136	7a074413-4859-4c63-b201-f5202c6b320d	C	MXN	5615.94	t	\N	\N	\N	2026-03-30 22:21:39.314	2026-03-30 22:21:42.992	7df38ea7-c5cd-45f3-979b-6b84c24ff500
e2afba37-92e6-4b55-b934-8ed15086329d	ad434e3f-b929-4ff4-a80d-11feac16b136	7a074413-4859-4c63-b201-f5202c6b320d	D	MXN	5896.67	t	\N	\N	\N	2026-03-30 22:21:39.321	2026-03-30 22:21:43.003	7df38ea7-c5cd-45f3-979b-6b84c24ff500
6a297084-43bb-4697-84bf-4f0647c095e1	ad434e3f-b929-4ff4-a80d-11feac16b136	1a0d7974-ee17-486d-97b1-14297369167f	A	MXN	5394.44	t	\N	\N	\N	2026-03-30 22:21:39.339	2026-03-30 22:21:43.021	444ee00f-17b7-4374-8914-10d37555f4d2
7e50f9d2-c2cc-45cb-9e7c-306203315ae1	ad434e3f-b929-4ff4-a80d-11feac16b136	1a0d7974-ee17-486d-97b1-14297369167f	B	MXN	5664.10	t	\N	\N	\N	2026-03-30 22:21:39.347	2026-03-30 22:21:43.029	444ee00f-17b7-4374-8914-10d37555f4d2
6f7e4f45-6f9b-4ab2-a9fd-87425da2d365	ad434e3f-b929-4ff4-a80d-11feac16b136	1a0d7974-ee17-486d-97b1-14297369167f	C	MXN	5947.27	t	\N	\N	\N	2026-03-30 22:21:39.356	2026-03-30 22:21:43.038	444ee00f-17b7-4374-8914-10d37555f4d2
80e46fc4-fcd4-4879-8866-26071cc9dc0e	ad434e3f-b929-4ff4-a80d-11feac16b136	1a0d7974-ee17-486d-97b1-14297369167f	D	MXN	6244.56	t	\N	\N	\N	2026-03-30 22:21:39.364	2026-03-30 22:21:43.047	444ee00f-17b7-4374-8914-10d37555f4d2
531bd7d8-682d-4dab-b711-72ecb3119414	ad434e3f-b929-4ff4-a80d-11feac16b136	82324aa9-e3d8-4b37-aa7e-e5dc2141a42d	A	MXN	5132.37	t	\N	\N	\N	2026-03-30 22:21:39.38	2026-03-30 22:21:43.066	82d5a9aa-8006-48f4-afc3-e02684f986a3
31b30a38-c7f5-464b-8db7-b2aa4360589b	ad434e3f-b929-4ff4-a80d-11feac16b136	82324aa9-e3d8-4b37-aa7e-e5dc2141a42d	B	MXN	5388.93	t	\N	\N	\N	2026-03-30 22:21:39.389	2026-03-30 22:21:43.077	82d5a9aa-8006-48f4-afc3-e02684f986a3
5499c7a2-dca1-43d6-9344-aa7d7eafeeb3	ad434e3f-b929-4ff4-a80d-11feac16b136	82324aa9-e3d8-4b37-aa7e-e5dc2141a42d	C	MXN	5658.34	t	\N	\N	\N	2026-03-30 22:21:39.396	2026-03-30 22:21:43.087	82d5a9aa-8006-48f4-afc3-e02684f986a3
3690ddf3-3686-4088-90a6-5d776fcf4d03	ad434e3f-b929-4ff4-a80d-11feac16b136	82324aa9-e3d8-4b37-aa7e-e5dc2141a42d	D	MXN	5941.19	t	\N	\N	\N	2026-03-30 22:21:39.406	2026-03-30 22:21:43.096	82d5a9aa-8006-48f4-afc3-e02684f986a3
4db9428a-b133-4e7f-9e91-299989012db9	ad434e3f-b929-4ff4-a80d-11feac16b136	bcd1b43e-9c32-4fb2-a63a-791fd575e91c	C	MXN	6413.84	t	\N	\N	\N	2026-03-30 22:21:38.101	2026-03-30 22:21:41.552	6e58c7a8-0cb7-4791-927a-118eb4567d6a
af56aedf-b395-4b3e-a489-60b041e65c91	ad434e3f-b929-4ff4-a80d-11feac16b136	bcd1b43e-9c32-4fb2-a63a-791fd575e91c	C	MXN	6876.08	t	\N	\N	\N	2026-03-30 22:21:38.219	2026-03-30 22:21:41.64	16cec520-0a73-4f35-8727-86680849935c
c52f5644-0acd-4a3a-8b36-7fb4adbd6264	ad434e3f-b929-4ff4-a80d-11feac16b136	9cca5e76-de22-447c-a1bd-e5d16142d93e	D	MXN	6781.18	t	\N	\N	\N	2026-03-30 22:21:38.549	2026-03-30 22:21:42.052	c1ab5a74-ce67-4985-9c90-b75b3924854f
dca7f4b4-f7f3-4c70-a01e-172df150bcd0	ad434e3f-b929-4ff4-a80d-11feac16b136	9cca5e76-de22-447c-a1bd-e5d16142d93e	D	MXN	7094.02	t	\N	\N	\N	2026-03-30 22:21:38.628	2026-03-30 22:21:42.195	e5e317bf-c840-4729-b412-5ec62682673a
535ea967-4e6c-4225-a015-f2ffdd18df45	ad434e3f-b929-4ff4-a80d-11feac16b136	86e0de54-1f22-4556-9437-1b640d3d08cf	A	MXN	6398.70	t	\N	\N	\N	2026-03-30 22:21:39.134	2026-03-30 22:21:42.774	01ee0c67-a12f-44a6-ac95-ccc2dfa7537d
\.


--
-- TOC entry 3914 (class 0 OID 16651)
-- Dependencies: 240
-- Data for Name: product_variants; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_variants (id, product_id, tenant_id, name, variant_type, sku, metadata, active, created_at, depth, height, sort_order, width) FROM stdin;
b4e77f71-b6c8-4630-a18e-d2d1862ea653	214c5e59-79a2-4841-868d-a7f14f72ad99	843c9ed9-5fce-4111-9839-34949786bed8	Locker 2 Puertas	size	LOC-TEST-101	{"unit": "pza"}	t	2026-03-30 03:33:02.551	0.45	1.8	0	0.38
602404d0-a22f-43a7-943b-15b9b2f5f642	214c5e59-79a2-4841-868d-a7f14f72ad99	843c9ed9-5fce-4111-9839-34949786bed8	Locker 4 Puertas	size	LOC-TEST-102	{"unit": "pza"}	t	2026-03-30 03:33:02.607	0.45	1.8	1	0.76
99d1bd58-a6a1-4595-8629-f2fbaf118d1c	214c5e59-79a2-4841-868d-a7f14f72ad99	843c9ed9-5fce-4111-9839-34949786bed8	Locker Arena	color	LOC-TEST-103	{"unit": "pza"}	t	2026-03-30 03:33:02.658	0.45	1.8	2	0.38
0310293e-98c6-4d29-b4c3-d8e8ebbd8c45	2815adb2-fea4-49b8-b9c9-1d9998bc0691	843c9ed9-5fce-4111-9839-34949786bed8	Escritorio 1.50m	size	ESC-TEST-201	{"unit": "pza"}	t	2026-03-30 03:33:02.705	0.6	0.75	3	1.5
027a9de0-b4f5-482d-9a50-c96c38eb155f	2815adb2-fea4-49b8-b9c9-1d9998bc0691	843c9ed9-5fce-4111-9839-34949786bed8	Escritorio 1.80m	size	ESC-TEST-202	{"unit": "pza"}	t	2026-03-30 03:33:02.756	0.6	0.75	4	1.8
e0609a75-0565-49e7-ac37-3d3ad54e6947	9a0be7a1-0438-43d4-a43a-13f65ca12b09	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA SENCILLA INICIAL 1.50X0.60X0.74	size	PR-0027-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:32.018	0.6	0.74	1	1.5
253c9023-cf64-484f-961b-29152878f4ad	9a0be7a1-0438-43d4-a43a-13f65ca12b09	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA SENCILLA INICIAL 1.60X0.60X0.74	size	PR-0031-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:32.057	0.6	0.74	2	1.6
ee5ec61e-2da0-4d99-9c6e-92608139d324	9a0be7a1-0438-43d4-a43a-13f65ca12b09	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA SENCILLA INICIAL 1.80X0.60X0.74	size	PR-0035-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:32.098	0.6	0.74	3	1.8
e79e0874-4b29-4fde-ab5c-e63a1323ae7d	a18ee5db-cad6-45cb-a472-37975cdecc02	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA SENCILLA INICIAL 1.40X0.60X0.74 QUADRA	size	PR-0024-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:32.164	0.6	0.74	4	1.4
f7d28355-046b-4012-930d-8ab2ddd3dae7	a18ee5db-cad6-45cb-a472-37975cdecc02	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA SENCILLA INICIAL 1.50X0.60X0.74 QUADRA	size	PR-0028-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:32.209	0.6	0.74	5	1.5
761551bb-04f6-43b0-8eaa-49ffc8cff79d	a18ee5db-cad6-45cb-a472-37975cdecc02	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA SENCILLA INICIAL 1.60X0.60X0.74 QUADRA	size	PR-0032-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:32.263	0.6	0.74	6	1.6
c1d7fd57-440c-4240-808e-2352e855e377	a18ee5db-cad6-45cb-a472-37975cdecc02	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA SENCILLA INICIAL 1.80X0.60X0.74 QUADRA	size	PR-0036-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:32.306	0.6	0.74	7	1.8
cddc835c-39b2-4053-8830-afc558d91504	a65fd618-c46b-4f3a-89a5-016987a46e53	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA SENCILLA INICIAL 1.40X0.60X0.74 INCLINADA	size	PR-0025-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:32.371	0.6	0.74	8	1.4
97cd585f-2b7e-47ce-b0ba-e7d76643d402	a65fd618-c46b-4f3a-89a5-016987a46e53	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA SENCILLA INICIAL 1.50X0.60X0.74 INCLINADA	size	PR-0029-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:32.429	0.6	0.74	9	1.5
3f434c13-113e-4926-bb62-ce8116fced2a	a65fd618-c46b-4f3a-89a5-016987a46e53	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA SENCILLA INICIAL 1.60X0.60X0.74 INCLINADA	size	PR-0033-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:32.488	0.6	0.74	10	1.6
988192ae-9d9a-423b-8337-a8d581ff1792	a65fd618-c46b-4f3a-89a5-016987a46e53	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA SENCILLA INICIAL 1.80X0.60X0.74 INCLINADA	size	PR-0037-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:32.548	0.6	0.74	11	1.8
66892415-6ff3-407c-a22f-703cc3543486	8f35dd7b-cb84-4b7a-9c17-9de37fdbcf0c	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA SENCILLA INICIAL 1.40X0.60X0.74 SEMI INCLINADA	size	PR-0026-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:32.596	0.6	0.74	12	1.4
523891aa-d048-41e4-a9b9-956ec85a5518	8f35dd7b-cb84-4b7a-9c17-9de37fdbcf0c	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA SENCILLA INICIAL 1.60X0.60X0.74 SEMI INCLINADA	size	PR-0034-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:32.671	0.6	0.74	13	1.6
eeb421ef-52ec-4b87-a90a-a70e320322dd	8f35dd7b-cb84-4b7a-9c17-9de37fdbcf0c	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA SENCILLA INICIAL 1.50X0.60X0.74 SEMI INCLINADA	size	PR-0030-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:32.718	0.6	0.74	14	1.5
ddac1262-b2e3-4c77-a80c-8d6aef3a6625	8f35dd7b-cb84-4b7a-9c17-9de37fdbcf0c	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA SENCILLA INICIAL 1.80X0.60X0.74 SEMI INCLINADA	size	PR-0038-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:32.766	0.6	0.74	15	1.8
cef547a6-012b-4e2e-bb6e-0f0c7b755bd0	ebef8308-ebb5-4b75-b25e-0d648cf244ec	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA SENCILLA ADICIONAL 1.40X0.60X0.74	size	PR-0283-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:32.811	0.6	0.74	16	1.4
de341d58-44f2-4749-98bb-6baede3fb116	ebef8308-ebb5-4b75-b25e-0d648cf244ec	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA SENCILLA ADICIONAL 1.50X0.60X0.74	size	PR-0287-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:32.861	0.6	0.74	17	1.5
3f466380-daf6-4914-9ef4-ab4fc38b48a7	ebef8308-ebb5-4b75-b25e-0d648cf244ec	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA SENCILLA ADICIONAL 1.60X0.60X0.74	size	PR-0291-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:32.92	0.6	0.74	18	1.6
99aab12d-4c6d-40e1-8b17-da000e386280	ebef8308-ebb5-4b75-b25e-0d648cf244ec	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA SENCILLA ADICIONAL 1.80X0.60X0.74	size	PR-0295-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:32.984	0.6	0.74	19	1.8
717c4d0b-0c05-4a2c-be8e-0c4dddccf2b2	f8c7e1aa-6839-4b19-b028-4f59d51bc095	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA SENCILLA ADICIONAL 1.40X0.60X0.74 QUADRA	size	PR-0284-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:33.042	0.6	0.74	20	1.4
29a9988a-3f3b-4a1b-b817-c7a8adc049d7	f8c7e1aa-6839-4b19-b028-4f59d51bc095	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA SENCILLA ADICIONAL 1.50X0.60X0.74 QUADRA	size	PR-0288-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:33.096	0.6	0.74	21	1.5
196f8b13-af1d-4a46-8fdd-07172ddab25c	f8c7e1aa-6839-4b19-b028-4f59d51bc095	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA SENCILLA ADICIONAL 1.60X0.60X0.74 QUADRA	size	PR-0292-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:33.146	0.6	0.74	22	1.6
67380c1f-994e-40ee-b5c7-6b606a9891e1	f8c7e1aa-6839-4b19-b028-4f59d51bc095	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA SENCILLA ADICIONAL 1.80X0.60X0.74 QUADRA	size	PR-0296-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:33.188	0.6	0.74	23	1.8
cf9584cf-24d0-4cee-b6be-2993ba34f9bb	be7e9360-211f-46a7-b1e6-9e5fa0d486e7	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA SENCILLA ADICIONAL 1.50X0.60X0.74 INCLINADA	size	PR-0289-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:33.285	0.6	0.74	25	1.5
7c4afeae-7beb-4ebf-8313-75ec187e9d14	be7e9360-211f-46a7-b1e6-9e5fa0d486e7	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA SENCILLA ADICIONAL 1.60X0.60X0.74 INCLINADA	size	PR-0293-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:33.323	0.6	0.74	26	1.6
feb4eb22-43a6-4ea9-8cb0-dc8e7ff060b3	be7e9360-211f-46a7-b1e6-9e5fa0d486e7	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA SENCILLA ADICIONAL 1.80X0.60X0.74 INCLINADA	size	PR-0297-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:33.361	0.6	0.74	27	1.8
c90fd1e9-2d31-43e4-869f-15eb2bff11f8	b15298f9-bfa6-455f-8c61-b2dc71a0028e	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA SENCILLA ADICIONAL 1.40X0.60X0.74 SEMI INCLINADA	size	PR-0286-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:33.403	0.6	0.74	28	1.4
72a9fb66-c4e2-49bc-bead-db7ee8bd5998	b15298f9-bfa6-455f-8c61-b2dc71a0028e	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA SENCILLA ADICIONAL 1.50X0.60X0.74 SEMI INCLINADA	size	PR-0290-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:33.46	0.6	0.74	29	1.5
fbc4caaf-b78e-47b6-817e-88be0f7a60bb	b15298f9-bfa6-455f-8c61-b2dc71a0028e	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA SENCILLA ADICIONAL 1.60X0.60X0.74 SEMI INCLINADA	size	PR-0294-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:33.528	0.6	0.74	30	1.6
267b31dd-3018-419b-b0f9-c1912b372420	b15298f9-bfa6-455f-8c61-b2dc71a0028e	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA SENCILLA ADICIONAL 1.80X0.60X0.74 SEMI INCLINADA	size	PR-0298-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:33.598	0.6	0.74	31	1.8
8b3ce486-2880-47e2-89ae-4de080826b9a	06c7a87d-5bbf-48ec-9a65-899b069cf396	ad434e3f-b929-4ff4-a80d-11feac16b136	LATERAL MESA SENCILLA 1.20X0.60X0.74 FRONTAL 60	size	PR-0731-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:33.654	0.6	0.74	32	1.2
edae2faf-3ccc-42a6-a12f-cd76f29935c5	37c02803-58c5-45c1-941a-e2bf55cc7a8d	ad434e3f-b929-4ff4-a80d-11feac16b136	LATERAL MESA SENCILLA 1.20X0.60X0.74 QUADRA FRONTAL 60	size	PR-0732-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:33.701	0.6	0.74	33	1.2
a649fef5-8804-4668-9a77-1392d947eb14	74121cef-f590-4d31-a33e-32c92ef65fd8	ad434e3f-b929-4ff4-a80d-11feac16b136	LATERAL MESA SENCILLA 1.20X0.60X0.74 INCLINADA FRONTAL 60	size	PR-0733-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:33.764	0.6	0.74	34	1.2
f3b253ff-6323-4831-9410-1e7916dc7437	6407104f-cf91-4ada-8daa-ba613ced763e	ad434e3f-b929-4ff4-a80d-11feac16b136	LATERAL MESA SENCILLA 1.20X0.60X0.74 SEMI INCLINADA FRONTAL 60	size	PR-0734-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:33.818	0.6	0.74	35	1.2
a3193b94-f506-44dc-bbb3-e51442f82ee8	93b0a71f-5e96-4ddb-b6bf-76ebd51d44eb	ad434e3f-b929-4ff4-a80d-11feac16b136	LATERAL MESA SENCILLA 1.20X0.75X0.74 FRONTAL 60	size	PR-0747-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:33.858	0.75	0.74	36	1.2
862ee54c-d67e-4fea-8582-c75b899765e7	6671b2b0-0dd0-481f-92f9-1a8b63183027	ad434e3f-b929-4ff4-a80d-11feac16b136	LATERAL MESA SENCILLA 1.20X0.75X0.74 QUADRA FRONTAL 60	size	PR-0748-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:33.9	0.75	0.74	37	1.2
061d45b0-ac8b-43d5-a62d-c293c65f0557	87dd282b-52da-4ff9-8998-5b825b13c5c9	ad434e3f-b929-4ff4-a80d-11feac16b136	LATERAL MESA SENCILLA 1.20X0.75X0.74 INCLINADA FRONTAL 60	size	PR-0749-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:33.952	0.75	0.74	38	1.2
7d2d18ee-6693-44ea-b96b-1811a159aa8c	879eda6d-128f-4680-b285-53bab6334a3e	ad434e3f-b929-4ff4-a80d-11feac16b136	LATERAL MESA SENCILLA 1.20X0.75X0.74 SEMI INCLINADA FRONTAL 60	size	PR-0750-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:34.002	0.75	0.74	39	1.2
51d2205d-1d44-4a3f-81ce-defe85beb38b	ada8d0ac-6b3d-46a8-ac98-8a1b1192a7ae	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA SENCILLA INICIAL 1.40X0.75X0.74	size	PR-0143-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:34.045	0.75	0.74	40	1.4
8ce1c577-6396-4dd6-a143-87727a63f172	ada8d0ac-6b3d-46a8-ac98-8a1b1192a7ae	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA SENCILLA INICIAL 1.50X0.75X0.74	size	PR-0147-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:34.092	0.75	0.74	41	1.5
8bc594fe-1343-4eaf-97a5-7aa6801fdf31	ada8d0ac-6b3d-46a8-ac98-8a1b1192a7ae	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA SENCILLA INICIAL 1.60X0.75X0.74	size	PR-0151-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:34.131	0.75	0.74	42	1.6
562018ba-2459-409e-b535-3c0d43410718	ada8d0ac-6b3d-46a8-ac98-8a1b1192a7ae	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA SENCILLA INICIAL 1.80X0.75X0.74	size	PR-0155-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:34.188	0.75	0.74	43	1.8
f4f7e489-c01f-41f2-99a4-9334c0d6fc21	e934b4ff-1597-44df-8d7f-640c6d7e8707	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA SENCILLA INICIAL 1.40X0.75X0.74 QUADRA	size	PR-0144-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:34.238	0.75	0.74	44	1.4
9a78bee8-0d41-4f43-b924-eae301192c91	e934b4ff-1597-44df-8d7f-640c6d7e8707	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA SENCILLA INICIAL 1.50X0.75X0.74 QUADRA	size	PR-0148-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:34.28	0.75	0.74	45	1.5
08b60d49-f649-4d41-bf86-bc7bc5812d36	e934b4ff-1597-44df-8d7f-640c6d7e8707	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA SENCILLA INICIAL 1.60X0.75X0.74 QUADRA	size	PR-0152-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:34.325	0.75	0.74	46	1.6
62e7461e-b0ae-4c98-8a0c-836ad7c59a47	e934b4ff-1597-44df-8d7f-640c6d7e8707	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA SENCILLA INICIAL 1.80X0.75X0.74 QUADRA	size	PR-0156-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:34.376	0.75	0.74	47	1.8
9f5f9cb3-f9fe-4f16-bf52-a0114278af8a	73f4aef0-f656-4768-9818-07129ee45791	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA SENCILLA INICIAL 1.40X0.75X0.74 INCLINADA	size	PR-0145-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:34.418	0.75	0.74	48	1.4
d2b40e91-b109-4082-ac23-072fb43cd14d	73f4aef0-f656-4768-9818-07129ee45791	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA SENCILLA INICIAL 1.50X0.75X0.74 INCLINADA	size	PR-0149-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:34.456	0.75	0.74	49	1.5
3ea51136-a661-44e3-9a75-acfe6ce6d4ca	73f4aef0-f656-4768-9818-07129ee45791	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA SENCILLA INICIAL 1.60X0.75X0.74 INCLINADA	size	PR-0153-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:34.491	0.75	0.74	50	1.6
f0c01c30-d31d-420f-a434-a1354beb7d90	73f4aef0-f656-4768-9818-07129ee45791	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA SENCILLA INICIAL 1.80X0.75X0.74 INCLINADA	size	PR-0157-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:34.53	0.75	0.74	51	1.8
aba72031-2ffc-4178-87d8-19ae461dff65	9a0be7a1-0438-43d4-a43a-13f65ca12b09	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA SENCILLA INICIAL 1.40X0.60X0.74	size	PR-0023-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:31.976	0.6	0.74	0	1.4
bee0e330-6637-4839-82fc-cbac1f24ddb4	8f63d311-722f-4b90-b890-fe271b51a9b4	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA SENCILLA INICIAL 1.60X0.75X0.74 SEMI INCLINADA	size	PR-0154-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:34.612	0.75	0.74	53	1.6
307b4617-c66e-4d65-b2a3-46fdd974d9d8	8f63d311-722f-4b90-b890-fe271b51a9b4	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA SENCILLA INICIAL 1.50X0.75X0.74 SEMI INCLINADA	size	PR-0150-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:34.649	0.75	0.74	54	1.5
ee631f5b-c4b0-4c11-93b5-db9b593d8698	8f63d311-722f-4b90-b890-fe271b51a9b4	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA SENCILLA INICIAL 1.80X0.75X0.74 SEMI INCLINADA	size	PR-0158-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:34.685	0.75	0.74	55	1.8
6f69186b-d301-48ee-b45a-f9ea4bcc6e49	1b778817-d9ab-428b-bdf1-9ebe3ed039ae	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA SENCILLA ADICIONAL 1.40X0.75X0.74	size	PR-0383-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:34.718	0.75	0.74	56	1.4
cbb89089-b313-46d9-80d1-db836d510c7c	1b778817-d9ab-428b-bdf1-9ebe3ed039ae	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA SENCILLA ADICIONAL 1.50X0.75X0.74	size	PR-0387-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:34.757	0.75	0.74	57	1.5
006f2288-6372-4c73-8186-879d6b4de577	1b778817-d9ab-428b-bdf1-9ebe3ed039ae	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA SENCILLA ADICIONAL 1.60X0.75X0.74	size	PR-0391-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:34.795	0.75	0.74	58	1.6
6b60fe9b-b002-4591-bcb4-d1696cc55b10	1b778817-d9ab-428b-bdf1-9ebe3ed039ae	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA SENCILLA ADICIONAL 1.80X0.75X0.74	size	PR-0395-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:34.832	0.75	0.74	59	1.8
04e79f99-bdf3-46f5-aed9-6e4d79cfbc98	e6e416d8-32ee-409e-9816-17c5e6f8b420	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA SENCILLA ADICIONAL 1.40X0.75X0.74 QUADRA	size	PR-0384-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:34.868	0.75	0.74	60	1.4
cf29c524-b552-4f10-86b6-ee64bdc29346	e6e416d8-32ee-409e-9816-17c5e6f8b420	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA SENCILLA ADICIONAL 1.50X0.75X0.74 QUADRA	size	PR-0388-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:34.908	0.75	0.74	61	1.5
cf00674c-6ea7-4487-9985-229866e05d2f	e6e416d8-32ee-409e-9816-17c5e6f8b420	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA SENCILLA ADICIONAL 1.60X0.75X0.74 QUADRA	size	PR-0392-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:34.944	0.75	0.74	62	1.6
6d1f5331-abfc-4524-a4a9-c90d389cc232	e6e416d8-32ee-409e-9816-17c5e6f8b420	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA SENCILLA ADICIONAL 1.80X0.75X0.74 QUADRA	size	PR-0396-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:35.016	0.75	0.74	63	1.8
7d04757d-dd79-4815-be30-938e034b618c	fc47eeb3-86e6-4a97-8964-821b5861a39d	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA SENCILLA ADICIONAL 1.40X0.75X0.74 INCLINADA	size	PR-0385-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:35.057	0.75	0.74	64	1.4
82f6062e-6f86-4c55-b1ba-f9b87fbfc14c	fc47eeb3-86e6-4a97-8964-821b5861a39d	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA SENCILLA ADICIONAL 1.50X0.75X0.74 INCLINADA	size	PR-0389-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:35.114	0.75	0.74	65	1.5
6b269ae3-e3af-44ce-ad9e-63a8ea979d56	fc47eeb3-86e6-4a97-8964-821b5861a39d	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA SENCILLA ADICIONAL 1.60X0.75X0.74 INCLINADA	size	PR-0393-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:35.16	0.75	0.74	66	1.6
2b5fcf25-3601-479a-b829-c76e07c88da5	fc47eeb3-86e6-4a97-8964-821b5861a39d	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA SENCILLA ADICIONAL 1.80X0.75X0.74 INCLINADA	size	PR-0397-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:35.21	0.75	0.74	67	1.8
dae7c93b-f6ec-459d-9792-bc22e2bf38e1	4cb2e968-181c-4d39-be42-ef153c26cc63	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA SENCILLA ADICIONAL 1.40X0.75X0.74 SEMI INCLINADA	size	PR-0386-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:35.256	0.75	0.74	68	1.4
c74ba569-cd40-4ea7-ab94-dda33e35a403	4cb2e968-181c-4d39-be42-ef153c26cc63	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA SENCILLA ADICIONAL 1.50X0.75X0.74 SEMI INCLINADA	size	PR-0390-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:35.294	0.75	0.74	69	1.5
99313dc2-8241-4f36-9b4b-e2eaddb1fad3	4cb2e968-181c-4d39-be42-ef153c26cc63	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA SENCILLA ADICIONAL 1.60X0.75X0.74 SEMI INCLINADA	size	PR-0394-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:35.335	0.75	0.74	70	1.6
1a2f628a-4a98-4052-a31a-9bb32c52b36b	4cb2e968-181c-4d39-be42-ef153c26cc63	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA SENCILLA ADICIONAL 1.80X0.75X0.74 SEMI INCLINADA	size	PR-0398-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:35.373	0.75	0.74	71	1.8
31d43601-712a-483a-8126-0cfb00c30c4d	d9bc9698-afef-47a5-b7a9-226ed87f142a	ad434e3f-b929-4ff4-a80d-11feac16b136	LATERAL MESA SENCILLA 1.05X0.60X0.74 FRONTAL 75	size	PR-0727-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:35.42	0.6	0.74	72	1.05
0bcb406a-760f-4cdd-9bef-22515b5627e0	61ccce64-d1d1-4e44-b290-287fcddf40cc	ad434e3f-b929-4ff4-a80d-11feac16b136	LATERAL MESA SENCILLA 1.05X0.60X0.74 QUADRA FRONTAL 75	size	PR-0728-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:35.465	0.6	0.74	73	1.05
c5582213-a38f-4d45-b15c-8f6d310b2944	5d3decde-b899-4682-9dc6-d4cb91338e7a	ad434e3f-b929-4ff4-a80d-11feac16b136	LATERAL MESA SENCILLA 1.05X0.60X0.74 INCLINADA FRONTAL 75	size	PR-0729-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:35.506	0.6	0.74	74	1.05
050617d4-45fa-4394-b144-a361b9958c0b	7595d52a-b509-4c49-9d77-87b8a8c0e0d5	ad434e3f-b929-4ff4-a80d-11feac16b136	LATERAL MESA SENCILLA 1.05X0.60X0.74 SEMI INCLINADA FRONTAL 75	size	PR-0730-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:35.542	0.6	0.74	75	1.05
f7c2bf16-6563-4291-a21f-3d31fa58afb6	37ae24e2-6337-4eaf-916b-9f1a9f8252c9	ad434e3f-b929-4ff4-a80d-11feac16b136	LATERAL MESA SENCILLA 1.05X0.75X0.74 FRONTAL 75	size	PR-0743-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:35.581	0.75	0.74	76	1.05
029a73b5-1508-42b8-8409-cf6d31991cbe	4d35c1d2-e088-4393-b2fb-ed2e7b7b511d	ad434e3f-b929-4ff4-a80d-11feac16b136	LATERAL MESA SENCILLA 1.05X0.75X0.74 QUADRA FRONTAL 75	size	PR-0744-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:35.625	0.75	0.74	77	1.05
baa18bf5-bfda-43f8-af81-a24068303eaf	ab6dd978-ac6b-4d6c-b43e-393cfc8f1f38	ad434e3f-b929-4ff4-a80d-11feac16b136	LATERAL MESA SENCILLA 1.05X0.75X0.74 INCLINADA FRONTAL 75	size	PR-0745-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:35.659	0.75	0.74	78	1.05
8d0a57ce-c21e-4988-a81e-f962791c3253	e4bc3270-0a38-461e-a321-211a7ebd94b3	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA BENCH INICIAL 1.40X1.20X0.74	size	PR-0502-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:35.732	1.2	0.74	80	1.4
d2f8817b-edb9-43c2-95ff-2542fd70f60b	e4bc3270-0a38-461e-a321-211a7ebd94b3	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA BENCH INICIAL 1.50X1.20X0.74	size	PR-0505-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:35.768	1.2	0.74	81	1.5
472a6f96-284f-4cf9-9df9-f159e48309a1	e4bc3270-0a38-461e-a321-211a7ebd94b3	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA BENCH INICIAL 1.60X1.20X0.74	size	PR-0508-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:35.806	1.2	0.74	82	1.6
7f921d4d-e657-4228-bd91-fb5a3709636c	e4bc3270-0a38-461e-a321-211a7ebd94b3	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA BENCH INICIAL 1.80X1.20X0.74	size	PR-0511-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:35.848	1.2	0.74	83	1.8
7305a3e8-416b-4e7d-8b94-ec97f10707fb	d6d4bb71-ab21-43b4-9187-41dc7eb19dc1	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA BENCH INICIAL 1.40X1.20X0.74 QUADRA	size	PR-0503-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:35.885	1.2	0.74	84	1.4
1b09736f-0666-4b0b-a203-b0433f8c0407	d6d4bb71-ab21-43b4-9187-41dc7eb19dc1	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA BENCH INICIAL 1.50X1.20X0.74 QUADRA	size	PR-0506-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:35.929	1.2	0.74	85	1.5
7616453f-08d1-4fe2-9463-d22d04401c88	d6d4bb71-ab21-43b4-9187-41dc7eb19dc1	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA BENCH INICIAL 1.60X1.20X0.74 QUADRA	size	PR-0509-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:35.973	1.2	0.74	86	1.6
28f9e816-a6c8-4ab3-9f74-62380c1fbbc4	d6d4bb71-ab21-43b4-9187-41dc7eb19dc1	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA BENCH INICIAL 1.80X1.20X0.74 QUADRA	size	PR-0512-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:36.017	1.2	0.74	87	1.8
762ef71e-b6c3-4311-81e9-b7ef591e442c	26d54ae1-6589-404b-b97e-5844a49a4126	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA BENCH INICIAL 1.40X1.20X0.74 INCLINADA	size	PR-0504-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:36.057	1.2	0.74	88	1.4
26662e5f-b0c4-406f-83c5-255fab6e60cc	26d54ae1-6589-404b-b97e-5844a49a4126	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA BENCH INICIAL 1.50X1.20X0.74 INCLINADA	size	PR-0507-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:36.099	1.2	0.74	89	1.5
c795860a-439d-4859-995a-134094570cc9	26d54ae1-6589-404b-b97e-5844a49a4126	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA BENCH INICIAL 1.60X1.20X0.74 INCLINADA	size	PR-0510-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:36.141	1.2	0.74	90	1.6
047fa171-7415-40a0-ad94-b3f35fc55803	26d54ae1-6589-404b-b97e-5844a49a4126	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA BENCH INICIAL 1.80X1.20X0.74 INCLINADA	size	PR-0513-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:36.184	1.2	0.74	91	1.8
d3fdc076-90a7-4152-b71d-8a207e9f395b	bcd1b43e-9c32-4fb2-a63a-791fd575e91c	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA BENCH ADICIONAL 1.40X1.20X0.74	size	PR-0622-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:36.232	1.2	0.74	92	1.4
42e6d5e9-8d7c-4ff6-b728-91346af7fad9	bcd1b43e-9c32-4fb2-a63a-791fd575e91c	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA BENCH ADICIONAL 1.50X1.20X0.74	size	PR-0625-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:36.299	1.2	0.74	93	1.5
9d6f498e-3656-4d04-9ffc-2297e760013d	bcd1b43e-9c32-4fb2-a63a-791fd575e91c	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA BENCH ADICIONAL 1.60X1.20X0.74	size	PR-0628-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:36.34	1.2	0.74	94	1.6
9d0373fb-cc23-451a-9b90-cf01c2f65e74	bcd1b43e-9c32-4fb2-a63a-791fd575e91c	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA BENCH ADICIONAL 1.80X1.20X0.74	size	PR-0631-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:36.388	1.2	0.74	95	1.8
3e5a0d7d-1be8-44bd-82c5-45ae67aa2978	008b256d-38f7-4781-83cf-04b1f624051e	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA BENCH ADICIONAL 1.40X1.20X0.74 QUADRA	size	PR-0623-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:36.439	1.2	0.74	96	1.4
2c571442-156d-4258-b1d1-4a369f742bd4	008b256d-38f7-4781-83cf-04b1f624051e	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA BENCH ADICIONAL 1.50X1.20X0.74 QUADRA	size	PR-0626-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:36.48	1.2	0.74	97	1.5
1b5799bf-a6e5-4a3b-9db6-f596e5bb4555	008b256d-38f7-4781-83cf-04b1f624051e	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA BENCH ADICIONAL 1.60X1.20X0.74 QUADRA	size	PR-0629-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:36.523	1.2	0.74	98	1.6
1d5fb1fe-3c6c-4af4-999d-e38397b05468	008b256d-38f7-4781-83cf-04b1f624051e	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA BENCH ADICIONAL 1.80X1.20X0.74 QUADRA	size	PR-0632-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:36.561	1.2	0.74	99	1.8
0e199f32-c3af-4ac0-b5d4-e629da9e2187	9cca5e76-de22-447c-a1bd-e5d16142d93e	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA BENCH ADICIONAL 1.40X1.20X0.74 INCLINADA	size	PR-0624-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:36.604	1.2	0.74	100	1.4
083939fd-ddcb-4ce4-bffa-815de313defe	9cca5e76-de22-447c-a1bd-e5d16142d93e	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA BENCH ADICIONAL 1.50X1.20X0.74 INCLINADA	size	PR-0627-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:36.644	1.2	0.74	101	1.5
13f71920-4a3d-4077-a201-1bd773ff22a4	9cca5e76-de22-447c-a1bd-e5d16142d93e	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA BENCH ADICIONAL 1.60X1.20X0.74 INCLINADA	size	PR-0630-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:36.682	1.2	0.74	102	1.6
8f8e58a8-fb67-4735-9d7b-12d0fd332123	9cca5e76-de22-447c-a1bd-e5d16142d93e	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA BENCH ADICIONAL 1.80X1.20X0.74 INCLINADA	size	PR-0633-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:36.718	1.2	0.74	103	1.8
d6beb8d9-dbf3-46cf-a9a7-ac7f8f01665c	bd2b7acf-9367-419f-a8b1-7e4053fd4ff9	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA BENCH CENTRAL 1.40X1.20X0.74	size	PR-0681-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:36.752	1.2	0.74	104	1.4
44508644-1678-4cf1-bd93-704cc110e85c	bd2b7acf-9367-419f-a8b1-7e4053fd4ff9	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA BENCH CENTRAL 1.50X1.20X0.74	size	PR-0683-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:36.786	1.2	0.74	105	1.5
a441d2fb-8dc3-42f8-a4bb-4eeb0a42fbf1	bd2b7acf-9367-419f-a8b1-7e4053fd4ff9	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA BENCH CENTRAL 1.60X1.20X0.74	size	PR-0685-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:36.821	1.2	0.74	106	1.6
fb3beb95-e9a0-4439-bcf5-9f6d8e0d1364	bd2b7acf-9367-419f-a8b1-7e4053fd4ff9	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA BENCH CENTRAL 1.80X1.20X0.74	size	PR-0687-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:36.856	1.2	0.74	107	1.8
101dfe1f-4d63-47b8-b9f6-19f58ce66063	be7e9360-211f-46a7-b1e6-9e5fa0d486e7	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA SENCILLA ADICIONAL 1.40X0.60X0.74 INCLINADA	size	PR-0285-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:33.235	0.6	0.74	24	1.4
56b96533-0368-4378-aa13-5fc86a70b6d1	8f63d311-722f-4b90-b890-fe271b51a9b4	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA SENCILLA INICIAL 1.40X0.75X0.74 SEMI INCLINADA	size	PR-0146-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:34.573	0.75	0.74	52	1.4
9aaf4531-2747-47d4-aec4-3b3e3d7470e5	e8b0d497-0784-48dc-9622-fa1c0ff0afc6	ad434e3f-b929-4ff4-a80d-11feac16b136	LATERAL MESA SENCILLA 1.05X0.75X0.74 SEMI INCLINADA FRONTAL 75	size	PR-0746-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:35.696	0.75	0.74	79	1.05
7cdec777-94f0-422f-8197-b31535358f92	86e0de54-1f22-4556-9437-1b640d3d08cf	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA BENCH CENTRAL 1.40X1.20X0.74 QUADRA	size	PR-0682-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:36.898	1.2	0.74	108	1.4
79417077-0a99-490b-9d06-1f6a7c5cdb44	4bbf5039-4c8e-4d07-80b1-b36bec5151d0	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA BENCH INICIAL 1.40X1.50X0.74 INCLINADA	size	PR-0564-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:37.808	1.5	0.74	126	1.4
a3d5eff6-2603-4d20-bdce-9694d023245c	86e0de54-1f22-4556-9437-1b640d3d08cf	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA BENCH CENTRAL 1.50X1.20X0.74 QUADRA	size	PR-0684-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:36.934	1.2	0.74	109	1.5
6eafd61d-f568-423e-8e6d-38c6e550b9c8	86e0de54-1f22-4556-9437-1b640d3d08cf	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA BENCH CENTRAL 1.60X1.20X0.74 QUADRA	size	PR-0686-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:36.976	1.2	0.74	110	1.6
dc9366fc-6f94-4668-bfe5-a4cad7fb9f68	86e0de54-1f22-4556-9437-1b640d3d08cf	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA BENCH CENTRAL 1.80X1.20X0.74 QUADRA	size	PR-0688-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:37.012	1.2	0.74	111	1.8
7de45c2b-c1df-42b9-8d41-25c3d47d2da5	a3539472-03d3-4625-831f-246f355c82aa	ad434e3f-b929-4ff4-a80d-11feac16b136	LATERAL MESA BENCH 1.20X1.20X0.74 FRONTAL 60	size	PR-0842-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:37.057	1.2	0.74	112	1.2
f0b35e5c-2d30-4f9a-9f50-37432d807181	6d125e00-87ce-487a-9ab2-cc15e442d3af	ad434e3f-b929-4ff4-a80d-11feac16b136	LATERAL MESA BENCH 1.20X1.20X0.74 QUADRA FRONTAL 60	size	PR-0843-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:37.102	1.2	0.74	113	1.2
d6df0e90-98cf-416e-90dc-9c18f2b3a32b	421a93a9-10a5-418f-bb61-8c29065e7a8b	ad434e3f-b929-4ff4-a80d-11feac16b136	LATERAL MESA BENCH 1.20X1.20X0.74 INCLINADA FRONTAL 60	size	PR-0844-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:37.14	1.2	0.74	114	1.2
4e6ea854-51d6-4bec-a400-573d956b687c	083a6238-60db-4b53-8617-f63f09870c1f	ad434e3f-b929-4ff4-a80d-11feac16b136	LATERAL MESA BENCH 1.20X1.50X0.74 FRONTAL 60	size	PR-0858-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:37.18	1.5	0.74	115	1.2
e6de4041-2cd2-4c7a-bfc7-1124707d13da	cf163728-3824-4dae-a07c-4396b0da3382	ad434e3f-b929-4ff4-a80d-11feac16b136	LATERAL MESA BENCH 1.20X1.50X0.74 QUADRA FRONTAL 60	size	PR-0859-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:37.22	1.5	0.74	116	1.2
54e3078c-d24a-47e1-a74d-dd52997c0062	9adabc28-d0a0-4175-b24b-0ee84e43d89b	ad434e3f-b929-4ff4-a80d-11feac16b136	LATERAL MESA BENCH 1.20X1.50X0.74 INCLINADA FRONTAL 60	size	PR-0860-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:37.267	1.5	0.74	117	1.2
f6bd8fc1-eabc-4724-be4e-7e1991d419af	5aab8c35-7477-495e-aa07-b6e4f6dbe457	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA BENCH INICIAL 1.40X1.50X0.74	size	PR-0562-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:37.325	1.5	0.74	118	1.4
6271d55d-06bb-4ba4-8424-77ca16722d5c	5aab8c35-7477-495e-aa07-b6e4f6dbe457	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA BENCH INICIAL 1.50X1.50X0.74	size	PR-0565-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:37.379	1.5	0.74	119	1.5
a505c639-1608-4ff5-9dbb-b48df37d5185	5aab8c35-7477-495e-aa07-b6e4f6dbe457	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA BENCH INICIAL 1.60X1.50X0.74	size	PR-0568-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:37.423	1.5	0.74	120	1.6
1c5c8279-58b5-432e-b922-f639a7ca10cd	5aab8c35-7477-495e-aa07-b6e4f6dbe457	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA BENCH INICIAL 1.80X1.50X0.74	size	PR-0571-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:37.479	1.5	0.74	121	1.8
8fa089b4-e69a-4488-bd5b-62d69909bee4	a2cec753-8d86-42f4-9f45-16aaf894e4b2	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA BENCH INICIAL 1.40X1.50X0.74 QUADRA	size	PR-0563-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:37.55	1.5	0.74	122	1.4
7fb776aa-f13b-44b2-9091-d89f40ded4fd	a2cec753-8d86-42f4-9f45-16aaf894e4b2	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA BENCH INICIAL 1.50X1.50X0.74 QUADRA	size	PR-0566-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:37.663	1.5	0.74	123	1.5
9c1e8d12-8bda-4837-9ad6-4a2d4a95b7ba	a2cec753-8d86-42f4-9f45-16aaf894e4b2	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA BENCH INICIAL 1.60X1.50X0.74 QUADRA	size	PR-0569-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:37.722	1.5	0.74	124	1.6
a54cbdf6-0d40-4541-898d-397dcb8bd715	a2cec753-8d86-42f4-9f45-16aaf894e4b2	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA BENCH INICIAL 1.80X1.50X0.74 QUADRA	size	PR-0572-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:37.772	1.5	0.74	125	1.8
8e546c86-d6c0-4a50-be99-1bf7bc643ee5	4bbf5039-4c8e-4d07-80b1-b36bec5151d0	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA BENCH INICIAL 1.50X1.50X0.74 INCLINADA	size	PR-0567-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:37.849	1.5	0.74	127	1.5
be5e6238-669c-4446-bab9-c1f54569b240	4bbf5039-4c8e-4d07-80b1-b36bec5151d0	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA BENCH INICIAL 1.60X1.50X0.74 INCLINADA	size	PR-0570-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:37.89	1.5	0.74	128	1.6
a50361eb-17fb-43b1-ace0-6626ab3beed2	4bbf5039-4c8e-4d07-80b1-b36bec5151d0	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA BENCH INICIAL 1.80X1.50X0.74 INCLINADA	size	PR-0573-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:37.937	1.5	0.74	129	1.8
76921fe7-8ee6-447b-b7e1-a06539bf0973	bcd1b43e-9c32-4fb2-a63a-791fd575e91c	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA BENCH ADICIONAL 1.20X1.50X0.74	size	PR-0649-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:37.983	1.2	0.74	130	1.2
286781b1-a426-4c66-8d01-f81606b36da1	bcd1b43e-9c32-4fb2-a63a-791fd575e91c	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA BENCH ADICIONAL 1.40X1.50X0.74	size	PR-0652-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:38.028	1.2	0.74	131	1.4
6e58c7a8-0cb7-4791-927a-118eb4567d6a	bcd1b43e-9c32-4fb2-a63a-791fd575e91c	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA BENCH ADICIONAL 1.50X1.50X0.74	size	PR-0655-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:38.075	1.2	0.74	132	1.5
43c9ed85-c152-4c04-8518-0342d967fc82	bcd1b43e-9c32-4fb2-a63a-791fd575e91c	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA BENCH ADICIONAL 1.60X1.50X0.74	size	PR-0658-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:38.123	1.2	0.74	133	1.6
16cec520-0a73-4f35-8727-86680849935c	bcd1b43e-9c32-4fb2-a63a-791fd575e91c	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA BENCH ADICIONAL 1.80X1.50X0.74	size	PR-0661-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:38.184	1.2	0.74	134	1.8
d528b7cb-cb8a-4ec2-adf4-8cd1c287bc5a	008b256d-38f7-4781-83cf-04b1f624051e	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA BENCH ADICIONAL 1.40X1.50X0.74 QUADRA	size	PR-0653-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:38.25	1.2	0.74	135	1.4
bc73c5fb-04f1-4be4-ab2b-2fe58d9e4174	008b256d-38f7-4781-83cf-04b1f624051e	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA BENCH ADICIONAL 1.20X1.50X0.74 QUADRA	size	PR-0650-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:38.299	1.2	0.74	136	1.2
89b87c76-288b-4f9f-ba97-a713c003efb2	008b256d-38f7-4781-83cf-04b1f624051e	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA BENCH ADICIONAL 1.50X1.50X0.74 QUADRA	size	PR-0656-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:38.338	1.2	0.74	137	1.5
3a8531fa-2411-48ab-8af5-e9c047116236	008b256d-38f7-4781-83cf-04b1f624051e	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA BENCH ADICIONAL 1.60X1.50X0.74 QUADRA	size	PR-0659-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:38.381	1.2	0.74	138	1.6
8614fd78-de35-4fca-86fb-eb7060d49587	008b256d-38f7-4781-83cf-04b1f624051e	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA BENCH ADICIONAL 1.80X1.50X0.74 QUADRA	size	PR-0662-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:38.426	1.2	0.74	139	1.8
c0b7dc51-d9c3-4ea8-8842-855598afe12d	9cca5e76-de22-447c-a1bd-e5d16142d93e	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA BENCH ADICIONAL 1.20X1.50X0.74 INCLINADA	size	PR-0651-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:38.48	1.2	0.74	140	1.2
c1ab5a74-ce67-4985-9c90-b75b3924854f	9cca5e76-de22-447c-a1bd-e5d16142d93e	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA BENCH ADICIONAL 1.40X1.50X0.74 INCLINADA	size	PR-0654-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:38.521	1.2	0.74	141	1.4
74a002cd-c785-4d33-8014-057415583672	9cca5e76-de22-447c-a1bd-e5d16142d93e	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA BENCH ADICIONAL 1.50X1.50X0.74 INCLINADA	size	PR-0657-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:38.557	1.2	0.74	142	1.5
e5e317bf-c840-4729-b412-5ec62682673a	9cca5e76-de22-447c-a1bd-e5d16142d93e	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA BENCH ADICIONAL 1.60X1.50X0.74 INCLINADA	size	PR-0660-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:38.597	1.2	0.74	143	1.6
8161596a-5ed3-47ef-b853-576feacb890f	9cca5e76-de22-447c-a1bd-e5d16142d93e	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA BENCH ADICIONAL 1.80X1.50X0.74 INCLINADA	size	PR-0663-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:38.635	1.2	0.74	144	1.8
d2ad100f-2a4a-4a57-a84f-61ea058e972b	bd2b7acf-9367-419f-a8b1-7e4053fd4ff9	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA BENCH CENTRAL 1.20X1.50X0.74	size	PR-0699-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:38.679	1.2	0.74	145	1.2
7239d3c0-c937-43c1-b35a-1a817c5aae98	bd2b7acf-9367-419f-a8b1-7e4053fd4ff9	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA BENCH CENTRAL 1.40X1.50X0.74	size	PR-0701-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:38.727	1.2	0.74	146	1.4
a38b2900-aaf5-4cea-b595-905a44b0596b	bd2b7acf-9367-419f-a8b1-7e4053fd4ff9	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA BENCH CENTRAL 1.50X1.50X0.74	size	PR-0703-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:38.794	1.2	0.74	147	1.5
fd2b6c36-88c3-488d-bbbb-24a4267a88d1	bd2b7acf-9367-419f-a8b1-7e4053fd4ff9	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA BENCH CENTRAL 1.60X1.50X0.74	size	PR-0705-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:38.874	1.2	0.74	148	1.6
96ef0c69-815b-420c-9ca9-8eded8d31c2c	bd2b7acf-9367-419f-a8b1-7e4053fd4ff9	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA BENCH CENTRAL 1.80X1.50X0.74	size	PR-0707-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:38.921	1.2	0.74	149	1.8
78242f94-87f4-4c34-8577-1e2518fe71f3	86e0de54-1f22-4556-9437-1b640d3d08cf	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA BENCH CENTRAL 1.20X1.50X0.74 QUADRA	size	PR-0700-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:38.976	1.2	0.74	150	1.2
a121e5c8-f3b8-4263-b3bd-c71214e26515	86e0de54-1f22-4556-9437-1b640d3d08cf	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA BENCH CENTRAL 1.40X1.50X0.74 QUADRA	size	PR-0702-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:39.036	1.2	0.74	151	1.4
a016707d-3639-4517-afaf-afd5c803e25b	86e0de54-1f22-4556-9437-1b640d3d08cf	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA BENCH CENTRAL 1.50X1.50X0.74 QUADRA	size	PR-0704-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:39.081	1.2	0.74	152	1.5
01ee0c67-a12f-44a6-ac95-ccc2dfa7537d	86e0de54-1f22-4556-9437-1b640d3d08cf	ad434e3f-b929-4ff4-a80d-11feac16b136	MESA BENCH CENTRAL 1.60X1.50X0.74 QUADRA	size	PR-0706-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:39.126	1.2	0.74	153	1.6
25fa5bf4-e914-430b-ae4a-4e8402c3bddf	a0244668-d009-42cf-a2e3-16e02a19e6aa	ad434e3f-b929-4ff4-a80d-11feac16b136	LATERAL MESA BENCH 1.05X1.20X0.74 FRONTAL 75	size	PR-0838-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:39.169	1.2	0.74	154	1.05
bd1814c9-46a6-44cd-ab92-81bcc6f78ee3	c369fbbb-e024-4b2c-915f-8034bc0c3d97	ad434e3f-b929-4ff4-a80d-11feac16b136	LATERAL MESA BENCH 1.05X1.20X0.74 QUADRA FRONTAL 75	size	PR-0839-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:39.208	1.2	0.74	155	1.05
a5cd3768-7eb5-4d3e-adbb-c75f56a0bc4e	5c0d7eb9-23c1-4bed-a617-859d68cc53a1	ad434e3f-b929-4ff4-a80d-11feac16b136	LATERAL MESA BENCH 1.05X1.20X0.74 INCLINADA FRONTAL 75	size	PR-0840-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:39.252	1.2	0.74	156	1.05
7df38ea7-c5cd-45f3-979b-6b84c24ff500	7a074413-4859-4c63-b201-f5202c6b320d	ad434e3f-b929-4ff4-a80d-11feac16b136	LATERAL MESA BENCH 1.05X1.50X0.74 FRONTAL 75	size	PR-0854-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:39.289	1.5	0.74	157	1.05
444ee00f-17b7-4374-8914-10d37555f4d2	1a0d7974-ee17-486d-97b1-14297369167f	ad434e3f-b929-4ff4-a80d-11feac16b136	LATERAL MESA BENCH 1.05X1.50X0.74 QUADRA FRONTAL 75	size	PR-0855-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:39.329	1.5	0.74	158	1.05
82d5a9aa-8006-48f4-afc3-e02684f986a3	82324aa9-e3d8-4b37-aa7e-e5dc2141a42d	ad434e3f-b929-4ff4-a80d-11feac16b136	LATERAL MESA BENCH 1.05X1.50X0.74 INCLINADA FRONTAL 75	size	PR-0856-**/**	{"unit": "m", "brand": "PEME"}	t	2026-03-30 22:21:39.373	1.5	0.74	159	1.05
\.


--
-- TOC entry 3915 (class 0 OID 16659)
-- Dependencies: 241
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.products (id, tenant_id, line_id, category_id, sku, name, description, width, depth, height, active, status, metadata) FROM stdin;
705bc497-70b8-4c51-ab25-340efcb1b26a	ad434e3f-b929-4ff4-a80d-11feac16b136	05df24a7-3b52-4460-94b0-3b53ee84cfca	\N	OHM-51001	ISABELA 	\N	1.2	0.8	0.75	f	DRAFT	\N
214c5e59-79a2-4841-868d-a7f14f72ad99	843c9ed9-5fce-4111-9839-34949786bed8	6ad8a902-6241-4b97-9044-54bc7b53753d	b1c32b8f-7e94-427e-80aa-66a5fcdc2c27	LOC-TEST-100	Locker Industrial Test	Locker industrial de prueba calibre 22	0.38	0.45	1.8	t	PUBLISHED	{"unit": "pza", "brand": "MetalPro"}
2815adb2-fea4-49b8-b9c9-1d9998bc0691	843c9ed9-5fce-4111-9839-34949786bed8	82ca08f5-d107-4477-b63b-9a09417bc60d	15017834-be2a-4479-ac58-11fbe2275bce	ESC-TEST-200	Escritorio Operativo Test	Escritorio con cajones de prueba	1.2	0.6	0.75	t	PUBLISHED	{"unit": "pza", "brand": "OfiLine"}
78ce3850-8629-4e56-94ad-61c0f69d1b91	843c9ed9-5fce-4111-9839-34949786bed8	3e80c50b-e8ee-4014-94f5-e951cb4b724a	15017834-be2a-4479-ac58-11fbe2275bce	SIL-TEST-300	Silla Ejecutiva Test	Silla ejecutiva de prueba	0.65	0.68	1.25	t	PUBLISHED	{"unit": "pza", "brand": "ErgoMax"}
8a291cf9-eb81-4404-a35c-0a3859efa369	ad434e3f-b929-4ff4-a80d-11feac16b136	05df24a7-3b52-4460-94b0-3b53ee84cfca	\N	7	silla 2	\N	1.2	0.8	0.75	f	DRAFT	\N
ce9b345f-d110-475b-9d57-57448ecef2b7	ad434e3f-b929-4ff4-a80d-11feac16b136	05df24a7-3b52-4460-94b0-3b53ee84cfca	\N	SKP	EXTENSION ESCRITORIO 106 C- PEDESTAL DERECHO	\N	1.2	0.8	0.75	f	DRAFT	\N
a18ee5db-cad6-45cb-a472-37975cdecc02	ad434e3f-b929-4ff4-a80d-11feac16b136	417393ce-4f25-4fad-8354-adb71a1bc9f9	b7c9f6df-ec51-4fd1-a7c3-5b12acae225a	PR-1509-**/**	MESA SENCILLA INICIAL 1.20X0.60X0.74 QUADRA	MESA SENCILLA INICIAL	1.2	0.6	0.74	t	PUBLISHED	{"unit": "m", "brand": "PEME"}
a65fd618-c46b-4f3a-89a5-016987a46e53	ad434e3f-b929-4ff4-a80d-11feac16b136	417393ce-4f25-4fad-8354-adb71a1bc9f9	b7c9f6df-ec51-4fd1-a7c3-5b12acae225a	PR-0021-**/**	MESA SENCILLA INICIAL 1.20X0.60X0.74 INCLINADA	MESA SENCILLA INICIAL	1.2	0.6	0.74	t	PUBLISHED	{"unit": "m", "brand": "PEME"}
8f35dd7b-cb84-4b7a-9c17-9de37fdbcf0c	ad434e3f-b929-4ff4-a80d-11feac16b136	417393ce-4f25-4fad-8354-adb71a1bc9f9	b7c9f6df-ec51-4fd1-a7c3-5b12acae225a	PR-0022-**/**	MESA SENCILLA INICIAL 1.20X0.60X0.74 SEMI INCLINADA	MESA SENCILLA INICIAL	1.2	0.6	0.74	t	PUBLISHED	{"unit": "m", "brand": "PEME"}
ebef8308-ebb5-4b75-b25e-0d648cf244ec	ad434e3f-b929-4ff4-a80d-11feac16b136	417393ce-4f25-4fad-8354-adb71a1bc9f9	b7c9f6df-ec51-4fd1-a7c3-5b12acae225a	PR-0279-**/**	MESA SENCILLA ADICIONAL 1.20X0.60X0.74	MESA SENCILLA ADICIONAL	1.2	0.6	0.74	t	PUBLISHED	{"unit": "m", "brand": "PEME"}
f8c7e1aa-6839-4b19-b028-4f59d51bc095	ad434e3f-b929-4ff4-a80d-11feac16b136	417393ce-4f25-4fad-8354-adb71a1bc9f9	b7c9f6df-ec51-4fd1-a7c3-5b12acae225a	PR-0280-**/**	MESA SENCILLA ADICIONAL 1.20X0.60X0.74 QUADRA	MESA SENCILLA ADICIONAL	1.2	0.6	0.74	t	PUBLISHED	{"unit": "m", "brand": "PEME"}
be7e9360-211f-46a7-b1e6-9e5fa0d486e7	ad434e3f-b929-4ff4-a80d-11feac16b136	417393ce-4f25-4fad-8354-adb71a1bc9f9	b7c9f6df-ec51-4fd1-a7c3-5b12acae225a	PR-0281-**/**	MESA SENCILLA ADICIONAL 1.20X0.60X0.74 INCLINADA	MESA SENCILLA ADICIONAL	1.2	0.6	0.74	t	PUBLISHED	{"unit": "m", "brand": "PEME"}
b15298f9-bfa6-455f-8c61-b2dc71a0028e	ad434e3f-b929-4ff4-a80d-11feac16b136	417393ce-4f25-4fad-8354-adb71a1bc9f9	b7c9f6df-ec51-4fd1-a7c3-5b12acae225a	PR-0282-**/**	MESA SENCILLA ADICIONAL 1.20X0.60X0.74 SEMI INCLINADA	MESA SENCILLA ADICIONAL	1.2	0.6	0.74	t	PUBLISHED	{"unit": "m", "brand": "PEME"}
06c7a87d-5bbf-48ec-9a65-899b069cf396	ad434e3f-b929-4ff4-a80d-11feac16b136	417393ce-4f25-4fad-8354-adb71a1bc9f9	60fe4a3f-fac0-4c98-8875-dfb56b9d3cd4	PR-0723-**/**	LATERAL MESA SENCILLA 0.90X0.60X0.74 FRONTAL 60	LATERAL MESA SENCILLA	0.9	0.6	0.74	t	PUBLISHED	{"unit": "m", "brand": "PEME"}
37c02803-58c5-45c1-941a-e2bf55cc7a8d	ad434e3f-b929-4ff4-a80d-11feac16b136	417393ce-4f25-4fad-8354-adb71a1bc9f9	60fe4a3f-fac0-4c98-8875-dfb56b9d3cd4	PR-0724-**/**	LATERAL MESA SENCILLA 0.90X0.60X0.74 QUADRA FRONTAL 60	LATERAL MESA SENCILLA	0.9	0.6	0.74	t	PUBLISHED	{"unit": "m", "brand": "PEME"}
74121cef-f590-4d31-a33e-32c92ef65fd8	ad434e3f-b929-4ff4-a80d-11feac16b136	417393ce-4f25-4fad-8354-adb71a1bc9f9	60fe4a3f-fac0-4c98-8875-dfb56b9d3cd4	PR-0725-**/**	LATERAL MESA SENCILLA 0.90X0.60X0.74 INCLINADA FRONTAL 60	LATERAL MESA SENCILLA	0.9	0.6	0.74	t	PUBLISHED	{"unit": "m", "brand": "PEME"}
6407104f-cf91-4ada-8daa-ba613ced763e	ad434e3f-b929-4ff4-a80d-11feac16b136	417393ce-4f25-4fad-8354-adb71a1bc9f9	60fe4a3f-fac0-4c98-8875-dfb56b9d3cd4	PR-0726-**/**	LATERAL MESA SENCILLA 0.90X0.60X0.74 SEMI INCLINADA FRONTAL 60	LATERAL MESA SENCILLA	0.9	0.6	0.74	t	PUBLISHED	{"unit": "m", "brand": "PEME"}
93b0a71f-5e96-4ddb-b6bf-76ebd51d44eb	ad434e3f-b929-4ff4-a80d-11feac16b136	417393ce-4f25-4fad-8354-adb71a1bc9f9	60fe4a3f-fac0-4c98-8875-dfb56b9d3cd4	PR-0739-**/**	LATERAL MESA SENCILLA 0.90X0.75X0.74 FRONTAL 60	LATERAL MESA SENCILLA	0.9	0.75	0.74	t	PUBLISHED	{"unit": "m", "brand": "PEME"}
6671b2b0-0dd0-481f-92f9-1a8b63183027	ad434e3f-b929-4ff4-a80d-11feac16b136	417393ce-4f25-4fad-8354-adb71a1bc9f9	60fe4a3f-fac0-4c98-8875-dfb56b9d3cd4	PR-0740-**/**	LATERAL MESA SENCILLA 0.90X0.75X0.74 QUADRA FRONTAL 60	LATERAL MESA SENCILLA	0.9	0.75	0.74	t	PUBLISHED	{"unit": "m", "brand": "PEME"}
87dd282b-52da-4ff9-8998-5b825b13c5c9	ad434e3f-b929-4ff4-a80d-11feac16b136	417393ce-4f25-4fad-8354-adb71a1bc9f9	60fe4a3f-fac0-4c98-8875-dfb56b9d3cd4	PR-0741-**/**	LATERAL MESA SENCILLA 0.90X0.75X0.74 INCLINADA FRONTAL 60	LATERAL MESA SENCILLA	0.9	0.75	0.74	t	PUBLISHED	{"unit": "m", "brand": "PEME"}
879eda6d-128f-4680-b285-53bab6334a3e	ad434e3f-b929-4ff4-a80d-11feac16b136	417393ce-4f25-4fad-8354-adb71a1bc9f9	60fe4a3f-fac0-4c98-8875-dfb56b9d3cd4	PR-0742-**/**	LATERAL MESA SENCILLA 0.90X0.75X0.74 SEMI INCLINADA FRONTAL 60	LATERAL MESA SENCILLA	0.9	0.75	0.74	t	PUBLISHED	{"unit": "m", "brand": "PEME"}
ada8d0ac-6b3d-46a8-ac98-8a1b1192a7ae	ad434e3f-b929-4ff4-a80d-11feac16b136	417393ce-4f25-4fad-8354-adb71a1bc9f9	b7c9f6df-ec51-4fd1-a7c3-5b12acae225a	PR-0139-**/**	MESA SENCILLA INICIAL 1.20X0.75X0.74	MESA SENCILLA INICIAL	1.2	0.75	0.74	t	PUBLISHED	{"unit": "m", "brand": "PEME"}
e934b4ff-1597-44df-8d7f-640c6d7e8707	ad434e3f-b929-4ff4-a80d-11feac16b136	417393ce-4f25-4fad-8354-adb71a1bc9f9	b7c9f6df-ec51-4fd1-a7c3-5b12acae225a	PR-0140-**/**	MESA SENCILLA INICIAL 1.20X0.75X0.74 QUADRA	MESA SENCILLA INICIAL	1.2	0.75	0.74	t	PUBLISHED	{"unit": "m", "brand": "PEME"}
e70096db-3db2-4fc3-a7c4-cfd2028cb73a	ad434e3f-b929-4ff4-a80d-11feac16b136	05df24a7-3b52-4460-94b0-3b53ee84cfca	\N	maya 	gondola  	\N	1.2	0.8	0.75	f	DRAFT	\N
8f63d311-722f-4b90-b890-fe271b51a9b4	ad434e3f-b929-4ff4-a80d-11feac16b136	417393ce-4f25-4fad-8354-adb71a1bc9f9	b7c9f6df-ec51-4fd1-a7c3-5b12acae225a	PR-0142-**/**	MESA SENCILLA INICIAL 1.20X0.75X0.74 SEMI INCLINADA	MESA SENCILLA INICIAL	1.2	0.75	0.74	t	PUBLISHED	{"unit": "m", "brand": "PEME"}
1b778817-d9ab-428b-bdf1-9ebe3ed039ae	ad434e3f-b929-4ff4-a80d-11feac16b136	417393ce-4f25-4fad-8354-adb71a1bc9f9	b7c9f6df-ec51-4fd1-a7c3-5b12acae225a	PR-0379-**/**	MESA SENCILLA ADICIONAL 1.20X0.75X0.74	MESA SENCILLA ADICIONAL	1.2	0.75	0.74	t	PUBLISHED	{"unit": "m", "brand": "PEME"}
e6e416d8-32ee-409e-9816-17c5e6f8b420	ad434e3f-b929-4ff4-a80d-11feac16b136	417393ce-4f25-4fad-8354-adb71a1bc9f9	b7c9f6df-ec51-4fd1-a7c3-5b12acae225a	PR-0380-**/**	MESA SENCILLA ADICIONAL 1.20X0.75X0.74 QUADRA	MESA SENCILLA ADICIONAL	1.2	0.75	0.74	t	PUBLISHED	{"unit": "m", "brand": "PEME"}
fc47eeb3-86e6-4a97-8964-821b5861a39d	ad434e3f-b929-4ff4-a80d-11feac16b136	417393ce-4f25-4fad-8354-adb71a1bc9f9	b7c9f6df-ec51-4fd1-a7c3-5b12acae225a	PR-0381-**/**	MESA SENCILLA ADICIONAL 1.20X0.75X0.74 INCLINADA	MESA SENCILLA ADICIONAL	1.2	0.75	0.74	t	PUBLISHED	{"unit": "m", "brand": "PEME"}
4cb2e968-181c-4d39-be42-ef153c26cc63	ad434e3f-b929-4ff4-a80d-11feac16b136	417393ce-4f25-4fad-8354-adb71a1bc9f9	b7c9f6df-ec51-4fd1-a7c3-5b12acae225a	PR-0382-**/**	MESA SENCILLA ADICIONAL 1.20X0.75X0.74 SEMI INCLINADA	MESA SENCILLA ADICIONAL	1.2	0.75	0.74	t	PUBLISHED	{"unit": "m", "brand": "PEME"}
d9bc9698-afef-47a5-b7a9-226ed87f142a	ad434e3f-b929-4ff4-a80d-11feac16b136	417393ce-4f25-4fad-8354-adb71a1bc9f9	60fe4a3f-fac0-4c98-8875-dfb56b9d3cd4	PR-0719-**/**	LATERAL MESA SENCILLA 0.75X0.60X0.74 FRONTAL 75	LATERAL MESA SENCILLA	0.75	0.6	0.74	t	PUBLISHED	{"unit": "m", "brand": "PEME"}
61ccce64-d1d1-4e44-b290-287fcddf40cc	ad434e3f-b929-4ff4-a80d-11feac16b136	417393ce-4f25-4fad-8354-adb71a1bc9f9	60fe4a3f-fac0-4c98-8875-dfb56b9d3cd4	PR-0720-**/**	LATERAL MESA SENCILLA 0.75X0.60X0.74 QUADRA FRONTAL 75	LATERAL MESA SENCILLA	0.75	0.6	0.74	t	PUBLISHED	{"unit": "m", "brand": "PEME"}
5d3decde-b899-4682-9dc6-d4cb91338e7a	ad434e3f-b929-4ff4-a80d-11feac16b136	417393ce-4f25-4fad-8354-adb71a1bc9f9	60fe4a3f-fac0-4c98-8875-dfb56b9d3cd4	PR-0721-**/**	LATERAL MESA SENCILLA 0.75X0.60X0.74 INCLINADA FRONTAL 75	LATERAL MESA SENCILLA	0.75	0.6	0.74	t	PUBLISHED	{"unit": "m", "brand": "PEME"}
7595d52a-b509-4c49-9d77-87b8a8c0e0d5	ad434e3f-b929-4ff4-a80d-11feac16b136	417393ce-4f25-4fad-8354-adb71a1bc9f9	60fe4a3f-fac0-4c98-8875-dfb56b9d3cd4	PR-0722-**/**	LATERAL MESA SENCILLA 0.75X0.60X0.74 SEMI INCLINADA FRONTAL 75	LATERAL MESA SENCILLA	0.75	0.6	0.74	t	PUBLISHED	{"unit": "m", "brand": "PEME"}
37ae24e2-6337-4eaf-916b-9f1a9f8252c9	ad434e3f-b929-4ff4-a80d-11feac16b136	417393ce-4f25-4fad-8354-adb71a1bc9f9	60fe4a3f-fac0-4c98-8875-dfb56b9d3cd4	PR-0735-**/**	LATERAL MESA SENCILLA 0.75X0.75X0.74 FRONTAL 75	LATERAL MESA SENCILLA	0.75	0.75	0.74	t	PUBLISHED	{"unit": "m", "brand": "PEME"}
4d35c1d2-e088-4393-b2fb-ed2e7b7b511d	ad434e3f-b929-4ff4-a80d-11feac16b136	417393ce-4f25-4fad-8354-adb71a1bc9f9	60fe4a3f-fac0-4c98-8875-dfb56b9d3cd4	PR-0736-**/**	LATERAL MESA SENCILLA 0.75X0.75X0.74 QUADRA FRONTAL 75	LATERAL MESA SENCILLA	0.75	0.75	0.74	t	PUBLISHED	{"unit": "m", "brand": "PEME"}
ab6dd978-ac6b-4d6c-b43e-393cfc8f1f38	ad434e3f-b929-4ff4-a80d-11feac16b136	417393ce-4f25-4fad-8354-adb71a1bc9f9	60fe4a3f-fac0-4c98-8875-dfb56b9d3cd4	PR-0737-**/**	LATERAL MESA SENCILLA 0.75X0.75X0.74 INCLINADA FRONTAL 75	LATERAL MESA SENCILLA	0.75	0.75	0.74	t	PUBLISHED	{"unit": "m", "brand": "PEME"}
e8b0d497-0784-48dc-9622-fa1c0ff0afc6	ad434e3f-b929-4ff4-a80d-11feac16b136	417393ce-4f25-4fad-8354-adb71a1bc9f9	60fe4a3f-fac0-4c98-8875-dfb56b9d3cd4	PR-0738-**/**	LATERAL MESA SENCILLA 0.75X0.75X0.74 SEMI INCLINADA FRONTAL 75	LATERAL MESA SENCILLA	0.75	0.75	0.74	t	PUBLISHED	{"unit": "m", "brand": "PEME"}
e4bc3270-0a38-461e-a321-211a7ebd94b3	ad434e3f-b929-4ff4-a80d-11feac16b136	417393ce-4f25-4fad-8354-adb71a1bc9f9	c1efe4aa-f5e3-4a5a-86ad-4c41a98d6945	PR-0499-**/**	MESA BENCH INICIAL 1.20X1.20X0.74	MESA BENCH INICIAL	1.2	1.2	0.74	t	PUBLISHED	{"unit": "m", "brand": "PEME"}
d6d4bb71-ab21-43b4-9187-41dc7eb19dc1	ad434e3f-b929-4ff4-a80d-11feac16b136	417393ce-4f25-4fad-8354-adb71a1bc9f9	c1efe4aa-f5e3-4a5a-86ad-4c41a98d6945	PR-0500-**/**	MESA BENCH INICIAL 1.20X1.20X0.74 QUADRA	MESA BENCH INICIAL	1.2	1.2	0.74	t	PUBLISHED	{"unit": "m", "brand": "PEME"}
26d54ae1-6589-404b-b97e-5844a49a4126	ad434e3f-b929-4ff4-a80d-11feac16b136	417393ce-4f25-4fad-8354-adb71a1bc9f9	c1efe4aa-f5e3-4a5a-86ad-4c41a98d6945	PR-0501-**/**	MESA BENCH INICIAL 1.20X1.20X0.74 INCLINADA	MESA BENCH INICIAL	1.2	1.2	0.74	t	PUBLISHED	{"unit": "m", "brand": "PEME"}
bcd1b43e-9c32-4fb2-a63a-791fd575e91c	ad434e3f-b929-4ff4-a80d-11feac16b136	417393ce-4f25-4fad-8354-adb71a1bc9f9	c1efe4aa-f5e3-4a5a-86ad-4c41a98d6945	PR-0619-**/**	MESA BENCH ADICIONAL 1.20X1.20X0.74	MESA BENCH ADICIONAL	1.2	1.2	0.74	t	PUBLISHED	{"unit": "m", "brand": "PEME"}
008b256d-38f7-4781-83cf-04b1f624051e	ad434e3f-b929-4ff4-a80d-11feac16b136	417393ce-4f25-4fad-8354-adb71a1bc9f9	c1efe4aa-f5e3-4a5a-86ad-4c41a98d6945	PR-0620-**/**	MESA BENCH ADICIONAL 1.20X1.20X0.74 QUADRA	MESA BENCH ADICIONAL	1.2	1.2	0.74	t	PUBLISHED	{"unit": "m", "brand": "PEME"}
9cca5e76-de22-447c-a1bd-e5d16142d93e	ad434e3f-b929-4ff4-a80d-11feac16b136	417393ce-4f25-4fad-8354-adb71a1bc9f9	c1efe4aa-f5e3-4a5a-86ad-4c41a98d6945	PR-0621-**/**	MESA BENCH ADICIONAL 1.20X1.20X0.74 INCLINADA	MESA BENCH ADICIONAL	1.2	1.2	0.74	t	PUBLISHED	{"unit": "m", "brand": "PEME"}
bd2b7acf-9367-419f-a8b1-7e4053fd4ff9	ad434e3f-b929-4ff4-a80d-11feac16b136	417393ce-4f25-4fad-8354-adb71a1bc9f9	c1efe4aa-f5e3-4a5a-86ad-4c41a98d6945	PR-0679-**/**	MESA BENCH CENTRAL 1.20X1.20X0.74	MESA BENCH CENTRAL	1.2	1.2	0.74	t	PUBLISHED	{"unit": "m", "brand": "PEME"}
86e0de54-1f22-4556-9437-1b640d3d08cf	ad434e3f-b929-4ff4-a80d-11feac16b136	417393ce-4f25-4fad-8354-adb71a1bc9f9	c1efe4aa-f5e3-4a5a-86ad-4c41a98d6945	PR-0680-**/**	MESA BENCH CENTRAL 1.20X1.20X0.74 QUADRA	MESA BENCH CENTRAL	1.2	1.2	0.74	t	PUBLISHED	{"unit": "m", "brand": "PEME"}
a3539472-03d3-4625-831f-246f355c82aa	ad434e3f-b929-4ff4-a80d-11feac16b136	417393ce-4f25-4fad-8354-adb71a1bc9f9	c1efe4aa-f5e3-4a5a-86ad-4c41a98d6945	PR-0834-**/**	LATERAL MESA BENCH 0.90X1.20X0.74 FRONTAL 60	LATERAL MESA BENCH	0.9	1.2	0.74	t	PUBLISHED	{"unit": "m", "brand": "PEME"}
6d125e00-87ce-487a-9ab2-cc15e442d3af	ad434e3f-b929-4ff4-a80d-11feac16b136	417393ce-4f25-4fad-8354-adb71a1bc9f9	c1efe4aa-f5e3-4a5a-86ad-4c41a98d6945	PR-0835-**/**	LATERAL MESA BENCH 0.90X1.20X0.74 QUADRA FRONTAL 60	LATERAL MESA BENCH	0.9	1.2	0.74	t	PUBLISHED	{"unit": "m", "brand": "PEME"}
9a0be7a1-0438-43d4-a43a-13f65ca12b09	ad434e3f-b929-4ff4-a80d-11feac16b136	417393ce-4f25-4fad-8354-adb71a1bc9f9	b7c9f6df-ec51-4fd1-a7c3-5b12acae225a	PR-0019-**/**	MESA SENCILLA INICIAL 1.20X0.60X0.74	MESA SENCILLA INICIAL	1.2	0.6	0.74	t	PUBLISHED	{"unit": "m", "brand": "PEME"}
73f4aef0-f656-4768-9818-07129ee45791	ad434e3f-b929-4ff4-a80d-11feac16b136	417393ce-4f25-4fad-8354-adb71a1bc9f9	b7c9f6df-ec51-4fd1-a7c3-5b12acae225a	PR-0141-**/**	MESA SENCILLA INICIAL 1.20X0.75X0.74 INCLINADA	MESA SENCILLA INICIAL	1.2	0.75	0.74	t	PUBLISHED	{"unit": "m", "brand": "PEME"}
421a93a9-10a5-418f-bb61-8c29065e7a8b	ad434e3f-b929-4ff4-a80d-11feac16b136	417393ce-4f25-4fad-8354-adb71a1bc9f9	c1efe4aa-f5e3-4a5a-86ad-4c41a98d6945	PR-0836-**/**	LATERAL MESA BENCH 0.90X1.20X0.74 INCLINADA FRONTAL 60	LATERAL MESA BENCH	0.9	1.2	0.74	t	PUBLISHED	{"unit": "m", "brand": "PEME"}
083a6238-60db-4b53-8617-f63f09870c1f	ad434e3f-b929-4ff4-a80d-11feac16b136	417393ce-4f25-4fad-8354-adb71a1bc9f9	c1efe4aa-f5e3-4a5a-86ad-4c41a98d6945	PR-0850-**/**	LATERAL MESA BENCH 0.90X1.50X0.74 FRONTAL 60	LATERAL MESA BENCH	0.9	1.5	0.74	t	PUBLISHED	{"unit": "m", "brand": "PEME"}
cf163728-3824-4dae-a07c-4396b0da3382	ad434e3f-b929-4ff4-a80d-11feac16b136	417393ce-4f25-4fad-8354-adb71a1bc9f9	c1efe4aa-f5e3-4a5a-86ad-4c41a98d6945	PR-0851-**/**	LATERAL MESA BENCH 0.90X1.50X0.74 QUADRA FRONTAL 60	LATERAL MESA BENCH	0.9	1.5	0.74	t	PUBLISHED	{"unit": "m", "brand": "PEME"}
9adabc28-d0a0-4175-b24b-0ee84e43d89b	ad434e3f-b929-4ff4-a80d-11feac16b136	417393ce-4f25-4fad-8354-adb71a1bc9f9	c1efe4aa-f5e3-4a5a-86ad-4c41a98d6945	PR-0852-**/**	LATERAL MESA BENCH 0.90X1.50X0.74 INCLINADA FRONTAL 60	LATERAL MESA BENCH	0.9	1.5	0.74	t	PUBLISHED	{"unit": "m", "brand": "PEME"}
5aab8c35-7477-495e-aa07-b6e4f6dbe457	ad434e3f-b929-4ff4-a80d-11feac16b136	417393ce-4f25-4fad-8354-adb71a1bc9f9	c1efe4aa-f5e3-4a5a-86ad-4c41a98d6945	PR-0559-**/**	MESA BENCH INICIAL 1.20X1.50X0.74	MESA BENCH INICIAL	1.2	1.5	0.74	t	PUBLISHED	{"unit": "m", "brand": "PEME"}
a2cec753-8d86-42f4-9f45-16aaf894e4b2	ad434e3f-b929-4ff4-a80d-11feac16b136	417393ce-4f25-4fad-8354-adb71a1bc9f9	c1efe4aa-f5e3-4a5a-86ad-4c41a98d6945	PR-0560-**/**	MESA BENCH INICIAL 1.20X1.50X0.74 QUADRA	MESA BENCH INICIAL	1.2	1.5	0.74	t	PUBLISHED	{"unit": "m", "brand": "PEME"}
4bbf5039-4c8e-4d07-80b1-b36bec5151d0	ad434e3f-b929-4ff4-a80d-11feac16b136	417393ce-4f25-4fad-8354-adb71a1bc9f9	c1efe4aa-f5e3-4a5a-86ad-4c41a98d6945	PR-0561-**/**	MESA BENCH INICIAL 1.20X1.50X0.74 INCLINADA	MESA BENCH INICIAL	1.2	1.5	0.74	t	PUBLISHED	{"unit": "m", "brand": "PEME"}
2ad80db8-2357-474a-8524-b88768b795cf	ad434e3f-b929-4ff4-a80d-11feac16b136	417393ce-4f25-4fad-8354-adb71a1bc9f9	c1efe4aa-f5e3-4a5a-86ad-4c41a98d6945	PR-0708-**/**	MESA BENCH CENTRAL 1.80X1.50X0.74 QUADRA	MESA BENCH A CENTRAL 1.80X1.50X0.74 QUADRA	1.8	1.2	0.74	t	PUBLISHED	{"unit": "m", "brand": "PEME"}
a0244668-d009-42cf-a2e3-16e02a19e6aa	ad434e3f-b929-4ff4-a80d-11feac16b136	417393ce-4f25-4fad-8354-adb71a1bc9f9	c1efe4aa-f5e3-4a5a-86ad-4c41a98d6945	PR-0830-**/**	LATERAL MESA BENCH 0.75X1.20X0.74 FRONTAL 75	LATERAL MESA BENCH	0.75	1.2	0.74	t	PUBLISHED	{"unit": "m", "brand": "PEME"}
c369fbbb-e024-4b2c-915f-8034bc0c3d97	ad434e3f-b929-4ff4-a80d-11feac16b136	417393ce-4f25-4fad-8354-adb71a1bc9f9	c1efe4aa-f5e3-4a5a-86ad-4c41a98d6945	PR-0831-**/**	LATERAL MESA BENCH 0.75X1.20X0.74 QUADRA FRONTAL 75	LATERAL MESA BENCH	0.75	1.2	0.74	t	PUBLISHED	{"unit": "m", "brand": "PEME"}
5c0d7eb9-23c1-4bed-a617-859d68cc53a1	ad434e3f-b929-4ff4-a80d-11feac16b136	417393ce-4f25-4fad-8354-adb71a1bc9f9	c1efe4aa-f5e3-4a5a-86ad-4c41a98d6945	PR-0832-**/**	LATERAL MESA BENCH 0.75X1.20X0.74 INCLINADA FRONTAL 75	LATERAL MESA BENCH	0.75	1.2	0.74	t	PUBLISHED	{"unit": "m", "brand": "PEME"}
7a074413-4859-4c63-b201-f5202c6b320d	ad434e3f-b929-4ff4-a80d-11feac16b136	417393ce-4f25-4fad-8354-adb71a1bc9f9	c1efe4aa-f5e3-4a5a-86ad-4c41a98d6945	PR-0846-**/**	LATERAL MESA BENCH 0.75X1.50X0.74 FRONTAL 75	LATERAL MESA BENCH	0.75	1.5	0.74	t	PUBLISHED	{"unit": "m", "brand": "PEME"}
1a0d7974-ee17-486d-97b1-14297369167f	ad434e3f-b929-4ff4-a80d-11feac16b136	417393ce-4f25-4fad-8354-adb71a1bc9f9	c1efe4aa-f5e3-4a5a-86ad-4c41a98d6945	PR-0847-**/**	LATERAL MESA BENCH 0.75X1.50X0.74 QUADRA FRONTAL 75	LATERAL MESA BENCH	0.75	1.5	0.74	t	PUBLISHED	{"unit": "m", "brand": "PEME"}
82324aa9-e3d8-4b37-aa7e-e5dc2141a42d	ad434e3f-b929-4ff4-a80d-11feac16b136	417393ce-4f25-4fad-8354-adb71a1bc9f9	c1efe4aa-f5e3-4a5a-86ad-4c41a98d6945	PR-0848-**/**	LATERAL MESA BENCH 0.75X1.50X0.74 INCLINADA FRONTAL 75	LATERAL MESA BENCH	0.75	1.5	0.74	t	PUBLISHED	{"unit": "m", "brand": "PEME"}
e4ac4776-1f09-435a-b0e8-14eee92909e9	ad434e3f-b929-4ff4-a80d-11feac16b136	417393ce-4f25-4fad-8354-adb71a1bc9f9	99fef396-baf7-45da-a243-4a3e3c766137	PR-1521	MODULO YOGUI INICIAL TERRA	YOGUI INICIAL	1	1	1	t	PUBLISHED	{"unit": "m", "brand": "PEME"}
88e01dc1-93ce-4ce4-b370-5d72da53f6f0	ad434e3f-b929-4ff4-a80d-11feac16b136	417393ce-4f25-4fad-8354-adb71a1bc9f9	99fef396-baf7-45da-a243-4a3e3c766137	PR-1523	MODULO YOGUI INICIAL QUADRA TERRA	YOGUI INICIAL	1	1	1	t	PUBLISHED	{"unit": "m", "brand": "PEME"}
e15bab3a-f5cf-48de-8ddd-595beb0b19c5	ad434e3f-b929-4ff4-a80d-11feac16b136	417393ce-4f25-4fad-8354-adb71a1bc9f9	99fef396-baf7-45da-a243-4a3e3c766137	PR-1524	MODULO YOGUI INICIAL INCLINADA TERRA	YOGUI INICIAL	1	1	1	t	PUBLISHED	{"unit": "m", "brand": "PEME"}
e90e7af5-db3b-4808-9e35-8121478294c7	ad434e3f-b929-4ff4-a80d-11feac16b136	417393ce-4f25-4fad-8354-adb71a1bc9f9	99fef396-baf7-45da-a243-4a3e3c766137	PR-1522	MODULO YOGUI ADICIONAL TERRA	YOGUI ADICIONAL	1	1	1	t	PUBLISHED	{"unit": "m", "brand": "PEME"}
71510889-5d8f-4f84-bc76-becbd3ca10be	ad434e3f-b929-4ff4-a80d-11feac16b136	417393ce-4f25-4fad-8354-adb71a1bc9f9	99fef396-baf7-45da-a243-4a3e3c766137	PR-1525	MODULO YOGUI ADICIONAL QUADRA TERRA	YOGUI ADICIONAL	1	1	1	t	PUBLISHED	{"unit": "m", "brand": "PEME"}
7a335d35-c7be-4220-8142-1d5b28e22710	ad434e3f-b929-4ff4-a80d-11feac16b136	417393ce-4f25-4fad-8354-adb71a1bc9f9	99fef396-baf7-45da-a243-4a3e3c766137	PR-1526	MODULO YOGUI ADICIONAL INCLINADA TERRA	YOGUI ADICIONAL	1	1	1	t	PUBLISHED	{"unit": "m", "brand": "PEME"}
\.


--
-- TOC entry 3916 (class 0 OID 16666)
-- Dependencies: 242
-- Data for Name: project_versions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.project_versions (id, project_id, "versionNum", scene_state_json, "createdAt", save_mode, scene_hash, summary) FROM stdin;
7550be06-3a79-4ef3-b99a-6c0d94109928	af44d62e-9013-4c9d-9d43-7150b485068a	1	{"faces": [], "items": [{"id": "gi096icyq", "type": "catalog-item", "depth": 0.8, "label": "Escritorio Terra Roble", "scale": [1, 1, 1], "width": 1.6, "height": 0.75, "layerId": "lines", "metadata": {"resizable": true, "model3dUrl": null, "floorAnchor": 0, "forwardAxis": "Z", "scaleFactor": 1}, "position": [0, 0, 0], "rotation": [0, 0, 0], "tenantId": "ad434e3f-b929-4ff4-a80d-11feac16b136", "productId": "fb2a964a-2c4b-4521-9515-f4c734e8565c", "resizable": true, "model3dUrl": null, "snapPoints": [], "floorAnchor": 0, "hasPriceAccess": true}, {"id": "kpeu51fed", "type": "catalog-item", "depth": 0.45, "label": "Locker 4 Compartimentos", "scale": [1, 1, 1], "width": 0.9, "height": 1.85, "layerId": "lines", "metadata": {"resizable": true, "model3dUrl": null, "floorAnchor": 0, "forwardAxis": "Z", "scaleFactor": 1}, "position": [0, 0, 0], "rotation": [0, 0, 0], "tenantId": "ad434e3f-b929-4ff4-a80d-11feac16b136", "productId": "abb900bc-ac69-43f5-a10d-54c0fee97a29", "resizable": true, "model3dUrl": null, "snapPoints": [], "floorAnchor": 0, "hasPriceAccess": true}, {"id": "y9mkz0hgt", "type": "catalog-item", "depth": 0.45, "label": "Locker 4 Compartimentos", "scale": [1, 1, 1], "width": 0.9, "height": 1.85, "layerId": "lines", "metadata": {"resizable": true, "model3dUrl": null, "floorAnchor": 0, "forwardAxis": "Z", "scaleFactor": 1}, "position": [0.5, 0, 0.5], "rotation": [0, 0, 0], "tenantId": "ad434e3f-b929-4ff4-a80d-11feac16b136", "productId": "abb900bc-ac69-43f5-a10d-54c0fee97a29", "resizable": true, "model3dUrl": null, "snapPoints": [], "floorAnchor": 0, "hasPriceAccess": true}], "lines": [], "walls": [], "groups": [], "layers": [{"id": "walls", "name": "Muros", "locked": false, "visible": true}, {"id": "openings", "name": "Huecos", "locked": false, "visible": true}, {"id": "assets", "name": "Objetos", "locked": false, "visible": true}, {"id": "dimensions", "name": "Dimensiones", "locked": false, "visible": true}, {"id": "lines", "name": "Líneas de boceto", "locked": false, "visible": true}, {"id": "rectangles", "name": "Rectángulos", "locked": false, "visible": true}, {"id": "faces", "name": "Caras", "locked": false, "visible": true}, {"id": "volumes", "name": "Volúmenes", "locked": false, "visible": true}], "scenes": [], "volumes": [], "openings": [], "blueprint": {"url": null, "scale": 1, "locked": false, "opacity": 0.5, "visible": true, "position": [0, -0.01, 0], "rotation": 0}, "dimensions": [], "rectangles": []}	2026-03-27 04:41:05.479	autosave	\N	\N
1e26de7b-846a-4b57-a30a-25712d8a1c93	36b6ba7b-4b64-4171-9ab1-375c14d277e9	1	{"faces": [], "items": [{"id": "gi096icyq", "type": "catalog-item", "depth": 0.8, "label": "Escritorio Terra Roble", "scale": [1, 1, 1], "width": 1.6, "height": 0.75, "layerId": "lines", "metadata": {"resizable": true, "model3dUrl": null, "floorAnchor": 0, "forwardAxis": "Z", "scaleFactor": 1}, "position": [0, 0, 0], "rotation": [0, 0, 0], "tenantId": "ad434e3f-b929-4ff4-a80d-11feac16b136", "productId": "fb2a964a-2c4b-4521-9515-f4c734e8565c", "resizable": true, "model3dUrl": null, "snapPoints": [], "floorAnchor": 0, "hasPriceAccess": true}, {"id": "kpeu51fed", "type": "catalog-item", "depth": 0.45, "label": "Locker 4 Compartimentos", "scale": [1, 1, 1], "width": 0.9, "height": 1.85, "layerId": "lines", "metadata": {"resizable": true, "model3dUrl": null, "floorAnchor": 0, "forwardAxis": "Z", "scaleFactor": 1}, "position": [0, 0, 0], "rotation": [0, 0, 0], "tenantId": "ad434e3f-b929-4ff4-a80d-11feac16b136", "productId": "abb900bc-ac69-43f5-a10d-54c0fee97a29", "resizable": true, "model3dUrl": null, "snapPoints": [], "floorAnchor": 0, "hasPriceAccess": true}, {"id": "y9mkz0hgt", "type": "catalog-item", "depth": 0.45, "label": "Locker 4 Compartimentos", "scale": [1, 1, 1], "width": 0.9, "height": 1.85, "layerId": "lines", "metadata": {"resizable": true, "model3dUrl": null, "floorAnchor": 0, "forwardAxis": "Z", "scaleFactor": 1}, "position": [0.5, 0, 0.5], "rotation": [0, 0, 0], "tenantId": "ad434e3f-b929-4ff4-a80d-11feac16b136", "productId": "abb900bc-ac69-43f5-a10d-54c0fee97a29", "resizable": true, "model3dUrl": null, "snapPoints": [], "floorAnchor": 0, "hasPriceAccess": true}], "lines": [], "walls": [], "groups": [], "layers": [{"id": "walls", "name": "Muros", "locked": false, "visible": true}, {"id": "openings", "name": "Huecos", "locked": false, "visible": true}, {"id": "assets", "name": "Objetos", "locked": false, "visible": true}, {"id": "dimensions", "name": "Dimensiones", "locked": false, "visible": true}, {"id": "lines", "name": "Líneas de boceto", "locked": false, "visible": true}, {"id": "rectangles", "name": "Rectángulos", "locked": false, "visible": true}, {"id": "faces", "name": "Caras", "locked": false, "visible": true}, {"id": "volumes", "name": "Volúmenes", "locked": false, "visible": true}], "scenes": [], "volumes": [], "openings": [], "blueprint": {"url": null, "scale": 1, "locked": false, "opacity": 0.5, "visible": true, "position": [0, -0.01, 0], "rotation": 0}, "dimensions": [], "rectangles": []}	2026-03-27 04:41:21.568	autosave	\N	\N
95d9aa50-7dfd-45c4-a661-8fc27609ca35	af44d62e-9013-4c9d-9d43-7150b485068a	2	{"faces": [], "items": [{"id": "gi096icyq", "type": "catalog-item", "depth": 0.8, "label": "Escritorio Terra Roble", "scale": [1, 1, 1], "width": 1.6, "height": 0.75, "layerId": "lines", "metadata": {"resizable": true, "model3dUrl": null, "floorAnchor": 0, "forwardAxis": "Z", "scaleFactor": 1}, "position": [-1.75, 0, -0.125], "rotation": [0, 0, 0], "tenantId": "ad434e3f-b929-4ff4-a80d-11feac16b136", "productId": "fb2a964a-2c4b-4521-9515-f4c734e8565c", "resizable": true, "model3dUrl": null, "snapPoints": [], "floorAnchor": 0, "hasPriceAccess": true}, {"id": "kpeu51fed", "type": "catalog-item", "depth": 0.45, "label": "Locker 4 Compartimentos", "scale": [1, 1, 1], "width": 0.9, "height": 1.85, "layerId": "lines", "metadata": {"resizable": true, "model3dUrl": null, "floorAnchor": 0, "forwardAxis": "Z", "scaleFactor": 1}, "position": [-1.75, 0, 1.125], "rotation": [0, 0, 0], "tenantId": "ad434e3f-b929-4ff4-a80d-11feac16b136", "productId": "abb900bc-ac69-43f5-a10d-54c0fee97a29", "resizable": true, "model3dUrl": null, "snapPoints": [], "floorAnchor": 0, "hasPriceAccess": true}, {"id": "y9mkz0hgt", "type": "catalog-item", "depth": 0.45, "label": "Locker 4 Compartimentos", "scale": [1, 1, 1], "width": 0.9, "height": 1.85, "layerId": "lines", "metadata": {"resizable": true, "model3dUrl": null, "floorAnchor": 0, "forwardAxis": "Z", "scaleFactor": 1}, "position": [-1.25, 0, 0.375], "rotation": [0, 0, 0], "tenantId": "ad434e3f-b929-4ff4-a80d-11feac16b136", "productId": "abb900bc-ac69-43f5-a10d-54c0fee97a29", "resizable": true, "model3dUrl": null, "snapPoints": [], "floorAnchor": 0, "hasPriceAccess": true}, {"id": "j3bninyzr", "type": "catalog-item", "depth": 0.8, "label": "Escritorio Terra Roble", "scale": [1, 1, 1], "width": 1.6, "height": 0.75, "layerId": "lines", "metadata": {"resizable": true, "model3dUrl": null, "floorAnchor": 0, "forwardAxis": "Z", "scaleFactor": 1}, "position": [3.25, 0, 0.375], "rotation": [0, 0, 0], "tenantId": "ad434e3f-b929-4ff4-a80d-11feac16b136", "productId": "fb2a964a-2c4b-4521-9515-f4c734e8565c", "resizable": true, "model3dUrl": null, "snapPoints": [], "floorAnchor": 0, "hasPriceAccess": true}, {"id": "3pqcwf7ug", "type": "catalog-item", "depth": 0.45, "label": "Locker 4 Compartimentos", "scale": [1, 1, 1], "width": 0.9, "height": 1.85, "layerId": "lines", "metadata": {"resizable": true, "model3dUrl": null, "floorAnchor": 0, "forwardAxis": "Z", "scaleFactor": 1}, "position": [3.25, 0, 1.625], "rotation": [0, 0, 0], "tenantId": "ad434e3f-b929-4ff4-a80d-11feac16b136", "productId": "abb900bc-ac69-43f5-a10d-54c0fee97a29", "resizable": true, "model3dUrl": null, "snapPoints": [], "floorAnchor": 0, "hasPriceAccess": true}, {"id": "omxz9aq6u", "type": "catalog-item", "depth": 0.45, "label": "Locker 4 Compartimentos", "scale": [1, 1, 1], "width": 0.9, "height": 1.85, "layerId": "lines", "metadata": {"resizable": true, "model3dUrl": null, "floorAnchor": 0, "forwardAxis": "Z", "scaleFactor": 1}, "position": [3.75, 0, 0.875], "rotation": [0, 0, 0], "tenantId": "ad434e3f-b929-4ff4-a80d-11feac16b136", "productId": "abb900bc-ac69-43f5-a10d-54c0fee97a29", "resizable": true, "model3dUrl": null, "snapPoints": [], "floorAnchor": 0, "hasPriceAccess": true}, {"id": "i3ej31p5f", "type": "catalog-item", "depth": 0.8, "label": "Escritorio Terra Roble", "scale": [1, 1, 1], "width": 1.6, "height": 0.75, "layerId": "lines", "metadata": {"resizable": true, "model3dUrl": null, "floorAnchor": 0, "forwardAxis": "Z", "scaleFactor": 1}, "position": [-0.25, 0, 1.875], "rotation": [0, 0, 0], "tenantId": "ad434e3f-b929-4ff4-a80d-11feac16b136", "productId": "fb2a964a-2c4b-4521-9515-f4c734e8565c", "resizable": true, "model3dUrl": null, "snapPoints": [], "floorAnchor": 0, "hasPriceAccess": true}, {"id": "saykn9ab7", "type": "catalog-item", "depth": 0.45, "label": "Locker 4 Compartimentos", "scale": [1, 1, 1], "width": 0.9, "height": 1.85, "layerId": "lines", "metadata": {"resizable": true, "model3dUrl": null, "floorAnchor": 0, "forwardAxis": "Z", "scaleFactor": 1}, "position": [-0.25, 0, 3.125], "rotation": [0, 0, 0], "tenantId": "ad434e3f-b929-4ff4-a80d-11feac16b136", "productId": "abb900bc-ac69-43f5-a10d-54c0fee97a29", "resizable": true, "model3dUrl": null, "snapPoints": [], "floorAnchor": 0, "hasPriceAccess": true}, {"id": "362e2abhp", "type": "catalog-item", "depth": 0.45, "label": "Locker 4 Compartimentos", "scale": [1, 1, 1], "width": 0.9, "height": 1.85, "layerId": "lines", "metadata": {"resizable": true, "model3dUrl": null, "floorAnchor": 0, "forwardAxis": "Z", "scaleFactor": 1}, "position": [0.25, 0, 2.375], "rotation": [0, 0, 0], "tenantId": "ad434e3f-b929-4ff4-a80d-11feac16b136", "productId": "abb900bc-ac69-43f5-a10d-54c0fee97a29", "resizable": true, "model3dUrl": null, "snapPoints": [], "floorAnchor": 0, "hasPriceAccess": true}], "lines": [], "walls": [], "groups": [], "layers": [{"id": "walls", "name": "Muros", "locked": false, "visible": true}, {"id": "openings", "name": "Huecos", "locked": false, "visible": true}, {"id": "assets", "name": "Objetos", "locked": false, "visible": true}, {"id": "dimensions", "name": "Dimensiones", "locked": false, "visible": true}, {"id": "lines", "name": "Líneas de boceto", "locked": false, "visible": true}, {"id": "rectangles", "name": "Rectángulos", "locked": false, "visible": true}, {"id": "faces", "name": "Caras", "locked": false, "visible": true}, {"id": "volumes", "name": "Volúmenes", "locked": false, "visible": true}], "scenes": [], "volumes": [], "openings": [], "blueprint": {"url": null, "scale": 1, "locked": false, "opacity": 0.5, "visible": true, "position": [0, -0.01, 0], "rotation": 0}, "dimensions": [], "rectangles": []}	2026-03-27 04:43:01.214	autosave	\N	\N
c0ae1046-07bf-46fa-a4a0-ca45b8ec849c	af44d62e-9013-4c9d-9d43-7150b485068a	3	{"faces": [], "items": [{"id": "gi096icyq", "type": "catalog-item", "depth": 0.8, "label": "Escritorio Terra Roble", "scale": [1, 1, 1], "width": 1.6, "height": 0.75, "layerId": "lines", "metadata": {"resizable": true, "model3dUrl": null, "floorAnchor": 0, "forwardAxis": "Z", "scaleFactor": 1}, "position": [-1.75, 0, -0.125], "rotation": [0, 0, 0], "tenantId": "ad434e3f-b929-4ff4-a80d-11feac16b136", "productId": "fb2a964a-2c4b-4521-9515-f4c734e8565c", "resizable": true, "model3dUrl": null, "snapPoints": [], "floorAnchor": 0, "hasPriceAccess": true}, {"id": "kpeu51fed", "type": "catalog-item", "depth": 0.45, "label": "Locker 4 Compartimentos", "scale": [1, 1, 1], "width": 0.9, "height": 1.85, "layerId": "lines", "metadata": {"resizable": true, "model3dUrl": null, "floorAnchor": 0, "forwardAxis": "Z", "scaleFactor": 1}, "position": [-1.75, 0, 1.125], "rotation": [0, 0, 0], "tenantId": "ad434e3f-b929-4ff4-a80d-11feac16b136", "productId": "abb900bc-ac69-43f5-a10d-54c0fee97a29", "resizable": true, "model3dUrl": null, "snapPoints": [], "floorAnchor": 0, "hasPriceAccess": true}, {"id": "y9mkz0hgt", "type": "catalog-item", "depth": 0.45, "label": "Locker 4 Compartimentos", "scale": [1, 1, 1], "width": 0.9, "height": 1.85, "layerId": "lines", "metadata": {"resizable": true, "model3dUrl": null, "floorAnchor": 0, "forwardAxis": "Z", "scaleFactor": 1}, "position": [-1.25, 0, 0.375], "rotation": [0, 0, 0], "tenantId": "ad434e3f-b929-4ff4-a80d-11feac16b136", "productId": "abb900bc-ac69-43f5-a10d-54c0fee97a29", "resizable": true, "model3dUrl": null, "snapPoints": [], "floorAnchor": 0, "hasPriceAccess": true}, {"id": "j3bninyzr", "type": "catalog-item", "depth": 0.8, "label": "Escritorio Terra Roble", "scale": [1, 1, 1], "width": 1.6, "height": 0.75, "layerId": "lines", "metadata": {"resizable": true, "model3dUrl": null, "floorAnchor": 0, "forwardAxis": "Z", "scaleFactor": 1}, "position": [3.25, 0, 0.375], "rotation": [0, 0, 0], "tenantId": "ad434e3f-b929-4ff4-a80d-11feac16b136", "productId": "fb2a964a-2c4b-4521-9515-f4c734e8565c", "resizable": true, "model3dUrl": null, "snapPoints": [], "floorAnchor": 0, "hasPriceAccess": true}, {"id": "3pqcwf7ug", "type": "catalog-item", "depth": 0.45, "label": "Locker 4 Compartimentos", "scale": [1, 1, 1], "width": 0.9, "height": 1.85, "layerId": "lines", "metadata": {"resizable": true, "model3dUrl": null, "floorAnchor": 0, "forwardAxis": "Z", "scaleFactor": 1}, "position": [3.25, 0, 1.625], "rotation": [0, 0, 0], "tenantId": "ad434e3f-b929-4ff4-a80d-11feac16b136", "productId": "abb900bc-ac69-43f5-a10d-54c0fee97a29", "resizable": true, "model3dUrl": null, "snapPoints": [], "floorAnchor": 0, "hasPriceAccess": true}, {"id": "omxz9aq6u", "type": "catalog-item", "depth": 0.45, "label": "Locker 4 Compartimentos", "scale": [1, 1, 1], "width": 0.9, "height": 1.85, "layerId": "lines", "metadata": {"resizable": true, "model3dUrl": null, "floorAnchor": 0, "forwardAxis": "Z", "scaleFactor": 1}, "position": [3.75, 0, 0.875], "rotation": [0, 0, 0], "tenantId": "ad434e3f-b929-4ff4-a80d-11feac16b136", "productId": "abb900bc-ac69-43f5-a10d-54c0fee97a29", "resizable": true, "model3dUrl": null, "snapPoints": [], "floorAnchor": 0, "hasPriceAccess": true}, {"id": "i3ej31p5f", "type": "catalog-item", "depth": 0.8, "label": "Escritorio Terra Roble", "scale": [1, 1, 1], "width": 1.6, "height": 0.75, "layerId": "lines", "metadata": {"resizable": true, "model3dUrl": null, "floorAnchor": 0, "forwardAxis": "Z", "scaleFactor": 1}, "position": [-0.25, 0, 1.875], "rotation": [0, 0, 0], "tenantId": "ad434e3f-b929-4ff4-a80d-11feac16b136", "productId": "fb2a964a-2c4b-4521-9515-f4c734e8565c", "resizable": true, "model3dUrl": null, "snapPoints": [], "floorAnchor": 0, "hasPriceAccess": true}, {"id": "saykn9ab7", "type": "catalog-item", "depth": 0.45, "label": "Locker 4 Compartimentos", "scale": [1, 1, 1], "width": 0.9, "height": 1.85, "layerId": "lines", "metadata": {"resizable": true, "model3dUrl": null, "floorAnchor": 0, "forwardAxis": "Z", "scaleFactor": 1}, "position": [-0.25, 0, 3.125], "rotation": [0, 0, 0], "tenantId": "ad434e3f-b929-4ff4-a80d-11feac16b136", "productId": "abb900bc-ac69-43f5-a10d-54c0fee97a29", "resizable": true, "model3dUrl": null, "snapPoints": [], "floorAnchor": 0, "hasPriceAccess": true}, {"id": "362e2abhp", "type": "catalog-item", "depth": 0.45, "label": "Locker 4 Compartimentos", "scale": [1, 1, 1], "width": 0.9, "height": 1.85, "layerId": "lines", "metadata": {"resizable": true, "model3dUrl": null, "floorAnchor": 0, "forwardAxis": "Z", "scaleFactor": 1}, "position": [0.25, 0, 2.375], "rotation": [0, 0, 0], "tenantId": "ad434e3f-b929-4ff4-a80d-11feac16b136", "productId": "abb900bc-ac69-43f5-a10d-54c0fee97a29", "resizable": true, "model3dUrl": null, "snapPoints": [], "floorAnchor": 0, "hasPriceAccess": true}], "lines": [], "walls": [], "groups": [], "layers": [{"id": "walls", "name": "Muros", "locked": false, "visible": true}, {"id": "openings", "name": "Huecos", "locked": false, "visible": true}, {"id": "assets", "name": "Objetos", "locked": false, "visible": true}, {"id": "dimensions", "name": "Dimensiones", "locked": false, "visible": true}, {"id": "lines", "name": "Líneas de boceto", "locked": false, "visible": true}, {"id": "rectangles", "name": "Rectángulos", "locked": false, "visible": true}, {"id": "faces", "name": "Caras", "locked": false, "visible": true}, {"id": "volumes", "name": "Volúmenes", "locked": false, "visible": true}], "scenes": [], "volumes": [], "openings": [], "blueprint": {"url": null, "scale": 1, "locked": false, "opacity": 0.5, "visible": true, "position": [0, -0.01, 0], "rotation": 0}, "dimensions": [], "rectangles": []}	2026-03-27 04:43:05.075	autosave	\N	\N
6e3be66b-c46c-4f53-9838-7b7ed306ff27	af44d62e-9013-4c9d-9d43-7150b485068a	4	{"faces": [], "items": [{"id": "gi096icyq", "type": "catalog-item", "depth": 0.8, "label": "Escritorio Terra Roble", "scale": [1, 1, 1], "width": 1.6, "height": 0.75, "layerId": "lines", "metadata": {"resizable": true, "model3dUrl": null, "floorAnchor": 0, "forwardAxis": "Z", "scaleFactor": 1}, "position": [-1.75, 0, -0.125], "rotation": [0, 0, 0], "tenantId": "ad434e3f-b929-4ff4-a80d-11feac16b136", "productId": "fb2a964a-2c4b-4521-9515-f4c734e8565c", "resizable": true, "model3dUrl": null, "snapPoints": [], "floorAnchor": 0, "hasPriceAccess": true}, {"id": "kpeu51fed", "type": "catalog-item", "depth": 0.45, "label": "Locker 4 Compartimentos", "scale": [1, 1, 1], "width": 0.9, "height": 1.85, "layerId": "lines", "metadata": {"resizable": true, "model3dUrl": null, "floorAnchor": 0, "forwardAxis": "Z", "scaleFactor": 1}, "position": [-1.75, 0, 1.125], "rotation": [0, 0, 0], "tenantId": "ad434e3f-b929-4ff4-a80d-11feac16b136", "productId": "abb900bc-ac69-43f5-a10d-54c0fee97a29", "resizable": true, "model3dUrl": null, "snapPoints": [], "floorAnchor": 0, "hasPriceAccess": true}, {"id": "j3bninyzr", "type": "catalog-item", "depth": 0.8, "label": "Escritorio Terra Roble", "scale": [1, 1, 1], "width": 1.6, "height": 0.75, "layerId": "lines", "metadata": {"resizable": true, "model3dUrl": null, "floorAnchor": 0, "forwardAxis": "Z", "scaleFactor": 1}, "position": [3.25, 0, 0.375], "rotation": [0, 0, 0], "tenantId": "ad434e3f-b929-4ff4-a80d-11feac16b136", "productId": "fb2a964a-2c4b-4521-9515-f4c734e8565c", "resizable": true, "model3dUrl": null, "snapPoints": [], "floorAnchor": 0, "hasPriceAccess": true}, {"id": "3pqcwf7ug", "type": "catalog-item", "depth": 0.45, "label": "Locker 4 Compartimentos", "scale": [1, 1, 1], "width": 0.9, "height": 1.85, "layerId": "lines", "metadata": {"resizable": true, "model3dUrl": null, "floorAnchor": 0, "forwardAxis": "Z", "scaleFactor": 1}, "position": [3.25, 0, 1.625], "rotation": [0, 0, 0], "tenantId": "ad434e3f-b929-4ff4-a80d-11feac16b136", "productId": "abb900bc-ac69-43f5-a10d-54c0fee97a29", "resizable": true, "model3dUrl": null, "snapPoints": [], "floorAnchor": 0, "hasPriceAccess": true}, {"id": "omxz9aq6u", "type": "catalog-item", "depth": 0.45, "label": "Locker 4 Compartimentos", "scale": [1, 1, 1], "width": 0.9, "height": 1.85, "layerId": "lines", "metadata": {"resizable": true, "model3dUrl": null, "floorAnchor": 0, "forwardAxis": "Z", "scaleFactor": 1}, "position": [3.75, 0, 0.875], "rotation": [0, 0, 0], "tenantId": "ad434e3f-b929-4ff4-a80d-11feac16b136", "productId": "abb900bc-ac69-43f5-a10d-54c0fee97a29", "resizable": true, "model3dUrl": null, "snapPoints": [], "floorAnchor": 0, "hasPriceAccess": true}], "lines": [], "walls": [], "groups": [], "layers": [{"id": "walls", "name": "Muros", "locked": false, "visible": true}, {"id": "openings", "name": "Huecos", "locked": false, "visible": true}, {"id": "assets", "name": "Objetos", "locked": false, "visible": true}, {"id": "dimensions", "name": "Dimensiones", "locked": false, "visible": true}, {"id": "lines", "name": "Líneas de boceto", "locked": false, "visible": true}, {"id": "rectangles", "name": "Rectángulos", "locked": false, "visible": true}, {"id": "faces", "name": "Caras", "locked": false, "visible": true}, {"id": "volumes", "name": "Volúmenes", "locked": false, "visible": true}], "scenes": [], "volumes": [], "openings": [], "blueprint": {"url": null, "scale": 1, "locked": false, "opacity": 0.5, "visible": true, "position": [0, -0.01, 0], "rotation": 0}, "dimensions": [], "rectangles": []}	2026-03-27 04:43:24.887	autosave	\N	\N
fd85db8c-a297-40bc-a6b8-98908a62cd14	af44d62e-9013-4c9d-9d43-7150b485068a	5	{"faces": [], "items": [{"id": "gi096icyq", "type": "catalog-item", "depth": 0.8, "label": "Escritorio Terra Roble", "scale": [1, 1, 1], "width": 1.6, "height": 0.75, "layerId": "lines", "metadata": {"resizable": true, "model3dUrl": null, "floorAnchor": 0, "forwardAxis": "Z", "scaleFactor": 1}, "position": [-1.75, 0, -0.125], "rotation": [0, 0, 0], "tenantId": "ad434e3f-b929-4ff4-a80d-11feac16b136", "productId": "fb2a964a-2c4b-4521-9515-f4c734e8565c", "resizable": true, "model3dUrl": null, "snapPoints": [], "floorAnchor": 0, "hasPriceAccess": true}, {"id": "kpeu51fed", "type": "catalog-item", "depth": 0.45, "label": "Locker 4 Compartimentos", "scale": [1, 1, 1], "width": 0.9, "height": 1.85, "layerId": "lines", "metadata": {"resizable": true, "model3dUrl": null, "floorAnchor": 0, "forwardAxis": "Z", "scaleFactor": 1}, "position": [-1.75, 0, 1.125], "rotation": [0, 0, 0], "tenantId": "ad434e3f-b929-4ff4-a80d-11feac16b136", "productId": "abb900bc-ac69-43f5-a10d-54c0fee97a29", "resizable": true, "model3dUrl": null, "snapPoints": [], "floorAnchor": 0, "hasPriceAccess": true}, {"id": "j3bninyzr", "type": "catalog-item", "depth": 0.8, "label": "Escritorio Terra Roble", "scale": [1, 1, 1], "width": 1.6, "height": 0.75, "layerId": "lines", "metadata": {"resizable": true, "model3dUrl": null, "floorAnchor": 0, "forwardAxis": "Z", "scaleFactor": 1}, "position": [3.25, 0, 0.375], "rotation": [0, 0, 0], "tenantId": "ad434e3f-b929-4ff4-a80d-11feac16b136", "productId": "fb2a964a-2c4b-4521-9515-f4c734e8565c", "resizable": true, "model3dUrl": null, "snapPoints": [], "floorAnchor": 0, "hasPriceAccess": true}, {"id": "3pqcwf7ug", "type": "catalog-item", "depth": 0.45, "label": "Locker 4 Compartimentos", "scale": [1, 1, 1], "width": 0.9, "height": 1.85, "layerId": "lines", "metadata": {"resizable": true, "model3dUrl": null, "floorAnchor": 0, "forwardAxis": "Z", "scaleFactor": 1}, "position": [3.25, 0, 1.625], "rotation": [0, 0, 0], "tenantId": "ad434e3f-b929-4ff4-a80d-11feac16b136", "productId": "abb900bc-ac69-43f5-a10d-54c0fee97a29", "resizable": true, "model3dUrl": null, "snapPoints": [], "floorAnchor": 0, "hasPriceAccess": true}, {"id": "omxz9aq6u", "type": "catalog-item", "depth": 0.45, "label": "Locker 4 Compartimentos", "scale": [1, 1, 1], "width": 0.9, "height": 1.85, "layerId": "lines", "metadata": {"resizable": true, "model3dUrl": null, "floorAnchor": 0, "forwardAxis": "Z", "scaleFactor": 1}, "position": [3.75, 0, 0.875], "rotation": [0, 0, 0], "tenantId": "ad434e3f-b929-4ff4-a80d-11feac16b136", "productId": "abb900bc-ac69-43f5-a10d-54c0fee97a29", "resizable": true, "model3dUrl": null, "snapPoints": [], "floorAnchor": 0, "hasPriceAccess": true}], "lines": [], "walls": [], "groups": [], "layers": [{"id": "walls", "name": "Muros", "locked": false, "visible": true}, {"id": "openings", "name": "Huecos", "locked": false, "visible": true}, {"id": "assets", "name": "Objetos", "locked": false, "visible": true}, {"id": "dimensions", "name": "Dimensiones", "locked": false, "visible": true}, {"id": "lines", "name": "Líneas de boceto", "locked": false, "visible": true}, {"id": "rectangles", "name": "Rectángulos", "locked": false, "visible": true}, {"id": "faces", "name": "Caras", "locked": false, "visible": true}, {"id": "volumes", "name": "Volúmenes", "locked": false, "visible": true}], "scenes": [], "volumes": [], "openings": [], "blueprint": {"url": null, "scale": 1, "locked": false, "opacity": 0.5, "visible": true, "position": [0, -0.01, 0], "rotation": 0}, "dimensions": [], "rectangles": []}	2026-03-27 04:43:25.817	autosave	\N	\N
93735911-0073-4ef4-9b95-c89c89287560	cb80999d-132a-4cdc-a5f2-329e18a98250	1	{"faces": [], "items": [{"id": "gi096icyq", "type": "catalog-item", "depth": 0.8, "label": "Escritorio Terra Roble", "scale": [1, 1, 1], "width": 1.6, "height": 0.75, "layerId": "lines", "metadata": {"resizable": true, "model3dUrl": null, "floorAnchor": 0, "forwardAxis": "Z", "scaleFactor": 1}, "position": [-1.75, 0, -0.125], "rotation": [0, 0, 0], "tenantId": "ad434e3f-b929-4ff4-a80d-11feac16b136", "productId": "fb2a964a-2c4b-4521-9515-f4c734e8565c", "resizable": true, "model3dUrl": null, "snapPoints": [], "floorAnchor": 0, "hasPriceAccess": true}, {"id": "kpeu51fed", "type": "catalog-item", "depth": 0.45, "label": "Locker 4 Compartimentos", "scale": [1, 1, 1], "width": 0.9, "height": 1.85, "layerId": "lines", "metadata": {"resizable": true, "model3dUrl": null, "floorAnchor": 0, "forwardAxis": "Z", "scaleFactor": 1}, "position": [-1.75, 0, 1.125], "rotation": [0, 0, 0], "tenantId": "ad434e3f-b929-4ff4-a80d-11feac16b136", "productId": "abb900bc-ac69-43f5-a10d-54c0fee97a29", "resizable": true, "model3dUrl": null, "snapPoints": [], "floorAnchor": 0, "hasPriceAccess": true}, {"id": "j3bninyzr", "type": "catalog-item", "depth": 0.8, "label": "Escritorio Terra Roble", "scale": [1, 1, 1], "width": 1.6, "height": 0.75, "layerId": "lines", "metadata": {"resizable": true, "model3dUrl": null, "floorAnchor": 0, "forwardAxis": "Z", "scaleFactor": 1}, "position": [3.25, 0, 0.375], "rotation": [0, 0, 0], "tenantId": "ad434e3f-b929-4ff4-a80d-11feac16b136", "productId": "fb2a964a-2c4b-4521-9515-f4c734e8565c", "resizable": true, "model3dUrl": null, "snapPoints": [], "floorAnchor": 0, "hasPriceAccess": true}, {"id": "3pqcwf7ug", "type": "catalog-item", "depth": 0.45, "label": "Locker 4 Compartimentos", "scale": [1, 1, 1], "width": 0.9, "height": 1.85, "layerId": "lines", "metadata": {"resizable": true, "model3dUrl": null, "floorAnchor": 0, "forwardAxis": "Z", "scaleFactor": 1}, "position": [3.25, 0, 1.625], "rotation": [0, 0, 0], "tenantId": "ad434e3f-b929-4ff4-a80d-11feac16b136", "productId": "abb900bc-ac69-43f5-a10d-54c0fee97a29", "resizable": true, "model3dUrl": null, "snapPoints": [], "floorAnchor": 0, "hasPriceAccess": true}, {"id": "omxz9aq6u", "type": "catalog-item", "depth": 0.45, "label": "Locker 4 Compartimentos", "scale": [1, 1, 1], "width": 0.9, "height": 1.85, "layerId": "lines", "metadata": {"resizable": true, "model3dUrl": null, "floorAnchor": 0, "forwardAxis": "Z", "scaleFactor": 1}, "position": [3.75, 0, 0.875], "rotation": [0, 0, 0], "tenantId": "ad434e3f-b929-4ff4-a80d-11feac16b136", "productId": "abb900bc-ac69-43f5-a10d-54c0fee97a29", "resizable": true, "model3dUrl": null, "snapPoints": [], "floorAnchor": 0, "hasPriceAccess": true}], "lines": [], "walls": [], "groups": [], "layers": [{"id": "walls", "name": "Muros", "locked": false, "visible": true}, {"id": "openings", "name": "Huecos", "locked": false, "visible": true}, {"id": "assets", "name": "Objetos", "locked": false, "visible": true}, {"id": "dimensions", "name": "Dimensiones", "locked": false, "visible": true}, {"id": "lines", "name": "Líneas de boceto", "locked": false, "visible": true}, {"id": "rectangles", "name": "Rectángulos", "locked": false, "visible": true}, {"id": "faces", "name": "Caras", "locked": false, "visible": true}, {"id": "volumes", "name": "Volúmenes", "locked": false, "visible": true}], "scenes": [], "volumes": [], "openings": [], "blueprint": {"url": null, "scale": 1, "locked": false, "opacity": 0.5, "visible": true, "position": [0, -0.01, 0], "rotation": 0}, "dimensions": [], "rectangles": []}	2026-03-27 04:43:50.07	autosave	\N	\N
df56185e-e19b-423f-92c9-39694c3b92af	af44d62e-9013-4c9d-9d43-7150b485068a	6	{"faces": [], "items": [{"id": "j3bninyzr", "type": "catalog-item", "depth": 0.8, "label": "Escritorio Terra Roble", "scale": [1, 1, 1], "width": 1.6, "height": 0.75, "layerId": "lines", "metadata": {"resizable": true, "model3dUrl": null, "floorAnchor": 0, "forwardAxis": "Z", "scaleFactor": 1}, "position": [3.25, 0, 0.375], "rotation": [0, 0, 0], "tenantId": "ad434e3f-b929-4ff4-a80d-11feac16b136", "productId": "fb2a964a-2c4b-4521-9515-f4c734e8565c", "resizable": true, "model3dUrl": null, "snapPoints": [], "floorAnchor": 0, "hasPriceAccess": true}, {"id": "3pqcwf7ug", "type": "catalog-item", "depth": 0.45, "label": "Locker 4 Compartimentos", "scale": [1, 1, 1], "width": 0.9, "height": 1.85, "layerId": "lines", "metadata": {"resizable": true, "model3dUrl": null, "floorAnchor": 0, "forwardAxis": "Z", "scaleFactor": 1}, "position": [3.25, 0, 1.625], "rotation": [0, 0, 0], "tenantId": "ad434e3f-b929-4ff4-a80d-11feac16b136", "productId": "abb900bc-ac69-43f5-a10d-54c0fee97a29", "resizable": true, "model3dUrl": null, "snapPoints": [], "floorAnchor": 0, "hasPriceAccess": true}, {"id": "omxz9aq6u", "type": "catalog-item", "depth": 0.45, "label": "Locker 4 Compartimentos", "scale": [1, 1, 1], "width": 0.9, "height": 1.85, "layerId": "lines", "metadata": {"resizable": true, "model3dUrl": null, "floorAnchor": 0, "forwardAxis": "Z", "scaleFactor": 1}, "position": [3.75, 0, 0.875], "rotation": [0, 0, 0], "tenantId": "ad434e3f-b929-4ff4-a80d-11feac16b136", "productId": "abb900bc-ac69-43f5-a10d-54c0fee97a29", "resizable": true, "model3dUrl": null, "snapPoints": [], "floorAnchor": 0, "hasPriceAccess": true}], "lines": [], "walls": [], "groups": [], "layers": [{"id": "walls", "name": "Muros", "locked": false, "visible": true}, {"id": "openings", "name": "Huecos", "locked": false, "visible": true}, {"id": "assets", "name": "Objetos", "locked": false, "visible": true}, {"id": "dimensions", "name": "Dimensiones", "locked": false, "visible": true}, {"id": "lines", "name": "Líneas de boceto", "locked": false, "visible": true}, {"id": "rectangles", "name": "Rectángulos", "locked": false, "visible": true}, {"id": "faces", "name": "Caras", "locked": false, "visible": true}, {"id": "volumes", "name": "Volúmenes", "locked": false, "visible": true}], "scenes": [], "volumes": [], "openings": [], "blueprint": {"url": null, "scale": 1, "locked": false, "opacity": 0.5, "visible": true, "position": [0, -0.01, 0], "rotation": 0}, "dimensions": [], "rectangles": []}	2026-03-27 04:43:59.894	autosave	\N	\N
4579730a-28a9-42df-ad19-28a27cc8bb99	d560b37f-6412-49fa-9ff9-7966205e9c9e	1	{"items": [{"id": "item1", "position": [0, 0, 0], "rotation": [0, 0, 0], "productId": "prod1"}], "walls": [], "openings": []}	2026-03-27 04:45:47.669	autosave	\N	\N
7de6a696-7101-4d4d-a529-af624cffb7d9	af44d62e-9013-4c9d-9d43-7150b485068a	7	{"faces": [], "items": [{"id": "j3bninyzr", "type": "catalog-item", "depth": 0.8, "label": "Escritorio Terra Roble", "scale": [1, 1, 1], "width": 1.6, "height": 0.75, "layerId": "lines", "metadata": {"resizable": true, "model3dUrl": null, "floorAnchor": 0, "forwardAxis": "Z", "scaleFactor": 1}, "position": [5.5, 0.5, 3], "rotation": [0, 0, 0], "tenantId": "ad434e3f-b929-4ff4-a80d-11feac16b136", "productId": "fb2a964a-2c4b-4521-9515-f4c734e8565c", "resizable": true, "model3dUrl": null, "snapPoints": [], "floorAnchor": 0, "hasPriceAccess": true}, {"id": "3pqcwf7ug", "type": "catalog-item", "depth": 0.45, "label": "Locker 4 Compartimentos", "scale": [1, 1, 1], "width": 0.9, "height": 1.85, "layerId": "lines", "metadata": {"resizable": true, "model3dUrl": null, "floorAnchor": 0, "forwardAxis": "Z", "scaleFactor": 1}, "position": [3.25, 0, 1.625], "rotation": [0, 0, 0], "tenantId": "ad434e3f-b929-4ff4-a80d-11feac16b136", "productId": "abb900bc-ac69-43f5-a10d-54c0fee97a29", "resizable": true, "model3dUrl": null, "snapPoints": [], "floorAnchor": 0, "hasPriceAccess": true}, {"id": "omxz9aq6u", "type": "catalog-item", "depth": 0.45, "label": "Locker 4 Compartimentos", "scale": [1, 1, 1], "width": 0.9, "height": 1.85, "layerId": "lines", "metadata": {"resizable": true, "model3dUrl": null, "floorAnchor": 0, "forwardAxis": "Z", "scaleFactor": 1}, "position": [3.75, 0, 0.875], "rotation": [0, 0, 0], "tenantId": "ad434e3f-b929-4ff4-a80d-11feac16b136", "productId": "abb900bc-ac69-43f5-a10d-54c0fee97a29", "resizable": true, "model3dUrl": null, "snapPoints": [], "floorAnchor": 0, "hasPriceAccess": true}], "lines": [], "walls": [], "groups": [], "layers": [{"id": "walls", "name": "Muros", "locked": false, "visible": true}, {"id": "openings", "name": "Huecos", "locked": false, "visible": true}, {"id": "assets", "name": "Objetos", "locked": false, "visible": true}, {"id": "dimensions", "name": "Dimensiones", "locked": false, "visible": true}, {"id": "lines", "name": "Líneas de boceto", "locked": false, "visible": true}, {"id": "rectangles", "name": "Rectángulos", "locked": false, "visible": true}, {"id": "faces", "name": "Caras", "locked": false, "visible": true}, {"id": "volumes", "name": "Volúmenes", "locked": false, "visible": true}], "scenes": [], "volumes": [], "openings": [], "blueprint": {"url": null, "scale": 1, "locked": false, "opacity": 0.5, "visible": true, "position": [0, -0.01, 0], "rotation": 0}, "dimensions": [], "rectangles": []}	2026-03-27 22:29:50.38	autosave	{"blueprint":{"locked":false,"opacity":0.5,"position":[0,-0.01,0],"rotation":0,"scale":1,"url":null,"visible":true},"faces":[],"groups":[],"items":[{"depth":0.45,"floorAnchor":0,"hasPriceAccess":true,"height":1.85,"id":"3pqcwf7ug","label":"Locker 4 Compartimentos","layerId":"lines","metadata":{"floorAnchor":0,"forwardAxis":"Z","model3dUrl":null,"resizable":true,"scaleFactor":1},"model3dUrl":null,"position":[3.25,0,1.625],"productId":"abb900bc-ac69-43f5-a10d-54c0fee97a29","resizable":true,"rotation":[0,0,0],"scale":[1,1,1],"snapPoints":[],"tenantId":"ad434e3f-b929-4ff4-a80d-11feac16b136","type":"catalog-item","width":0.9},{"depth":0.8,"floorAnchor":0,"hasPriceAccess":true,"height":0.75,"id":"j3bninyzr","label":"Escritorio Terra Roble","layerId":"lines","metadata":{"floorAnchor":0,"forwardAxis":"Z","model3dUrl":null,"resizable":true,"scaleFactor":1},"model3dUrl":null,"position":[5.5,0.5,3],"productId":"fb2a964a-2c4b-4521-9515-f4c734e8565c","resizable":true,"rotation":[0,0,0],"scale":[1,1,1],"snapPoints":[],"tenantId":"ad434e3f-b929-4ff4-a80d-11feac16b136","type":"catalog-item","width":1.6},{"depth":0.45,"floorAnchor":0,"hasPriceAccess":true,"height":1.85,"id":"omxz9aq6u","label":"Locker 4 Compartimentos","layerId":"lines","metadata":{"floorAnchor":0,"forwardAxis":"Z","model3dUrl":null,"resizable":true,"scaleFactor":1},"model3dUrl":null,"position":[3.75,0,0.875],"productId":"abb900bc-ac69-43f5-a10d-54c0fee97a29","resizable":true,"rotation":[0,0,0],"scale":[1,1,1],"snapPoints":[],"tenantId":"ad434e3f-b929-4ff4-a80d-11feac16b136","type":"catalog-item","width":0.9}],"lines":[],"openings":[],"rectangles":[],"scenes":[],"volumes":[],"walls":[]}	{"totalItems": 3, "totalLines": 0, "totalWalls": 0, "totalOpenings": 0}
4d4b962f-9610-4c6f-b2ba-8a465e951e39	e3391f89-3e70-420e-becc-800cf65916aa	1	{"faces": [], "items": [{"id": "12l8axb4b", "type": "catalog-item", "depth": 0.75, "label": "sillon 3ds", "price": 1213, "scale": [1, 1, 1], "width": 0.78, "height": 0.75, "layerId": "lines", "metadata": {"materials": 1, "triangles": 42818, "model3dUrl": "/storage/converted/23ac4cc9-343f-499c-8775-64c0628c00d0.glb", "validation": "warning", "boundingBox": {"max": [321.5899516055998, 264.126130275497, 11.51466882270872], "min": [-321.369626817166, -248.6159647590168, -5.633164698566948], "depth": 17.1478, "width": 642.9596, "height": 512.7421}, "convertedAt": "2026-03-28T03:57:21.987Z", "orientation": {"status": "warning", "centered": false, "warnings": ["Modelo por debajo del piso (min.Y = -248.616m)", "Modelo descentrado (centro: X=0.110, Z=2.941)", "Modelo muy grande (max dim = 643.0m). Verificar escala."], "floorAligned": false}, "dracoEnabled": true, "originalFormat": "3ds", "originalSizeMb": 3.0375, "optimizedSizeMb": 0.3043, "compressionRatio": 90, "originalSizeBytes": 3185017, "optimizedSizeBytes": 319120, "validationWarnings": ["42,818 triángulos — recomendado < 10K", "Modelo por debajo del piso (min.Y = -248.616m)", "Modelo descentrado (centro: X=0.110, Z=2.941)", "Modelo muy grande (max dim = 643.0m). Verificar escala."]}, "position": [0, 0, 0], "rotation": [0, 0, 0], "tenantId": "ad434e3f-b929-4ff4-a80d-11feac16b136", "productId": "1a8df8c7-601e-44fb-9037-82c7adf63b60", "resizable": true, "model3dUrl": "/storage/converted/23ac4cc9-343f-499c-8775-64c0628c00d0.glb", "snapPoints": [], "floorAnchor": 0.5, "hasPriceAccess": true}], "lines": [], "walls": [], "groups": [], "layers": [{"id": "walls", "name": "Muros", "locked": false, "visible": true}, {"id": "openings", "name": "Huecos", "locked": false, "visible": true}, {"id": "assets", "name": "Objetos", "locked": false, "visible": true}, {"id": "dimensions", "name": "Dimensiones", "locked": false, "visible": true}, {"id": "lines", "name": "Líneas de boceto", "locked": false, "visible": true}, {"id": "rectangles", "name": "Rectángulos", "locked": false, "visible": true}, {"id": "faces", "name": "Caras", "locked": false, "visible": true}, {"id": "volumes", "name": "Volúmenes", "locked": false, "visible": true}], "scenes": [], "volumes": [], "openings": [], "blueprint": {"url": null, "scale": 1, "locked": false, "opacity": 0.5, "visible": true, "position": [0, -0.01, 0], "rotation": 0}, "dimensions": [], "rectangles": []}	2026-03-28 03:58:05.537	autosave	{"blueprint":{"locked":false,"opacity":0.5,"position":[0,-0.01,0],"rotation":0,"scale":1,"url":null,"visible":true},"faces":[],"groups":[],"items":[{"depth":0.75,"floorAnchor":0.5,"hasPriceAccess":true,"height":0.75,"id":"12l8axb4b","label":"sillon 3ds","layerId":"lines","metadata":{"boundingBox":{"depth":17.1478,"height":512.7421,"max":[321.5899516055998,264.126130275497,11.51466882270872],"min":[-321.369626817166,-248.6159647590168,-5.633164698566948],"width":642.9596},"compressionRatio":90,"convertedAt":"2026-03-28T03:57:21.987Z","dracoEnabled":true,"materials":1,"model3dUrl":"/storage/converted/23ac4cc9-343f-499c-8775-64c0628c00d0.glb","optimizedSizeBytes":319120,"optimizedSizeMb":0.3043,"orientation":{"centered":false,"floorAligned":false,"status":"warning","warnings":["Modelo por debajo del piso (min.Y = -248.616m)","Modelo descentrado (centro: X=0.110, Z=2.941)","Modelo muy grande (max dim = 643.0m). Verificar escala."]},"originalFormat":"3ds","originalSizeBytes":3185017,"originalSizeMb":3.0375,"triangles":42818,"validation":"warning","validationWarnings":["42,818 triángulos — recomendado < 10K","Modelo por debajo del piso (min.Y = -248.616m)","Modelo descentrado (centro: X=0.110, Z=2.941)","Modelo muy grande (max dim = 643.0m). Verificar escala."]},"model3dUrl":"/storage/converted/23ac4cc9-343f-499c-8775-64c0628c00d0.glb","position":[0,0,0],"price":1213,"productId":"1a8df8c7-601e-44fb-9037-82c7adf63b60","resizable":true,"rotation":[0,0,0],"scale":[1,1,1],"snapPoints":[],"tenantId":"ad434e3f-b929-4ff4-a80d-11feac16b136","type":"catalog-item","width":0.78}],"lines":[],"openings":[],"rectangles":[],"scenes":[],"volumes":[],"walls":[]}	{"totalItems": 1, "totalLines": 0, "totalWalls": 0, "totalOpenings": 0}
e574469c-a869-4af2-978a-c655f61e0d74	e3391f89-3e70-420e-becc-800cf65916aa	2	{"faces": [], "items": [{"id": "12l8axb4b", "type": "catalog-item", "depth": 0.75, "label": "sillon 3ds", "price": 1213, "scale": [1, 1, 1], "width": 0.78, "height": 0.75, "layerId": "lines", "metadata": {"materials": 1, "triangles": 42818, "model3dUrl": "/storage/converted/23ac4cc9-343f-499c-8775-64c0628c00d0.glb", "validation": "warning", "boundingBox": {"max": [321.5899516055998, 264.126130275497, 11.51466882270872], "min": [-321.369626817166, -248.6159647590168, -5.633164698566948], "depth": 17.1478, "width": 642.9596, "height": 512.7421}, "convertedAt": "2026-03-28T03:57:21.987Z", "orientation": {"status": "warning", "centered": false, "warnings": ["Modelo por debajo del piso (min.Y = -248.616m)", "Modelo descentrado (centro: X=0.110, Z=2.941)", "Modelo muy grande (max dim = 643.0m). Verificar escala."], "floorAligned": false}, "dracoEnabled": true, "originalFormat": "3ds", "originalSizeMb": 3.0375, "optimizedSizeMb": 0.3043, "compressionRatio": 90, "originalSizeBytes": 3185017, "optimizedSizeBytes": 319120, "validationWarnings": ["42,818 triángulos — recomendado < 10K", "Modelo por debajo del piso (min.Y = -248.616m)", "Modelo descentrado (centro: X=0.110, Z=2.941)", "Modelo muy grande (max dim = 643.0m). Verificar escala."]}, "position": [0, 0, 0], "rotation": [0, 0, 0], "tenantId": "ad434e3f-b929-4ff4-a80d-11feac16b136", "productId": "1a8df8c7-601e-44fb-9037-82c7adf63b60", "resizable": true, "model3dUrl": "/storage/converted/23ac4cc9-343f-499c-8775-64c0628c00d0.glb", "snapPoints": [], "floorAnchor": 0.5, "hasPriceAccess": true}, {"id": "it10tugry", "type": "catalog-item", "depth": 0.8, "label": "Escritorio Terra Roble", "scale": [1, 1, 1], "width": 1.6, "height": 0.75, "layerId": "lines", "metadata": {"failedAt": "2026-03-28T03:39:59.618Z", "errorType": "conversion", "model3dUrl": null, "originalFormat": "dwg", "originalSizeMb": 1.7672, "originalSizeBytes": 1853046}, "position": [0, 0, 0], "rotation": [0, 0, 0], "tenantId": "ad434e3f-b929-4ff4-a80d-11feac16b136", "productId": "fb2a964a-2c4b-4521-9515-f4c734e8565c", "resizable": true, "model3dUrl": null, "snapPoints": [], "floorAnchor": 0.5, "hasPriceAccess": true}], "lines": [], "walls": [], "groups": [], "layers": [{"id": "walls", "name": "Muros", "locked": false, "visible": true}, {"id": "openings", "name": "Huecos", "locked": false, "visible": true}, {"id": "assets", "name": "Objetos", "locked": false, "visible": true}, {"id": "dimensions", "name": "Dimensiones", "locked": false, "visible": true}, {"id": "lines", "name": "Líneas de boceto", "locked": false, "visible": true}, {"id": "rectangles", "name": "Rectángulos", "locked": false, "visible": true}, {"id": "faces", "name": "Caras", "locked": false, "visible": true}, {"id": "volumes", "name": "Volúmenes", "locked": false, "visible": true}], "scenes": [], "volumes": [], "openings": [], "blueprint": {"url": null, "scale": 1, "locked": false, "opacity": 0.5, "visible": true, "position": [0, -0.01, 0], "rotation": 0}, "dimensions": [], "rectangles": []}	2026-03-28 03:58:17.58	autosave	{"blueprint":{"locked":false,"opacity":0.5,"position":[0,-0.01,0],"rotation":0,"scale":1,"url":null,"visible":true},"faces":[],"groups":[],"items":[{"depth":0.75,"floorAnchor":0.5,"hasPriceAccess":true,"height":0.75,"id":"12l8axb4b","label":"sillon 3ds","layerId":"lines","metadata":{"boundingBox":{"depth":17.1478,"height":512.7421,"max":[321.5899516055998,264.126130275497,11.51466882270872],"min":[-321.369626817166,-248.6159647590168,-5.633164698566948],"width":642.9596},"compressionRatio":90,"convertedAt":"2026-03-28T03:57:21.987Z","dracoEnabled":true,"materials":1,"model3dUrl":"/storage/converted/23ac4cc9-343f-499c-8775-64c0628c00d0.glb","optimizedSizeBytes":319120,"optimizedSizeMb":0.3043,"orientation":{"centered":false,"floorAligned":false,"status":"warning","warnings":["Modelo por debajo del piso (min.Y = -248.616m)","Modelo descentrado (centro: X=0.110, Z=2.941)","Modelo muy grande (max dim = 643.0m). Verificar escala."]},"originalFormat":"3ds","originalSizeBytes":3185017,"originalSizeMb":3.0375,"triangles":42818,"validation":"warning","validationWarnings":["42,818 triángulos — recomendado < 10K","Modelo por debajo del piso (min.Y = -248.616m)","Modelo descentrado (centro: X=0.110, Z=2.941)","Modelo muy grande (max dim = 643.0m). Verificar escala."]},"model3dUrl":"/storage/converted/23ac4cc9-343f-499c-8775-64c0628c00d0.glb","position":[0,0,0],"price":1213,"productId":"1a8df8c7-601e-44fb-9037-82c7adf63b60","resizable":true,"rotation":[0,0,0],"scale":[1,1,1],"snapPoints":[],"tenantId":"ad434e3f-b929-4ff4-a80d-11feac16b136","type":"catalog-item","width":0.78},{"depth":0.8,"floorAnchor":0.5,"hasPriceAccess":true,"height":0.75,"id":"it10tugry","label":"Escritorio Terra Roble","layerId":"lines","metadata":{"errorType":"conversion","failedAt":"2026-03-28T03:39:59.618Z","model3dUrl":null,"originalFormat":"dwg","originalSizeBytes":1853046,"originalSizeMb":1.7672},"model3dUrl":null,"position":[0,0,0],"productId":"fb2a964a-2c4b-4521-9515-f4c734e8565c","resizable":true,"rotation":[0,0,0],"scale":[1,1,1],"snapPoints":[],"tenantId":"ad434e3f-b929-4ff4-a80d-11feac16b136","type":"catalog-item","width":1.6}],"lines":[],"openings":[],"rectangles":[],"scenes":[],"volumes":[],"walls":[]}	{"totalItems": 2, "totalLines": 0, "totalWalls": 0, "totalOpenings": 0}
b0d97be3-b404-4454-844e-88e740f726f3	e3391f89-3e70-420e-becc-800cf65916aa	3	{"faces": [], "items": [{"id": "it10tugry", "type": "catalog-item", "depth": 0.8, "label": "Escritorio Terra Roble", "scale": [1, 1, 1], "width": 1.6, "height": 0.75, "layerId": "lines", "metadata": {"failedAt": "2026-03-28T03:39:59.618Z", "errorType": "conversion", "model3dUrl": null, "originalFormat": "dwg", "originalSizeMb": 1.7672, "originalSizeBytes": 1853046}, "position": [0, 0, 0], "rotation": [0, 0, 0], "tenantId": "ad434e3f-b929-4ff4-a80d-11feac16b136", "productId": "fb2a964a-2c4b-4521-9515-f4c734e8565c", "resizable": true, "model3dUrl": null, "snapPoints": [], "floorAnchor": 0.5, "hasPriceAccess": true}], "lines": [], "walls": [], "groups": [], "layers": [{"id": "walls", "name": "Muros", "locked": false, "visible": true}, {"id": "openings", "name": "Huecos", "locked": false, "visible": true}, {"id": "assets", "name": "Objetos", "locked": false, "visible": true}, {"id": "dimensions", "name": "Dimensiones", "locked": false, "visible": true}, {"id": "lines", "name": "Líneas de boceto", "locked": false, "visible": true}, {"id": "rectangles", "name": "Rectángulos", "locked": false, "visible": true}, {"id": "faces", "name": "Caras", "locked": false, "visible": true}, {"id": "volumes", "name": "Volúmenes", "locked": false, "visible": true}], "scenes": [], "volumes": [], "openings": [], "blueprint": {"url": null, "scale": 1, "locked": false, "opacity": 0.5, "visible": true, "position": [0, -0.01, 0], "rotation": 0}, "dimensions": [], "rectangles": []}	2026-03-28 03:58:25.293	autosave	{"blueprint":{"locked":false,"opacity":0.5,"position":[0,-0.01,0],"rotation":0,"scale":1,"url":null,"visible":true},"faces":[],"groups":[],"items":[{"depth":0.8,"floorAnchor":0.5,"hasPriceAccess":true,"height":0.75,"id":"it10tugry","label":"Escritorio Terra Roble","layerId":"lines","metadata":{"errorType":"conversion","failedAt":"2026-03-28T03:39:59.618Z","model3dUrl":null,"originalFormat":"dwg","originalSizeBytes":1853046,"originalSizeMb":1.7672},"model3dUrl":null,"position":[0,0,0],"productId":"fb2a964a-2c4b-4521-9515-f4c734e8565c","resizable":true,"rotation":[0,0,0],"scale":[1,1,1],"snapPoints":[],"tenantId":"ad434e3f-b929-4ff4-a80d-11feac16b136","type":"catalog-item","width":1.6}],"lines":[],"openings":[],"rectangles":[],"scenes":[],"volumes":[],"walls":[]}	{"totalItems": 1, "totalLines": 0, "totalWalls": 0, "totalOpenings": 0}
bdcf9381-aa54-4cd3-949a-d3f438d9864a	e3391f89-3e70-420e-becc-800cf65916aa	4	{"faces": [], "items": [], "lines": [], "walls": [], "groups": [], "layers": [{"id": "walls", "name": "Muros", "locked": false, "visible": true}, {"id": "openings", "name": "Huecos", "locked": false, "visible": true}, {"id": "assets", "name": "Objetos", "locked": false, "visible": true}, {"id": "dimensions", "name": "Dimensiones", "locked": false, "visible": true}, {"id": "lines", "name": "Líneas de boceto", "locked": false, "visible": true}, {"id": "rectangles", "name": "Rectángulos", "locked": false, "visible": true}, {"id": "faces", "name": "Caras", "locked": false, "visible": true}, {"id": "volumes", "name": "Volúmenes", "locked": false, "visible": true}], "scenes": [], "volumes": [], "openings": [], "blueprint": {"url": null, "scale": 1, "locked": false, "opacity": 0.5, "visible": true, "position": [0, -0.01, 0], "rotation": 0}, "dimensions": [], "rectangles": []}	2026-03-28 03:58:30.688	autosave	{"blueprint":{"locked":false,"opacity":0.5,"position":[0,-0.01,0],"rotation":0,"scale":1,"url":null,"visible":true},"faces":[],"groups":[],"items":[],"lines":[],"openings":[],"rectangles":[],"scenes":[],"volumes":[],"walls":[]}	{"totalItems": 0, "totalLines": 0, "totalWalls": 0, "totalOpenings": 0}
f736d976-4d37-4190-811b-fb7b75b6e9a4	e3391f89-3e70-420e-becc-800cf65916aa	5	{"faces": [], "items": [{"id": "y1rg0kyct", "type": "catalog-item", "depth": 0.75, "label": "sillon 3ds", "price": 1213, "scale": [1, 1, 1], "width": 0.78, "height": 0.75, "layerId": "lines", "metadata": {"materials": 1, "triangles": 42818, "model3dUrl": "/storage/converted/23ac4cc9-343f-499c-8775-64c0628c00d0.glb", "validation": "warning", "boundingBox": {"max": [321.5899516055998, 264.126130275497, 11.51466882270872], "min": [-321.369626817166, -248.6159647590168, -5.633164698566948], "depth": 17.1478, "width": 642.9596, "height": 512.7421}, "convertedAt": "2026-03-28T03:57:21.987Z", "orientation": {"status": "warning", "centered": false, "warnings": ["Modelo por debajo del piso (min.Y = -248.616m)", "Modelo descentrado (centro: X=0.110, Z=2.941)", "Modelo muy grande (max dim = 643.0m). Verificar escala."], "floorAligned": false}, "dracoEnabled": true, "originalFormat": "3ds", "originalSizeMb": 3.0375, "optimizedSizeMb": 0.3043, "compressionRatio": 90, "originalSizeBytes": 3185017, "optimizedSizeBytes": 319120, "validationWarnings": ["42,818 triángulos — recomendado < 10K", "Modelo por debajo del piso (min.Y = -248.616m)", "Modelo descentrado (centro: X=0.110, Z=2.941)", "Modelo muy grande (max dim = 643.0m). Verificar escala."]}, "position": [0, 0, 0], "rotation": [0, 0, 0], "tenantId": "ad434e3f-b929-4ff4-a80d-11feac16b136", "productId": "1a8df8c7-601e-44fb-9037-82c7adf63b60", "resizable": true, "model3dUrl": "/storage/converted/23ac4cc9-343f-499c-8775-64c0628c00d0.glb", "snapPoints": [], "floorAnchor": 0.5, "hasPriceAccess": true}, {"id": "sm32nflqn", "type": "catalog-item", "depth": 0.8, "label": "Escritorio Terra Roble", "scale": [1, 1, 1], "width": 1.6, "height": 0.75, "layerId": "lines", "metadata": {"failedAt": "2026-03-28T03:39:59.618Z", "errorType": "conversion", "model3dUrl": null, "originalFormat": "dwg", "originalSizeMb": 1.7672, "originalSizeBytes": 1853046}, "position": [0, 0, 0], "rotation": [0, 0, 0], "tenantId": "ad434e3f-b929-4ff4-a80d-11feac16b136", "productId": "fb2a964a-2c4b-4521-9515-f4c734e8565c", "resizable": true, "model3dUrl": null, "snapPoints": [], "floorAnchor": 0.5, "hasPriceAccess": true}], "lines": [], "walls": [], "groups": [], "layers": [{"id": "walls", "name": "Muros", "locked": false, "visible": true}, {"id": "openings", "name": "Huecos", "locked": false, "visible": true}, {"id": "assets", "name": "Objetos", "locked": false, "visible": true}, {"id": "dimensions", "name": "Dimensiones", "locked": false, "visible": true}, {"id": "lines", "name": "Líneas de boceto", "locked": false, "visible": true}, {"id": "rectangles", "name": "Rectángulos", "locked": false, "visible": true}, {"id": "faces", "name": "Caras", "locked": false, "visible": true}, {"id": "volumes", "name": "Volúmenes", "locked": false, "visible": true}], "scenes": [], "volumes": [], "openings": [], "blueprint": {"url": null, "scale": 1, "locked": false, "opacity": 0.5, "visible": true, "position": [0, -0.01, 0], "rotation": 0}, "dimensions": [], "rectangles": []}	2026-03-28 04:02:59.766	autosave	{"blueprint":{"locked":false,"opacity":0.5,"position":[0,-0.01,0],"rotation":0,"scale":1,"url":null,"visible":true},"faces":[],"groups":[],"items":[{"depth":0.8,"floorAnchor":0.5,"hasPriceAccess":true,"height":0.75,"id":"sm32nflqn","label":"Escritorio Terra Roble","layerId":"lines","metadata":{"errorType":"conversion","failedAt":"2026-03-28T03:39:59.618Z","model3dUrl":null,"originalFormat":"dwg","originalSizeBytes":1853046,"originalSizeMb":1.7672},"model3dUrl":null,"position":[0,0,0],"productId":"fb2a964a-2c4b-4521-9515-f4c734e8565c","resizable":true,"rotation":[0,0,0],"scale":[1,1,1],"snapPoints":[],"tenantId":"ad434e3f-b929-4ff4-a80d-11feac16b136","type":"catalog-item","width":1.6},{"depth":0.75,"floorAnchor":0.5,"hasPriceAccess":true,"height":0.75,"id":"y1rg0kyct","label":"sillon 3ds","layerId":"lines","metadata":{"boundingBox":{"depth":17.1478,"height":512.7421,"max":[321.5899516055998,264.126130275497,11.51466882270872],"min":[-321.369626817166,-248.6159647590168,-5.633164698566948],"width":642.9596},"compressionRatio":90,"convertedAt":"2026-03-28T03:57:21.987Z","dracoEnabled":true,"materials":1,"model3dUrl":"/storage/converted/23ac4cc9-343f-499c-8775-64c0628c00d0.glb","optimizedSizeBytes":319120,"optimizedSizeMb":0.3043,"orientation":{"centered":false,"floorAligned":false,"status":"warning","warnings":["Modelo por debajo del piso (min.Y = -248.616m)","Modelo descentrado (centro: X=0.110, Z=2.941)","Modelo muy grande (max dim = 643.0m). Verificar escala."]},"originalFormat":"3ds","originalSizeBytes":3185017,"originalSizeMb":3.0375,"triangles":42818,"validation":"warning","validationWarnings":["42,818 triángulos — recomendado < 10K","Modelo por debajo del piso (min.Y = -248.616m)","Modelo descentrado (centro: X=0.110, Z=2.941)","Modelo muy grande (max dim = 643.0m). Verificar escala."]},"model3dUrl":"/storage/converted/23ac4cc9-343f-499c-8775-64c0628c00d0.glb","position":[0,0,0],"price":1213,"productId":"1a8df8c7-601e-44fb-9037-82c7adf63b60","resizable":true,"rotation":[0,0,0],"scale":[1,1,1],"snapPoints":[],"tenantId":"ad434e3f-b929-4ff4-a80d-11feac16b136","type":"catalog-item","width":0.78}],"lines":[],"openings":[],"rectangles":[],"scenes":[],"volumes":[],"walls":[]}	{"totalItems": 2, "totalLines": 0, "totalWalls": 0, "totalOpenings": 0}
94235198-f6f5-424c-8433-5da58646cd48	6c68bf23-2a22-489c-abff-8f6bd685d4b8	1	{"faces": [], "items": [{"id": "jhfrfuf0r", "type": "catalog-item", "depth": 0.8, "label": "ISABELA ", "price": 2323, "scale": [1, 1, 1], "width": 1.2, "height": 0.75, "layerId": "lines", "metadata": {"materials": 1, "triangles": 40728, "model3dUrl": "/storage/converted/6b3758e0-67c6-451f-818e-c938c02f0580.glb", "validation": "warning", "boundingBox": {"max": [0.5052420682215992, 0.7394428030406789, 0.304865394551872], "min": [-0.3154240733886066, 0.000994644281507252, -0.4799870735907856], "depth": 0.7849, "width": 0.8207, "height": 0.7384}, "convertedAt": "2026-03-28T06:05:13.971Z", "orientation": {"status": "ok", "centered": true, "warnings": [], "floorAligned": true}, "dracoEnabled": true, "normalization": {"normalized": true, "finalMaxDim": 0.8205659866333008, "detectedUnit": "cm", "scaleApplied": 0.01, "originalMaxDim": 82.05659866333008}, "originalFormat": "obj", "originalSizeMb": 6.1741, "optimizedSizeMb": 0.3275, "compressionRatio": 94.7, "originalSizeBytes": 6474010, "optimizedSizeBytes": 343400, "validationWarnings": ["40,728 triángulos — recomendado < 10K"]}, "position": [0, 0, 0], "rotation": [0, 0, 0], "tenantId": "ad434e3f-b929-4ff4-a80d-11feac16b136", "productId": "705bc497-70b8-4c51-ab25-340efcb1b26a", "resizable": true, "model3dUrl": "/storage/converted/6b3758e0-67c6-451f-818e-c938c02f0580.glb", "snapPoints": [], "floorAnchor": 0.5, "hasPriceAccess": true}], "lines": [], "walls": [], "groups": [], "layers": [{"id": "walls", "name": "Muros", "locked": false, "visible": true}, {"id": "openings", "name": "Huecos", "locked": false, "visible": true}, {"id": "assets", "name": "Objetos", "locked": false, "visible": true}, {"id": "dimensions", "name": "Dimensiones", "locked": false, "visible": true}, {"id": "lines", "name": "Líneas de boceto", "locked": false, "visible": true}, {"id": "rectangles", "name": "Rectángulos", "locked": false, "visible": true}, {"id": "faces", "name": "Caras", "locked": false, "visible": true}, {"id": "volumes", "name": "Volúmenes", "locked": false, "visible": true}], "scenes": [], "volumes": [], "openings": [], "blueprint": {"url": null, "scale": 1, "locked": false, "opacity": 0.5, "visible": true, "position": [0, -0.01, 0], "rotation": 0}, "dimensions": [], "rectangles": []}	2026-03-29 23:06:57.811	manual	{"blueprint":{"locked":false,"opacity":0.5,"position":[0,-0.01,0],"rotation":0,"scale":1,"url":null,"visible":true},"dimensions":[],"faces":[],"groups":[],"items":[{"depth":0.8,"floorAnchor":0.5,"hasPriceAccess":true,"height":0.75,"id":"jhfrfuf0r","label":"ISABELA ","layerId":"lines","metadata":{"boundingBox":{"depth":0.7849,"height":0.7384,"max":[0.5052420682215992,0.7394428030406789,0.304865394551872],"min":[-0.3154240733886066,0.000994644281507252,-0.4799870735907856],"width":0.8207},"compressionRatio":94.7,"convertedAt":"2026-03-28T06:05:13.971Z","dracoEnabled":true,"materials":1,"model3dUrl":"/storage/converted/6b3758e0-67c6-451f-818e-c938c02f0580.glb","normalization":{"detectedUnit":"cm","finalMaxDim":0.8205659866333008,"normalized":true,"originalMaxDim":82.05659866333008,"scaleApplied":0.01},"optimizedSizeBytes":343400,"optimizedSizeMb":0.3275,"orientation":{"centered":true,"floorAligned":true,"status":"ok","warnings":[]},"originalFormat":"obj","originalSizeBytes":6474010,"originalSizeMb":6.1741,"triangles":40728,"validation":"warning","validationWarnings":["40,728 triángulos — recomendado < 10K"]},"model3dUrl":"/storage/converted/6b3758e0-67c6-451f-818e-c938c02f0580.glb","position":[0,0,0],"price":2323,"productId":"705bc497-70b8-4c51-ab25-340efcb1b26a","resizable":true,"rotation":[0,0,0],"scale":[1,1,1],"snapPoints":[],"tenantId":"ad434e3f-b929-4ff4-a80d-11feac16b136","type":"catalog-item","width":1.2}],"lines":[],"openings":[],"rectangles":[],"scenes":[],"volumes":[],"walls":[]}	{"totalItems": 1, "totalLines": 0, "totalWalls": 0, "totalOpenings": 0}
9c0f1ad7-0e50-4593-808f-d77163088626	2db1a1db-f2b2-42fe-863e-f358aaac09d0	1	{"faces": [], "items": [{"id": "g0st8n9oi", "type": "catalog-item", "depth": 1.2, "label": "LATERAL MESA BENCH 0.75X1.20X0.74 FRONTAL 75", "price": 5030.26, "scale": [1, 1, 1], "width": 0.75, "height": 0.74, "layerId": "lines", "metadata": {"unit": "m", "brand": "PEME", "model3dUrl": null}, "position": [0, 0, 0], "rotation": [0, 0, 0], "tenantId": "ad434e3f-b929-4ff4-a80d-11feac16b136", "productId": "a0244668-d009-42cf-a2e3-16e02a19e6aa", "resizable": true, "model3dUrl": null, "snapPoints": [], "floorAnchor": 0.5, "hasPriceAccess": true}], "lines": [], "walls": [], "groups": [], "layers": [{"id": "walls", "name": "Muros", "locked": false, "visible": true}, {"id": "openings", "name": "Huecos", "locked": false, "visible": true}, {"id": "assets", "name": "Objetos", "locked": false, "visible": true}, {"id": "dimensions", "name": "Dimensiones", "locked": false, "visible": true}, {"id": "lines", "name": "Líneas de boceto", "locked": false, "visible": true}, {"id": "rectangles", "name": "Rectángulos", "locked": false, "visible": true}, {"id": "faces", "name": "Caras", "locked": false, "visible": true}, {"id": "volumes", "name": "Volúmenes", "locked": false, "visible": true}], "scenes": [], "volumes": [], "openings": [], "blueprint": {"url": null, "scale": 1, "locked": false, "opacity": 0.5, "visible": true, "position": [0, -0.01, 0], "rotation": 0}, "dimensions": [], "rectangles": []}	2026-03-30 23:53:12.104	manual	{"blueprint":{"locked":false,"opacity":0.5,"position":[0,-0.01,0],"rotation":0,"scale":1,"url":null,"visible":true},"dimensions":[],"faces":[],"groups":[],"items":[{"depth":1.2,"floorAnchor":0.5,"hasPriceAccess":true,"height":0.74,"id":"g0st8n9oi","label":"LATERAL MESA BENCH 0.75X1.20X0.74 FRONTAL 75","layerId":"lines","metadata":{"brand":"PEME","model3dUrl":null,"unit":"m"},"model3dUrl":null,"position":[0,0,0],"price":5030.26,"productId":"a0244668-d009-42cf-a2e3-16e02a19e6aa","resizable":true,"rotation":[0,0,0],"scale":[1,1,1],"snapPoints":[],"tenantId":"ad434e3f-b929-4ff4-a80d-11feac16b136","type":"catalog-item","width":0.75}],"lines":[],"openings":[],"rectangles":[],"scenes":[],"volumes":[],"walls":[]}	{"totalItems": 1, "totalLines": 0, "totalWalls": 0, "totalOpenings": 0}
86ff1fb2-64d4-4b6d-82b6-6a0603119138	2db1a1db-f2b2-42fe-863e-f358aaac09d0	2	{"faces": [], "items": [{"id": "g0st8n9oi", "type": "catalog-item", "depth": 1.2, "label": "LATERAL MESA BENCH 0.75X1.20X0.74 FRONTAL 75", "price": 5030.26, "scale": [1, 1, 1], "width": 0.75, "height": 0.74, "layerId": "lines", "metadata": {"unit": "m", "brand": "PEME", "model3dUrl": null}, "position": [0, 0, 0.2], "rotation": [0, 0, 0], "tenantId": "ad434e3f-b929-4ff4-a80d-11feac16b136", "productId": "a0244668-d009-42cf-a2e3-16e02a19e6aa", "resizable": true, "model3dUrl": null, "snapPoints": [], "floorAnchor": 0.5, "hasPriceAccess": true}], "lines": [], "walls": [], "groups": [], "layers": [{"id": "walls", "name": "Muros", "locked": false, "visible": true}, {"id": "openings", "name": "Huecos", "locked": false, "visible": true}, {"id": "assets", "name": "Objetos", "locked": false, "visible": true}, {"id": "dimensions", "name": "Dimensiones", "locked": false, "visible": true}, {"id": "lines", "name": "Líneas de boceto", "locked": false, "visible": true}, {"id": "rectangles", "name": "Rectángulos", "locked": false, "visible": true}, {"id": "faces", "name": "Caras", "locked": false, "visible": true}, {"id": "volumes", "name": "Volúmenes", "locked": false, "visible": true}], "scenes": [], "volumes": [], "openings": [], "blueprint": {"url": null, "scale": 1, "locked": false, "opacity": 0.5, "visible": true, "position": [0, -0.01, 0], "rotation": 0}, "dimensions": [], "rectangles": []}	2026-03-31 00:09:09.591	autosave	{"blueprint":{"locked":false,"opacity":0.5,"position":[0,-0.01,0],"rotation":0,"scale":1,"url":null,"visible":true},"dimensions":[],"faces":[],"groups":[],"items":[{"depth":1.2,"floorAnchor":0.5,"hasPriceAccess":true,"height":0.74,"id":"g0st8n9oi","label":"LATERAL MESA BENCH 0.75X1.20X0.74 FRONTAL 75","layerId":"lines","metadata":{"brand":"PEME","model3dUrl":null,"unit":"m"},"model3dUrl":null,"position":[0,0,0.2],"price":5030.26,"productId":"a0244668-d009-42cf-a2e3-16e02a19e6aa","resizable":true,"rotation":[0,0,0],"scale":[1,1,1],"snapPoints":[],"tenantId":"ad434e3f-b929-4ff4-a80d-11feac16b136","type":"catalog-item","width":0.75}],"lines":[],"openings":[],"rectangles":[],"scenes":[],"volumes":[],"walls":[]}	{"totalItems": 1, "totalLines": 0, "totalWalls": 0, "totalOpenings": 0}
\.


--
-- TOC entry 3917 (class 0 OID 16673)
-- Dependencies: 243
-- Data for Name: projects; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.projects (id, tenant_id, name, description, price_type, creator_id, client_company, client_name, commercial_status, contact_email, contact_name, contact_phone, created_at, due_date, estimated_value, final_value, operational_status, priority, probability, project_code, source, tags, updated_at) FROM stdin;
af44d62e-9013-4c9d-9d43-7150b485068a	ad434e3f-b929-4ff4-a80d-11feac16b136	New Projectjsadfas	\N	A	00d6c278-f539-4a6c-9ca2-1ac75cb8a8ff	\N	\N	Prospecto	\N	\N	\N	2026-03-27 04:41:05.32	\N	\N	\N	Sin iniciar	Media	\N	\N	\N	\N	2026-03-27 04:41:05.32
cb80999d-132a-4cdc-a5f2-329e18a98250	ad434e3f-b929-4ff4-a80d-11feac16b136	otris	Copia de New Projectjsadfas	A	00d6c278-f539-4a6c-9ca2-1ac75cb8a8ff	\N	\N	Descubrimiento	\N	\N	\N	2026-03-27 04:43:49.931	\N	\N	\N	Sin iniciar	Media	\N	\N	\N	\N	2026-03-27 04:44:15.751
36b6ba7b-4b64-4171-9ab1-375c14d277e9	ad434e3f-b929-4ff4-a80d-11feac16b136	New Projectjsadfas (COPIA)	Copia de New Projectjsadfas	A	00d6c278-f539-4a6c-9ca2-1ac75cb8a8ff	\N	\N	Diseño	\N	\N	\N	2026-03-27 04:41:21.396	\N	\N	\N	Sin iniciar	Media	\N	\N	\N	\N	2026-03-27 04:44:17.846
8efad843-e540-4d3c-a68d-028147937e56	b0a521ce-a8f0-4a63-997d-911c06aa7495	Proyecto Test 1774586735775	\N	A	0464a0e6-8763-46fb-927b-119fbfc0d30c	\N	\N	Prospecto	\N	\N	\N	2026-03-27 04:45:35.811	\N	\N	\N	Sin iniciar	Media	\N	\N	\N	\N	2026-03-27 04:45:35.811
d560b37f-6412-49fa-9ff9-7966205e9c9e	b0a521ce-a8f0-4a63-997d-911c06aa7495	Proyecto Test 1774586747566	\N	A	0464a0e6-8763-46fb-927b-119fbfc0d30c	\N	\N	Prospecto	\N	\N	\N	2026-03-27 04:45:47.605	\N	\N	\N	Sin iniciar	Media	\N	\N	\N	\N	2026-03-27 04:45:47.605
e3391f89-3e70-420e-becc-800cf65916aa	ad434e3f-b929-4ff4-a80d-11feac16b136	NUEVO DISEÑO	\N	A	00d6c278-f539-4a6c-9ca2-1ac75cb8a8ff	\N	\N	Prospecto	\N	\N	\N	2026-03-28 03:57:57.026	\N	\N	\N	Sin iniciar	Media	\N	\N	\N	\N	2026-03-28 03:57:57.026
6c68bf23-2a22-489c-abff-8f6bd685d4b8	ad434e3f-b929-4ff4-a80d-11feac16b136	New Project	\N	A	00d6c278-f539-4a6c-9ca2-1ac75cb8a8ff	\N	\N	Prospecto	\N	\N	\N	2026-03-29 23:06:57.672	\N	\N	\N	Sin iniciar	Media	\N	\N	\N	\N	2026-03-29 23:06:57.672
2db1a1db-f2b2-42fe-863e-f358aaac09d0	ad434e3f-b929-4ff4-a80d-11feac16b136	New Project	\N	A	00d6c278-f539-4a6c-9ca2-1ac75cb8a8ff	\N	\N	Descubrimiento	\N	\N	\N	2026-03-30 23:53:11.96	\N	\N	\N	Sin iniciar	Media	\N	\N	\N	\N	2026-03-31 16:38:55.614
ec1caa04-b102-4e6b-8fcf-38127fbda83a	ad434e3f-b929-4ff4-a80d-11feac16b136	New Project	\N	A	00d6c278-f539-4a6c-9ca2-1ac75cb8a8ff	\N	\N	Prospecto	\N	\N	\N	2026-03-31 19:14:22.245	\N	\N	\N	Sin iniciar	Media	\N	\N	\N	\N	2026-03-31 19:14:22.245
\.


--
-- TOC entry 3930 (class 0 OID 17215)
-- Dependencies: 256
-- Data for Name: quote_lines; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.quote_lines (id, quote_id, product_id, variant_id, tenant_id, tenant_name, product_name, product_sku, quantity, price_list_type, base_list_price, discount_percent, authorized_price, pro_markup, final_price, line_total, currency, metadata) FROM stdin;
\.


--
-- TOC entry 3918 (class 0 OID 16683)
-- Dependencies: 244
-- Data for Name: quote_templates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.quote_templates (id, owner_type, tenant_id, distributor_id, name, logo_url, company_name, address, phone, email, rfc, website, primary_color, accent_color, font_family, header_text, footer_text, validity_days, show_iva, iva_rate, currency, is_default, active, created_at, updated_at) FROM stdin;
d3dc6391-a214-4827-9953-4dc05eef5782	tenant	ad434e3f-b929-4ff4-a80d-11feac16b136	\N	Cotización estándar	https://peme.mx/assets/img/LOGO%20PEME_gris.png	PEME	Av. Industrial 1234, Col. Centro, CAv. Industrial 1234, Col. Centro, Cd. de Mexicod. de M	(55) 1234-5678	ventas@pmlapiedad.com	PLP001231AB1	www.pmlapiedad.comw	#000000	#000000	helvetica		Esta cotización tiene carácter informativo y no constituye un compromiso comercial vinculante. Los precios están sujetos a confirmación.	20	t	0.16	MXN	t	t	2026-03-30 23:42:11.076	2026-03-31 00:26:20.378
\.


--
-- TOC entry 3919 (class 0 OID 16699)
-- Dependencies: 245
-- Data for Name: quotes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.quotes (id, tenant_id, project_version_id, total_amount, total_pieces, price_type, status, "quoteData", creator_id, "createdAt", distributor_id, iva_amount, quote_mode, subtotal_amount) FROM stdin;
56aa40d7-907b-401f-8efb-076e63570338	ad434e3f-b929-4ff4-a80d-11feac16b136	7550be06-3a79-4ef3-b99a-6c0d94109928	0.00	3	A	DRAFT	[{"product": "Escritorio Terra Roble", "lineTotal": 0, "unitPrice": 0}, {"product": "Locker 4 Compartimentos", "lineTotal": 0, "unitPrice": 0}, {"product": "Locker 4 Compartimentos", "lineTotal": 0, "unitPrice": 0}]	\N	2026-03-27 04:41:05.587	\N	0.00	PER_BRAND	0.00
54cb38c8-83c0-436b-b63c-e486abef2ac0	ad434e3f-b929-4ff4-a80d-11feac16b136	df56185e-e19b-423f-92c9-39694c3b92af	0.00	3	A	DRAFT	[{"product": "Escritorio Terra Roble", "lineTotal": 0, "unitPrice": 0}, {"product": "Locker 4 Compartimentos", "lineTotal": 0, "unitPrice": 0}, {"product": "Locker 4 Compartimentos", "lineTotal": 0, "unitPrice": 0}]	\N	2026-03-27 04:43:59.971	\N	0.00	PER_BRAND	0.00
0d47250a-e256-42dc-a74b-f185e4e40a7e	b0a521ce-a8f0-4a63-997d-911c06aa7495	4579730a-28a9-42df-ad19-28a27cc8bb99	0.00	1	A	DRAFT	[]	\N	2026-03-27 04:45:47.761	\N	0.00	PER_BRAND	0.00
da779fcf-864c-4f11-bfd8-e8194a2fdbab	ad434e3f-b929-4ff4-a80d-11feac16b136	4d4b962f-9610-4c6f-b2ba-8a465e951e39	1213.00	1	A	DRAFT	[{"product": "sillon 3ds", "lineTotal": 1213, "unitPrice": 1213}]	\N	2026-03-28 03:58:05.599	\N	0.00	PER_BRAND	0.00
af10e645-089d-4e8c-a914-b35c8c830c31	ad434e3f-b929-4ff4-a80d-11feac16b136	b0d97be3-b404-4454-844e-88e740f726f3	0.00	1	A	DRAFT	[{"product": "Escritorio Terra Roble", "lineTotal": 0, "unitPrice": 0}]	\N	2026-03-28 03:58:25.35	\N	0.00	PER_BRAND	0.00
b6a5ab97-eeaa-4271-917e-6d52d37dca31	ad434e3f-b929-4ff4-a80d-11feac16b136	f736d976-4d37-4190-811b-fb7b75b6e9a4	1213.00	2	A	DRAFT	[{"product": "sillon 3ds", "lineTotal": 1213, "unitPrice": 1213}, {"product": "Escritorio Terra Roble", "lineTotal": 0, "unitPrice": 0}]	\N	2026-03-28 04:02:59.858	\N	0.00	PER_BRAND	0.00
0f7a981f-8488-48b5-9cab-855311f27a4f	ad434e3f-b929-4ff4-a80d-11feac16b136	94235198-f6f5-424c-8433-5da58646cd48	2323.00	1	A	DRAFT	[{"product": "ISABELA ", "lineTotal": 2323, "unitPrice": 2323}]	\N	2026-03-29 23:06:57.857	\N	0.00	PER_BRAND	0.00
44ad3b88-e133-471e-93b0-b8e5798be26c	ad434e3f-b929-4ff4-a80d-11feac16b136	9c0f1ad7-0e50-4593-808f-d77163088626	4227.10	1	A	DRAFT	[{"product": "LATERAL MESA BENCH 0.75X1.20X0.74 FRONTAL 75", "lineTotal": 4227.1, "unitPrice": 4227.1}]	\N	2026-03-30 23:53:12.161	\N	0.00	PER_BRAND	0.00
b960232c-95ca-42f3-aea8-b25d7346942b	ad434e3f-b929-4ff4-a80d-11feac16b136	9c0f1ad7-0e50-4593-808f-d77163088626	5835.10	1	A	DRAFT	{"items": [{"sku": "", "name": "LATERAL MESA BENCH 0.75X1.20X0.74 FRONTAL 75", "hasPrice": true, "quantity": 1, "subtotal": 5030.26, "productId": "a0244668-d009-42cf-a2e3-16e02a19e6aa", "unitPrice": 5030.26}], "total": 5835.1, "ivaRate": 0.16, "subtotal": 5030.26, "ivaAmount": 804.84, "totalItems": 1, "itemsWithoutPrice": 0}	00d6c278-f539-4a6c-9ca2-1ac75cb8a8ff	2026-03-30 23:54:36.48	\N	0.00	PER_BRAND	0.00
bffef554-9d7d-421a-98f0-c06ced767f9d	ad434e3f-b929-4ff4-a80d-11feac16b136	9c0f1ad7-0e50-4593-808f-d77163088626	5835.10	1	A	DRAFT	{"items": [{"sku": "", "name": "LATERAL MESA BENCH 0.75X1.20X0.74 FRONTAL 75", "hasPrice": true, "quantity": 1, "subtotal": 5030.26, "productId": "a0244668-d009-42cf-a2e3-16e02a19e6aa", "unitPrice": 5030.26}], "total": 5835.1, "ivaRate": 0.16, "subtotal": 5030.26, "ivaAmount": 804.84, "totalItems": 1, "itemsWithoutPrice": 0}	00d6c278-f539-4a6c-9ca2-1ac75cb8a8ff	2026-03-31 00:04:17.568	\N	0.00	PER_BRAND	0.00
8d564517-849d-4853-9a9b-4b7e785822b4	ad434e3f-b929-4ff4-a80d-11feac16b136	9c0f1ad7-0e50-4593-808f-d77163088626	5835.10	1	A	DRAFT	{"items": [{"sku": "", "name": "LATERAL MESA BENCH 0.75X1.20X0.74 FRONTAL 75", "hasPrice": true, "quantity": 1, "subtotal": 5030.26, "productId": "a0244668-d009-42cf-a2e3-16e02a19e6aa", "unitPrice": 5030.26}], "total": 5835.1, "ivaRate": 0.16, "subtotal": 5030.26, "ivaAmount": 804.84, "totalItems": 1, "itemsWithoutPrice": 0}	00d6c278-f539-4a6c-9ca2-1ac75cb8a8ff	2026-03-31 00:04:18.87	\N	0.00	PER_BRAND	0.00
dd3ecdcb-b6e7-4330-9696-c29993888f58	ad434e3f-b929-4ff4-a80d-11feac16b136	9c0f1ad7-0e50-4593-808f-d77163088626	5835.10	1	A	DRAFT	{"items": [{"sku": "", "name": "LATERAL MESA BENCH 0.75X1.20X0.74 FRONTAL 75", "hasPrice": true, "quantity": 1, "subtotal": 5030.26, "productId": "a0244668-d009-42cf-a2e3-16e02a19e6aa", "unitPrice": 5030.26}], "total": 5835.1, "ivaRate": 0.16, "subtotal": 5030.26, "ivaAmount": 804.84, "totalItems": 1, "itemsWithoutPrice": 0}	00d6c278-f539-4a6c-9ca2-1ac75cb8a8ff	2026-03-31 00:04:30.071	\N	0.00	PER_BRAND	0.00
\.


--
-- TOC entry 3920 (class 0 OID 16708)
-- Dependencies: 246
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.roles (id, name, description) FROM stdin;
\.


--
-- TOC entry 3921 (class 0 OID 16713)
-- Dependencies: 247
-- Data for Name: rooms; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.rooms (id, project_version_id, name, area_square_meters, "dataJson") FROM stdin;
\.


--
-- TOC entry 3922 (class 0 OID 16718)
-- Dependencies: 248
-- Data for Name: tenants; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tenants (id, name, slug, status, logo_url, contact_email, created_by_id, metadata, created_at, updated_at) FROM stdin;
b0a521ce-a8f0-4a63-997d-911c06aa7495	Demo Brand	demo-brand	INACTIVE	\N	admin@demobrand.io	00d6c278-f539-4a6c-9ca2-1ac75cb8a8ff	{"country": "MX", "industry": "demo"}	2026-03-25 04:23:37.71	2026-03-26 16:30:27.249
687ecfd3-7d47-461c-89c9-627bd5dfe8c7	Demo Company	demo	INACTIVE	\N	hola@demo.mx	\N	\N	2026-03-25 04:23:38.807	2026-03-26 16:30:37.356
ad434e3f-b929-4ff4-a80d-11feac16b136	PM La Piedad	pm-la-piedad	ACTIVE	\N	jx.granados@pmlapiedad.com	\N	\N	2026-03-25 04:23:39.032	2026-03-26 21:03:04.739
843c9ed9-5fce-4111-9839-34949786bed8	PM La Piedad	pm-lapiedad	ACTIVE	\N	contacto@pmlapiedad.com	00d6c278-f539-4a6c-9ca2-1ac75cb8a8ff	{"country": "MX", "industry": "furniture"}	2026-03-25 04:23:37.696	2026-03-27 02:49:53.238
\.


--
-- TOC entry 3923 (class 0 OID 16725)
-- Dependencies: 249
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_roles (user_id, role_id) FROM stdin;
\.


--
-- TOC entry 3924 (class 0 OID 16730)
-- Dependencies: 250
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, email, password, "firstName", "lastName", tenant_id, "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 3925 (class 0 OID 16736)
-- Dependencies: 251
-- Data for Name: walls; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.walls (id, project_version_id, room_id, start_x, start_y, end_x, end_y, thickness, height) FROM stdin;
\.


--
-- TOC entry 3571 (class 2606 OID 16749)
-- Name: activation_codes activation_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.activation_codes
    ADD CONSTRAINT activation_codes_pkey PRIMARY KEY (id);


--
-- TOC entry 3573 (class 2606 OID 16751)
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- TOC entry 3575 (class 2606 OID 16753)
-- Name: brands brands_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.brands
    ADD CONSTRAINT brands_pkey PRIMARY KEY (id);


--
-- TOC entry 3577 (class 2606 OID 16755)
-- Name: catalog_accesses catalog_accesses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.catalog_accesses
    ADD CONSTRAINT catalog_accesses_pkey PRIMARY KEY (id);


--
-- TOC entry 3580 (class 2606 OID 16757)
-- Name: companies companies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.companies
    ADD CONSTRAINT companies_pkey PRIMARY KEY (id);


--
-- TOC entry 3582 (class 2606 OID 16759)
-- Name: company_brand_access company_brand_access_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_brand_access
    ADD CONSTRAINT company_brand_access_pkey PRIMARY KEY (company_id, brand_id);


--
-- TOC entry 3584 (class 2606 OID 16761)
-- Name: company_price_lists company_price_lists_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_price_lists
    ADD CONSTRAINT company_price_lists_pkey PRIMARY KEY (tenant_id, price_list_id);


--
-- TOC entry 3587 (class 2606 OID 16763)
-- Name: company_users company_users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_users
    ADD CONSTRAINT company_users_pkey PRIMARY KEY (id);


--
-- TOC entry 3589 (class 2606 OID 16765)
-- Name: discount_rules discount_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.discount_rules
    ADD CONSTRAINT discount_rules_pkey PRIMARY KEY (id);


--
-- TOC entry 3677 (class 2606 OID 17214)
-- Name: distributor_branding_configs distributor_branding_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.distributor_branding_configs
    ADD CONSTRAINT distributor_branding_configs_pkey PRIMARY KEY (id);


--
-- TOC entry 3592 (class 2606 OID 16767)
-- Name: distributor_catalog_accesses distributor_catalog_accesses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.distributor_catalog_accesses
    ADD CONSTRAINT distributor_catalog_accesses_pkey PRIMARY KEY (id);


--
-- TOC entry 3594 (class 2606 OID 16769)
-- Name: distributor_companies distributor_companies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.distributor_companies
    ADD CONSTRAINT distributor_companies_pkey PRIMARY KEY (id);


--
-- TOC entry 3597 (class 2606 OID 16771)
-- Name: distributor_price_markups distributor_price_markups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.distributor_price_markups
    ADD CONSTRAINT distributor_price_markups_pkey PRIMARY KEY (id);


--
-- TOC entry 3674 (class 2606 OID 17204)
-- Name: distributor_pro_pricing_rules distributor_pro_pricing_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.distributor_pro_pricing_rules
    ADD CONSTRAINT distributor_pro_pricing_rules_pkey PRIMARY KEY (id);


--
-- TOC entry 3600 (class 2606 OID 16773)
-- Name: distributor_users distributor_users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.distributor_users
    ADD CONSTRAINT distributor_users_pkey PRIMARY KEY (id);


--
-- TOC entry 3603 (class 2606 OID 16775)
-- Name: end_users end_users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.end_users
    ADD CONSTRAINT end_users_pkey PRIMARY KEY (id);


--
-- TOC entry 3605 (class 2606 OID 16777)
-- Name: import_jobs import_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.import_jobs
    ADD CONSTRAINT import_jobs_pkey PRIMARY KEY (id);


--
-- TOC entry 3607 (class 2606 OID 16779)
-- Name: manufacturer_distributor_accesses manufacturer_distributor_accesses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.manufacturer_distributor_accesses
    ADD CONSTRAINT manufacturer_distributor_accesses_pkey PRIMARY KEY (id);


--
-- TOC entry 3669 (class 2606 OID 17183)
-- Name: manufacturer_distributor_allowed_price_lists manufacturer_distributor_allowed_price_lists_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.manufacturer_distributor_allowed_price_lists
    ADD CONSTRAINT manufacturer_distributor_allowed_price_lists_pkey PRIMARY KEY (id);


--
-- TOC entry 3672 (class 2606 OID 17193)
-- Name: manufacturer_distributor_discounts manufacturer_distributor_discounts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.manufacturer_distributor_discounts
    ADD CONSTRAINT manufacturer_distributor_discounts_pkey PRIMARY KEY (id);


--
-- TOC entry 3610 (class 2606 OID 16781)
-- Name: openings openings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.openings
    ADD CONSTRAINT openings_pkey PRIMARY KEY (id);


--
-- TOC entry 3612 (class 2606 OID 16783)
-- Name: placements placements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.placements
    ADD CONSTRAINT placements_pkey PRIMARY KEY (id);


--
-- TOC entry 3615 (class 2606 OID 16785)
-- Name: platform_users platform_users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.platform_users
    ADD CONSTRAINT platform_users_pkey PRIMARY KEY (id);


--
-- TOC entry 3617 (class 2606 OID 16787)
-- Name: price_list_items price_list_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.price_list_items
    ADD CONSTRAINT price_list_items_pkey PRIMARY KEY (price_list_id, product_id_legacy);


--
-- TOC entry 3619 (class 2606 OID 16789)
-- Name: price_lists price_lists_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.price_lists
    ADD CONSTRAINT price_lists_pkey PRIMARY KEY (id);


--
-- TOC entry 3621 (class 2606 OID 16791)
-- Name: product_assets product_assets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_assets
    ADD CONSTRAINT product_assets_pkey PRIMARY KEY (id);


--
-- TOC entry 3623 (class 2606 OID 16793)
-- Name: product_categories product_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_categories
    ADD CONSTRAINT product_categories_pkey PRIMARY KEY (id);


--
-- TOC entry 3626 (class 2606 OID 16795)
-- Name: product_conditions product_conditions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_conditions
    ADD CONSTRAINT product_conditions_pkey PRIMARY KEY (id);


--
-- TOC entry 3628 (class 2606 OID 16797)
-- Name: product_lines product_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_lines
    ADD CONSTRAINT product_lines_pkey PRIMARY KEY (id);


--
-- TOC entry 3631 (class 2606 OID 16799)
-- Name: product_prices product_prices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_prices
    ADD CONSTRAINT product_prices_pkey PRIMARY KEY (id);


--
-- TOC entry 3637 (class 2606 OID 16801)
-- Name: product_variants product_variants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_variants
    ADD CONSTRAINT product_variants_pkey PRIMARY KEY (id);


--
-- TOC entry 3641 (class 2606 OID 16803)
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- TOC entry 3645 (class 2606 OID 16805)
-- Name: project_versions project_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_versions
    ADD CONSTRAINT project_versions_pkey PRIMARY KEY (id);


--
-- TOC entry 3648 (class 2606 OID 16807)
-- Name: projects projects_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_pkey PRIMARY KEY (id);


--
-- TOC entry 3679 (class 2606 OID 17226)
-- Name: quote_lines quote_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quote_lines
    ADD CONSTRAINT quote_lines_pkey PRIMARY KEY (id);


--
-- TOC entry 3650 (class 2606 OID 16809)
-- Name: quote_templates quote_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quote_templates
    ADD CONSTRAINT quote_templates_pkey PRIMARY KEY (id);


--
-- TOC entry 3652 (class 2606 OID 16811)
-- Name: quotes quotes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quotes
    ADD CONSTRAINT quotes_pkey PRIMARY KEY (id);


--
-- TOC entry 3655 (class 2606 OID 16813)
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- TOC entry 3657 (class 2606 OID 16815)
-- Name: rooms rooms_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rooms
    ADD CONSTRAINT rooms_pkey PRIMARY KEY (id);


--
-- TOC entry 3659 (class 2606 OID 16817)
-- Name: tenants tenants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_pkey PRIMARY KEY (id);


--
-- TOC entry 3662 (class 2606 OID 16819)
-- Name: user_roles user_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_pkey PRIMARY KEY (user_id, role_id);


--
-- TOC entry 3665 (class 2606 OID 16821)
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- TOC entry 3667 (class 2606 OID 16823)
-- Name: walls walls_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.walls
    ADD CONSTRAINT walls_pkey PRIMARY KEY (id);


--
-- TOC entry 3569 (class 1259 OID 16824)
-- Name: activation_codes_code_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX activation_codes_code_key ON public.activation_codes USING btree (code);


--
-- TOC entry 3578 (class 1259 OID 16825)
-- Name: catalog_accesses_tenant_id_end_user_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX catalog_accesses_tenant_id_end_user_id_key ON public.catalog_accesses USING btree (tenant_id, end_user_id);


--
-- TOC entry 3585 (class 1259 OID 16826)
-- Name: company_users_email_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX company_users_email_key ON public.company_users USING btree (email);


--
-- TOC entry 3675 (class 1259 OID 17228)
-- Name: distributor_branding_configs_distributor_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX distributor_branding_configs_distributor_id_key ON public.distributor_branding_configs USING btree (distributor_id);


--
-- TOC entry 3590 (class 1259 OID 16827)
-- Name: distributor_catalog_accesses_distributor_id_tenant_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX distributor_catalog_accesses_distributor_id_tenant_id_key ON public.distributor_catalog_accesses USING btree (distributor_id, tenant_id);


--
-- TOC entry 3595 (class 1259 OID 16828)
-- Name: distributor_companies_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX distributor_companies_slug_key ON public.distributor_companies USING btree (slug);


--
-- TOC entry 3598 (class 1259 OID 16829)
-- Name: distributor_users_email_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX distributor_users_email_key ON public.distributor_users USING btree (email);


--
-- TOC entry 3601 (class 1259 OID 16830)
-- Name: end_users_email_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX end_users_email_key ON public.end_users USING btree (email);


--
-- TOC entry 3608 (class 1259 OID 16831)
-- Name: manufacturer_distributor_accesses_tenant_id_distributor_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX manufacturer_distributor_accesses_tenant_id_distributor_id_key ON public.manufacturer_distributor_accesses USING btree (tenant_id, distributor_id);


--
-- TOC entry 3670 (class 1259 OID 17227)
-- Name: manufacturer_distributor_allowed_price_lists_tenant_id_dist_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX manufacturer_distributor_allowed_price_lists_tenant_id_dist_key ON public.manufacturer_distributor_allowed_price_lists USING btree (tenant_id, distributor_id, price_list_type);


--
-- TOC entry 3613 (class 1259 OID 16832)
-- Name: platform_users_email_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX platform_users_email_key ON public.platform_users USING btree (email);


--
-- TOC entry 3624 (class 1259 OID 16833)
-- Name: product_categories_tenant_id_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX product_categories_tenant_id_slug_key ON public.product_categories USING btree (tenant_id, slug);


--
-- TOC entry 3629 (class 1259 OID 16834)
-- Name: product_lines_tenant_id_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX product_lines_tenant_id_slug_key ON public.product_lines USING btree (tenant_id, slug);


--
-- TOC entry 3632 (class 1259 OID 17229)
-- Name: product_prices_product_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_prices_product_id_idx ON public.product_prices USING btree (product_id);


--
-- TOC entry 3633 (class 1259 OID 16835)
-- Name: product_prices_product_id_variant_id_price_type_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX product_prices_product_id_variant_id_price_type_key ON public.product_prices USING btree (product_id, variant_id, price_type);


--
-- TOC entry 3634 (class 1259 OID 17230)
-- Name: product_prices_variant_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_prices_variant_id_idx ON public.product_prices USING btree (variant_id);


--
-- TOC entry 3635 (class 1259 OID 17232)
-- Name: product_variants_active_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_variants_active_idx ON public.product_variants USING btree (active);


--
-- TOC entry 3638 (class 1259 OID 17231)
-- Name: product_variants_product_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_variants_product_id_idx ON public.product_variants USING btree (product_id);


--
-- TOC entry 3639 (class 1259 OID 16836)
-- Name: product_variants_tenant_id_sku_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX product_variants_tenant_id_sku_key ON public.product_variants USING btree (tenant_id, sku);


--
-- TOC entry 3642 (class 1259 OID 17233)
-- Name: products_status_active_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX products_status_active_idx ON public.products USING btree (status, active);


--
-- TOC entry 3643 (class 1259 OID 16837)
-- Name: products_tenant_id_sku_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX products_tenant_id_sku_key ON public.products USING btree (tenant_id, sku);


--
-- TOC entry 3646 (class 1259 OID 16838)
-- Name: project_versions_project_id_versionNum_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "project_versions_project_id_versionNum_key" ON public.project_versions USING btree (project_id, "versionNum");


--
-- TOC entry 3653 (class 1259 OID 16839)
-- Name: roles_name_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX roles_name_key ON public.roles USING btree (name);


--
-- TOC entry 3660 (class 1259 OID 16840)
-- Name: tenants_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX tenants_slug_key ON public.tenants USING btree (slug);


--
-- TOC entry 3663 (class 1259 OID 16841)
-- Name: users_email_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX users_email_key ON public.users USING btree (email);


--
-- TOC entry 3680 (class 2606 OID 16842)
-- Name: activation_codes activation_codes_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.activation_codes
    ADD CONSTRAINT activation_codes_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3681 (class 2606 OID 16847)
-- Name: audit_logs audit_company_user_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_company_user_fk FOREIGN KEY (actor_id) REFERENCES public.company_users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- TOC entry 3682 (class 2606 OID 16852)
-- Name: audit_logs audit_end_user_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_end_user_fk FOREIGN KEY (actor_id) REFERENCES public.end_users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- TOC entry 3683 (class 2606 OID 16857)
-- Name: audit_logs audit_logs_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- TOC entry 3684 (class 2606 OID 16862)
-- Name: audit_logs audit_platform_user_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_platform_user_fk FOREIGN KEY (actor_id) REFERENCES public.platform_users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- TOC entry 3685 (class 2606 OID 16867)
-- Name: brands brand_legacy_company_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.brands
    ADD CONSTRAINT brand_legacy_company_fk FOREIGN KEY (tenant_id) REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- TOC entry 3686 (class 2606 OID 16872)
-- Name: brands brand_tenant_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.brands
    ADD CONSTRAINT brand_tenant_fk FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- TOC entry 3687 (class 2606 OID 16877)
-- Name: catalog_accesses catalog_accesses_activated_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.catalog_accesses
    ADD CONSTRAINT catalog_accesses_activated_by_user_id_fkey FOREIGN KEY (activated_by_user_id) REFERENCES public.company_users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- TOC entry 3688 (class 2606 OID 16882)
-- Name: catalog_accesses catalog_accesses_activation_code_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.catalog_accesses
    ADD CONSTRAINT catalog_accesses_activation_code_id_fkey FOREIGN KEY (activation_code_id) REFERENCES public.activation_codes(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- TOC entry 3689 (class 2606 OID 16887)
-- Name: catalog_accesses catalog_accesses_end_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.catalog_accesses
    ADD CONSTRAINT catalog_accesses_end_user_id_fkey FOREIGN KEY (end_user_id) REFERENCES public.end_users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3690 (class 2606 OID 16892)
-- Name: catalog_accesses catalog_accesses_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.catalog_accesses
    ADD CONSTRAINT catalog_accesses_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3691 (class 2606 OID 16897)
-- Name: company_brand_access company_brand_access_brand_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_brand_access
    ADD CONSTRAINT company_brand_access_brand_id_fkey FOREIGN KEY (brand_id) REFERENCES public.brands(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3692 (class 2606 OID 16902)
-- Name: company_brand_access company_brand_access_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_brand_access
    ADD CONSTRAINT company_brand_access_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3693 (class 2606 OID 16907)
-- Name: company_price_lists company_price_list_legacy_company_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_price_lists
    ADD CONSTRAINT company_price_list_legacy_company_fk FOREIGN KEY (tenant_id) REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3694 (class 2606 OID 16912)
-- Name: company_price_lists company_price_list_tenant_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_price_lists
    ADD CONSTRAINT company_price_list_tenant_fk FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3695 (class 2606 OID 16917)
-- Name: company_price_lists company_price_lists_price_list_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_price_lists
    ADD CONSTRAINT company_price_lists_price_list_id_fkey FOREIGN KEY (price_list_id) REFERENCES public.price_lists(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3696 (class 2606 OID 16922)
-- Name: company_users company_users_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_users
    ADD CONSTRAINT company_users_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3697 (class 2606 OID 16927)
-- Name: discount_rules discount_rule_legacy_company_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.discount_rules
    ADD CONSTRAINT discount_rule_legacy_company_fk FOREIGN KEY (tenant_id) REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3698 (class 2606 OID 16932)
-- Name: discount_rules discount_rule_tenant_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.discount_rules
    ADD CONSTRAINT discount_rule_tenant_fk FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3744 (class 2606 OID 17259)
-- Name: distributor_branding_configs distributor_branding_configs_distributor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.distributor_branding_configs
    ADD CONSTRAINT distributor_branding_configs_distributor_id_fkey FOREIGN KEY (distributor_id) REFERENCES public.distributor_companies(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3699 (class 2606 OID 16937)
-- Name: distributor_catalog_accesses distributor_catalog_accesses_distributor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.distributor_catalog_accesses
    ADD CONSTRAINT distributor_catalog_accesses_distributor_id_fkey FOREIGN KEY (distributor_id) REFERENCES public.distributor_companies(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3700 (class 2606 OID 16942)
-- Name: distributor_catalog_accesses distributor_catalog_accesses_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.distributor_catalog_accesses
    ADD CONSTRAINT distributor_catalog_accesses_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3701 (class 2606 OID 16947)
-- Name: distributor_price_markups distributor_price_markups_distributor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.distributor_price_markups
    ADD CONSTRAINT distributor_price_markups_distributor_id_fkey FOREIGN KEY (distributor_id) REFERENCES public.distributor_companies(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3743 (class 2606 OID 17254)
-- Name: distributor_pro_pricing_rules distributor_pro_pricing_rules_distributor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.distributor_pro_pricing_rules
    ADD CONSTRAINT distributor_pro_pricing_rules_distributor_id_fkey FOREIGN KEY (distributor_id) REFERENCES public.distributor_companies(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3702 (class 2606 OID 16952)
-- Name: distributor_users distributor_users_distributor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.distributor_users
    ADD CONSTRAINT distributor_users_distributor_id_fkey FOREIGN KEY (distributor_id) REFERENCES public.distributor_companies(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3703 (class 2606 OID 16957)
-- Name: import_jobs import_jobs_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.import_jobs
    ADD CONSTRAINT import_jobs_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3704 (class 2606 OID 16962)
-- Name: manufacturer_distributor_accesses manufacturer_distributor_accesses_distributor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.manufacturer_distributor_accesses
    ADD CONSTRAINT manufacturer_distributor_accesses_distributor_id_fkey FOREIGN KEY (distributor_id) REFERENCES public.distributor_companies(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3705 (class 2606 OID 16967)
-- Name: manufacturer_distributor_accesses manufacturer_distributor_accesses_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.manufacturer_distributor_accesses
    ADD CONSTRAINT manufacturer_distributor_accesses_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3739 (class 2606 OID 17239)
-- Name: manufacturer_distributor_allowed_price_lists manufacturer_distributor_allowed_price_lists_distributor_i_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.manufacturer_distributor_allowed_price_lists
    ADD CONSTRAINT manufacturer_distributor_allowed_price_lists_distributor_i_fkey FOREIGN KEY (distributor_id) REFERENCES public.distributor_companies(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3740 (class 2606 OID 17234)
-- Name: manufacturer_distributor_allowed_price_lists manufacturer_distributor_allowed_price_lists_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.manufacturer_distributor_allowed_price_lists
    ADD CONSTRAINT manufacturer_distributor_allowed_price_lists_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3741 (class 2606 OID 17249)
-- Name: manufacturer_distributor_discounts manufacturer_distributor_discounts_distributor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.manufacturer_distributor_discounts
    ADD CONSTRAINT manufacturer_distributor_discounts_distributor_id_fkey FOREIGN KEY (distributor_id) REFERENCES public.distributor_companies(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3742 (class 2606 OID 17244)
-- Name: manufacturer_distributor_discounts manufacturer_distributor_discounts_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.manufacturer_distributor_discounts
    ADD CONSTRAINT manufacturer_distributor_discounts_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3706 (class 2606 OID 16972)
-- Name: openings openings_project_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.openings
    ADD CONSTRAINT openings_project_version_id_fkey FOREIGN KEY (project_version_id) REFERENCES public.project_versions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3707 (class 2606 OID 16977)
-- Name: openings openings_wall_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.openings
    ADD CONSTRAINT openings_wall_id_fkey FOREIGN KEY (wall_id) REFERENCES public.walls(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3708 (class 2606 OID 16982)
-- Name: placements placements_project_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.placements
    ADD CONSTRAINT placements_project_version_id_fkey FOREIGN KEY (project_version_id) REFERENCES public.project_versions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3709 (class 2606 OID 16987)
-- Name: placements placements_room_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.placements
    ADD CONSTRAINT placements_room_id_fkey FOREIGN KEY (room_id) REFERENCES public.rooms(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- TOC entry 3710 (class 2606 OID 16992)
-- Name: price_list_items price_list_items_price_list_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.price_list_items
    ADD CONSTRAINT price_list_items_price_list_id_fkey FOREIGN KEY (price_list_id) REFERENCES public.price_lists(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3711 (class 2606 OID 16997)
-- Name: product_assets product_assets_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_assets
    ADD CONSTRAINT product_assets_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3712 (class 2606 OID 17002)
-- Name: product_assets product_assets_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_assets
    ADD CONSTRAINT product_assets_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3713 (class 2606 OID 17007)
-- Name: product_categories product_categories_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_categories
    ADD CONSTRAINT product_categories_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.product_categories(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- TOC entry 3714 (class 2606 OID 17012)
-- Name: product_categories product_categories_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_categories
    ADD CONSTRAINT product_categories_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3715 (class 2606 OID 17017)
-- Name: product_conditions product_conditions_line_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_conditions
    ADD CONSTRAINT product_conditions_line_id_fkey FOREIGN KEY (line_id) REFERENCES public.product_lines(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- TOC entry 3716 (class 2606 OID 17022)
-- Name: product_conditions product_conditions_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_conditions
    ADD CONSTRAINT product_conditions_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- TOC entry 3717 (class 2606 OID 17027)
-- Name: product_conditions product_conditions_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_conditions
    ADD CONSTRAINT product_conditions_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3718 (class 2606 OID 17032)
-- Name: product_lines product_lines_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_lines
    ADD CONSTRAINT product_lines_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3719 (class 2606 OID 17037)
-- Name: product_prices product_prices_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_prices
    ADD CONSTRAINT product_prices_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3720 (class 2606 OID 17042)
-- Name: product_prices product_prices_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_prices
    ADD CONSTRAINT product_prices_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3721 (class 2606 OID 17047)
-- Name: product_prices product_prices_variant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_prices
    ADD CONSTRAINT product_prices_variant_id_fkey FOREIGN KEY (variant_id) REFERENCES public.product_variants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3722 (class 2606 OID 17052)
-- Name: product_variants product_variants_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_variants
    ADD CONSTRAINT product_variants_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3723 (class 2606 OID 17057)
-- Name: product_variants product_variants_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_variants
    ADD CONSTRAINT product_variants_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3724 (class 2606 OID 17062)
-- Name: products products_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.product_categories(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- TOC entry 3725 (class 2606 OID 17067)
-- Name: products products_line_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_line_id_fkey FOREIGN KEY (line_id) REFERENCES public.product_lines(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- TOC entry 3726 (class 2606 OID 17072)
-- Name: products products_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3727 (class 2606 OID 17077)
-- Name: project_versions project_versions_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_versions
    ADD CONSTRAINT project_versions_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3728 (class 2606 OID 17082)
-- Name: projects projects_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3745 (class 2606 OID 17264)
-- Name: quote_lines quote_lines_quote_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quote_lines
    ADD CONSTRAINT quote_lines_quote_id_fkey FOREIGN KEY (quote_id) REFERENCES public.quotes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3729 (class 2606 OID 17087)
-- Name: quote_templates quote_templates_distributor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quote_templates
    ADD CONSTRAINT quote_templates_distributor_id_fkey FOREIGN KEY (distributor_id) REFERENCES public.distributor_companies(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3730 (class 2606 OID 17092)
-- Name: quote_templates quote_templates_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quote_templates
    ADD CONSTRAINT quote_templates_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3731 (class 2606 OID 17097)
-- Name: quotes quotes_project_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quotes
    ADD CONSTRAINT quotes_project_version_id_fkey FOREIGN KEY (project_version_id) REFERENCES public.project_versions(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- TOC entry 3732 (class 2606 OID 17102)
-- Name: rooms rooms_project_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rooms
    ADD CONSTRAINT rooms_project_version_id_fkey FOREIGN KEY (project_version_id) REFERENCES public.project_versions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3733 (class 2606 OID 17107)
-- Name: tenants tenants_created_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_created_by_id_fkey FOREIGN KEY (created_by_id) REFERENCES public.platform_users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- TOC entry 3734 (class 2606 OID 17112)
-- Name: user_roles user_roles_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3735 (class 2606 OID 17117)
-- Name: user_roles user_roles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3736 (class 2606 OID 17122)
-- Name: users users_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- TOC entry 3737 (class 2606 OID 17127)
-- Name: walls walls_project_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.walls
    ADD CONSTRAINT walls_project_version_id_fkey FOREIGN KEY (project_version_id) REFERENCES public.project_versions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3738 (class 2606 OID 17132)
-- Name: walls walls_room_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.walls
    ADD CONSTRAINT walls_room_id_fkey FOREIGN KEY (room_id) REFERENCES public.rooms(id) ON UPDATE CASCADE ON DELETE SET NULL;


-- Completed on 2026-04-06 17:13:39 UTC

--
-- PostgreSQL database dump complete
--

\unrestrict rKVYobWk74ozb3Tvam8pFcQK3gwHeFOgCN21xfg50LNeX3ZeAUY9ndFYBs9NUro

